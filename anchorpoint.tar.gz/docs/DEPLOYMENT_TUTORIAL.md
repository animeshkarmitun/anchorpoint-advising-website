# 🚀 Deployment Tutorial — Anchor Point Advising

> **Audience:** Developers on the team who need to deploy, debug, or understand the deploy pipeline.
>
> **Last Updated:** 2026-03-01

---

## Table of Contents

1. [How Deployment Works (Big Picture)](#1-how-deployment-works-big-picture)
2. [Project Structure](#2-project-structure)
3. [The Deploy Script — `scripts/deploy.sh`](#3-the-deploy-script)
4. [CI/CD Pipeline — GitHub Actions](#4-cicd-pipeline--github-actions)
5. [Server Config — `~/.server-setup.conf`](#5-server-config)
6. [Environment Files](#6-environment-files)
7. [Common Scenarios](#7-common-scenarios)
8. [Troubleshooting](#8-troubleshooting)
9. [First-Time Server Setup](#9-first-time-server-setup)

---

## 1. How Deployment Works (Big Picture)

```
Developer pushes to `main`
        │
        ▼
GitHub Actions triggers ──────────────────────────┐
        │                                         │
        ▼                                         │
SSH into the production server                    │
        │                                         │
        ▼                                         │
Run scripts/deploy.sh                             │
        │                                         │
        ├── git pull (sync to latest main)        │
        ├── Validate .env files                   │
        ├── Backend Deploy                        │
        │     ├── npm install                     │
        │     ├── prisma generate                 │
        │     ├── prisma migrate deploy           │
        │     ├── nest build                      │
        │     ├── Verify dist/main.js exists      │  ← safety check
        │     └── PM2 restart backend             │
        ├── Frontend Deploy                       │
        │     ├── npm install                     │
        │     ├── Clear .next/cache               │
        │     ├── next build                      │
        │     └── PM2 restart frontend            │
        ├── Health checks (backend, frontend)     │
        └── pm2 save                              │
                                                   │
GitHub Actions shows ✅ or ❌ ◄────────────────────┘
```

**Key principle:** The deploy script is designed to be **safe by default**. If anything fails (build error, missing env vars, etc.), it stops early and keeps the currently running version alive.

---

## 2. Project Structure

```
anchorpoint/
├── backend/                  ← NestJS API (port 3012)
│   ├── src/
│   ├── prisma/
│   │   └── schema.prisma     ← Database schema
│   ├── .env                  ← Backend secrets (NOT in git)
│   └── package.json          ← "start:prod": "node dist/main"
│
├── src/                      ← Next.js frontend
├── .env.local                ← Frontend env (auto-generated on deploy)
├── package.json              ← "dev": "next dev -p 3011"
│
├── scripts/
│   └── deploy.sh             ← Deploy orchestrator (IN git)
│
├── server-setup.sh           ← One-time server provisioning
│
└── .github/workflows/
    └── deploy.yml            ← CI/CD pipeline
```

**PM2 process names on the server:**

| Process | PM2 Name | Port | Start Command |
|---------|----------|------|---------------|
| Backend | `anchor-point` | 3012 | `npm run start:prod` |
| Frontend | `anchor-point-frontend` | 3011 | `npm run start` |

---

## 3. The Deploy Script

**File:** `scripts/deploy.sh`

This is the single source of truth for deployments. Both CI/CD and manual SSH deploys use this same script.

### Quick Reference

```bash
# Full deploy (backend + frontend)
bash scripts/deploy.sh

# Deploy only backend
bash scripts/deploy.sh backend

# Deploy only frontend
bash scripts/deploy.sh frontend

# Quick deploy — just pull code and restart PM2, skip rebuilding
bash scripts/deploy.sh --quick

# Rollback to the previous deployment
bash scripts/deploy.sh --rollback

# Show current deployment status
bash scripts/deploy.sh --status

# Show help
bash scripts/deploy.sh --help
```

### What Each Mode Does

#### `bash scripts/deploy.sh` or `bash scripts/deploy.sh all`

The **default full deploy**. This is what CI/CD runs on every push to `main`.

**Step by step:**

1. **Git pull** — Fetches `origin/${GIT_BRANCH}` and does a hard reset. Saves the current commit hash to `.last-deploy-commit` (used for rollback).

2. **Env validation** — Checks that `backend/.env` exists and contains `DATABASE_URL`, `JWT_SECRET`, and `PORT`. Auto-generates `/.env.local` for the frontend.

3. **Backend deploy:**
   - `npm install` — installs/updates dependencies
   - `npx prisma generate` — regenerates the Prisma client (needed after schema changes)
   - `npx prisma migrate deploy` — applies any pending database migrations (production-safe, never creates new migrations)
   - `npm run build` — compiles TypeScript to `dist/`
   - **Build verification** — checks that `dist/main.js` actually exists before proceeding. If the build silently fails, we do NOT restart PM2 (this protects your running app).
   - `pm2 restart anchor-point` — restarts the backend process with updated env

4. **Frontend deploy:**
   - `npm install` — installs/updates dependencies
   - Clears `.next/cache` — prevents stale ISR/cache issues
   - `npm run build` — runs `next build` (takes 1–3 minutes)
   - `pm2 restart anchor-point-frontend` — restarts the frontend

5. **Health check** — Curls `localhost:3012/api/` (backend) and `localhost:3011/` (frontend). If a domain is configured, also checks HTTPS.

6. **`pm2 save`** — Saves the PM2 process list so it survives server reboots.

#### `bash scripts/deploy.sh backend`

Runs only steps 1–3 above. Use this when you've only changed backend code (API routes, services, DTOs, Prisma schema, etc.) and don't want to wait for the frontend rebuild.

**When to use:**
- Changed a controller or service
- Updated the Prisma schema
- Fixed a backend bug
- Updated backend dependencies

#### `bash scripts/deploy.sh frontend`

Runs only steps 1, 2, and 4. Use this when you've only changed frontend code.

**When to use:**
- Changed a React component
- Updated content JSON files
- Changed styles
- Updated frontend dependencies

#### `bash scripts/deploy.sh --quick`

**Fastest option.** Pulls code and restarts PM2 processes without rebuilding. Takes ~5 seconds.

**When to use:**
- Fixed a typo in a content JSON file
- Changed a static file in `public/`
- **NOT safe** for TypeScript code changes (you need a rebuild for those)

> ⚠️ **Warning:** Quick deploy does NOT run `npm install`, `prisma generate`, or `npm run build`. If your code changes involve new dependencies, schema changes, or TypeScript changes, use a full deploy.

#### `bash scripts/deploy.sh --rollback`

Reverts to the commit that was running before the last deployment. Rebuilds everything and restarts PM2.

**What it does:**
1. Reads the stored commit hash from `.last-deploy-commit`
2. Checks out that commit
3. Reinstalls dependencies, rebuilds backend + frontend
4. Restarts both PM2 processes
5. Runs health checks

**When to use:**
- A deploy broke something and you need to go back immediately
- You deployed the wrong branch

> Note: You can only roll back once (to the immediately previous deployment). For deeper rollbacks, use `git log` and `git checkout <commit>` manually.

#### `bash scripts/deploy.sh --status`

Prints a summary of the current deployment without changing anything:

```
  App Name  : anchor-point
  Branch    : main
  Commit    : a1b2c3d
  Message   : fix: resolve TypeScript errors
  Date      : 2026-03-01 23:00:00 +0600

  Ports:
    Backend  : 3012
    Frontend : 3011

  PM2 Status:
    Backend  (anchor-point): online
    Frontend (anchor-point-frontend): online

  Last 5 deploy events:
    === BACKEND DEPLOY Sun Mar  1 23:00:00 BST 2026 ===
    === FRONTEND DEPLOY Sun Mar  1 23:02:00 BST 2026 ===
```

---

## 4. CI/CD Pipeline — GitHub Actions

**File:** `.github/workflows/deploy.yml`

### How It Triggers

| Trigger | What Happens |
|---------|--------------|
| **Push to `main`** | Automatic full deploy (`all`) |
| **Manual (Actions tab)** | You choose target (`all`/`backend`/`frontend`) and mode (`full`/`quick`) |

### Manual Trigger (Workflow Dispatch)

Go to **GitHub → Actions → "🚀 Deploy to Production" → Run workflow**:

- **deploy_target**: Choose `all`, `backend`, or `frontend`
- **deploy_mode**: Choose `full` (rebuild) or `quick` (restart only)

This is useful when you want to deploy just the backend after a hotfix, without waiting for the frontend rebuild.

### Concurrency Control

```yaml
concurrency:
  group: production-deploy
  cancel-in-progress: false
```

This means: **if two pushes happen close together, the second deploy waits for the first to finish.** It does NOT cancel the first one. This prevents two builds from running simultaneously and corrupting each other.

### Timeout

```yaml
timeout-minutes: 15
```

If a deploy takes more than 15 minutes (normally takes 3–5), it's automatically killed. This prevents a hung deploy from blocking all future deploys.

### What the Workflow Does

1. **Logs** the trigger info (who pushed, what commit, what branch)
2. **SSHes** into the production server using password authentication
3. **Loads** `~/.server-setup.conf` on the server (for `PROJECT_DIR`, port configs, etc.)
4. **Pulls** the latest code with `git reset --hard` (ensures clean state)
5. **Runs** `scripts/deploy.sh` with the appropriate target
6. **Reports** success or failure in the Actions logs

### Required GitHub Secrets

Go to **Settings → Secrets and Variables → Actions** and add:

| Secret | Example | Required | Notes |
|--------|---------|----------|-------|
| `SERVER_HOST` | `203.0.113.50` | ✅ | Your server's IP address |
| `SERVER_USER` | `root` | ✅ | SSH username |
| `SERVER_PASSWORD` | `your-password` | ✅ | SSH password |
| `SERVER_PORT` | `22` | ❌ | Only if not default 22 |
| `PROJECT_DIR` | `~/anchor-point` | ❌ | Fallback if ~/.server-setup.conf is missing |

---

## 5. Server Config

**File on server:** `~/.server-setup.conf`

This file is created by `server-setup.sh` during initial provisioning. The deploy script reads it automatically.

```bash
# Example ~/.server-setup.conf
APP_NAME="anchor-point"
PROJECT_DIR="/root/anchor-point"
APP_PORT="3012"
DOMAIN_NAME="anchorpointadvising.com"
GIT_BRANCH="main"
BACKEND_PORT="3012"
FRONTEND_PORT="3011"
```

You can override any of these with environment variables:

```bash
# Override branch for this deploy only
GIT_BRANCH=hotfix/login bash scripts/deploy.sh backend
```

---

## 6. Environment Files

### Frontend: `.env.local` (Auto-Generated)

The deploy script **automatically generates** this file on every deploy. You do NOT need to create or edit it on the server.

```bash
# Auto-generated by deploy.sh
BACKEND_URL=https://anchorpointadvising.com    # or http://localhost:3012 if no domain
NEXT_PUBLIC_BASE_URL=https://anchorpointadvising.com
```

### Backend: `backend/.env` (Manual, Never Overwritten)

This file contains secrets and **must be created manually** on the server before first deploy.

```bash
# Required variables
PORT=3012
DATABASE_URL="postgresql://user:password@host:5432/dbname"
JWT_SECRET="a-long-random-secret-string"

# Also important
FRONTEND_URL=https://anchorpointadvising.com   # For CORS
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d
REGISTRATION_MODE=OPEN
THROTTLE_TTL=60000
THROTTLE_LIMIT=100
UPLOAD_DIR=./uploads
```

> ⚠️ **The deploy script validates** that `DATABASE_URL`, `JWT_SECRET`, and `PORT` exist in `backend/.env`. If any are missing, the deploy **aborts** before touching anything.

---

## 7. Common Scenarios

### "I pushed a backend-only change"

```bash
# Via GitHub Actions:
# Go to Actions → Run workflow → target: backend

# Or SSH into the server:
bash scripts/deploy.sh backend
```

### "I need to fix a typo in content JSON right now"

```bash
# Quick deploy — just pulls and restarts, no rebuild
bash scripts/deploy.sh --quick
```

### "My deploy broke the site"

```bash
# Rollback to the previous working version
bash scripts/deploy.sh --rollback
```

### "I want to check what's deployed"

```bash
bash scripts/deploy.sh --status
```

### "I added a new Prisma model/field"

The deploy script handles this automatically:

1. Update `backend/prisma/schema.prisma`
2. Run `npx prisma migrate dev --name my_migration` locally
3. Commit the new migration file (in `backend/prisma/migrations/`)
4. Push to `main`
5. The deploy script runs `npx prisma migrate deploy` which applies the migration

> ⚡ **Never** run `prisma migrate dev` on the production server. Always create migrations locally and let `migrate deploy` apply them.

### "I need to deploy a feature branch"

```bash
# Override the branch (one-time)
GIT_BRANCH=feature/my-feature bash scripts/deploy.sh
```

Or update `~/.server-setup.conf` on the server:

```bash
GIT_BRANCH="feature/my-feature"
```

### "I need to add a new environment variable to the backend"

1. SSH into the server
2. Edit `backend/.env` and add the variable
3. Restart the backend: `pm2 restart anchor-point --update-env`

If the variable needs to be set on every deploy, add it to `~/.server-setup.conf` and update the `ensure_env_files()` function in `scripts/deploy.sh`.

---

## 8. Troubleshooting

### "Deploy failed — build error"

```bash
# Check the deploy log
cat ~/anchor-point/deploy.log | tail -50

# Check PM2 logs for the process that failed
pm2 logs anchor-point --lines 50          # backend
pm2 logs anchor-point-frontend --lines 50 # frontend
```

The deploy script is designed to **not restart PM2** if the build fails. Your previous working version should still be running.

### "Backend is not starting after deploy"

```bash
# Check if the build output exists
ls -la ~/anchor-point/backend/dist/main.js

# Check PM2 status
pm2 status

# View real-time logs
pm2 logs anchor-point --lines 100

# Common fix: restart with environment reload
pm2 restart anchor-point --update-env
```

### "Frontend is showing stale content"

```bash
# Clear the Next.js cache and rebuild
cd ~/anchor-point
rm -rf .next/cache
npm run build
pm2 restart anchor-point-frontend
```

### "Prisma migration failed"

```bash
# Check migration status
cd ~/anchor-point/backend
npx prisma migrate status

# If there's a failed migration, you may need to:
# 1. Fix the migration SQL
# 2. Mark it as applied: npx prisma migrate resolve --applied <migration_name>
# 3. Re-run deploy
```

### "PM2 processes keep crashing"

```bash
# Check the restart count
pm2 status

# If restart count is high, check why:
pm2 logs anchor-point --err --lines 30

# Reset restart count after fixing:
pm2 reset anchor-point
```

### "I need to see all PM2 processes"

```bash
pm2 status       # Quick overview
pm2 monit        # Live monitoring (CPU, memory, logs)
pm2 jlist        # JSON output (for scripting)
```

### "The server rebooted and nothing is running"

```bash
# PM2 should auto-start. If not:
pm2 resurrect

# If that doesn't work, re-run the deploy:
cd ~/anchor-point
bash scripts/deploy.sh
```

---

## 9. First-Time Server Setup

If you're setting up a brand new server:

1. **Run the provisioning script:**
   ```bash
   bash server-setup.sh
   ```
   This installs Node.js, Git, PM2, Nginx, configures firewall, SSL, etc.

2. **Create the backend `.env`:**
   ```bash
   nano ~/anchor-point/backend/.env
   ```
   Add all required variables (see [Section 6](#6-environment-files)).

3. **Run the first deploy:**
   ```bash
   bash scripts/deploy.sh
   ```

4. **Set up GitHub Secrets** (see [Section 4](#4-cicd-pipeline--github-actions)) so pushes to `main` auto-deploy.

---

## Quick Cheat Sheet

```bash
# ── Deploy Commands ────────────────────────────
bash scripts/deploy.sh               # Full deploy (all)
bash scripts/deploy.sh backend       # Backend only
bash scripts/deploy.sh frontend      # Frontend only
bash scripts/deploy.sh --quick       # Pull + restart (no rebuild)
bash scripts/deploy.sh --rollback    # Undo last deploy
bash scripts/deploy.sh --status      # What's deployed now?

# ── PM2 Commands ───────────────────────────────
pm2 status                           # Process overview
pm2 logs anchor-point --lines 50     # Backend logs
pm2 logs anchor-point-frontend       # Frontend logs
pm2 monit                            # Live dashboard
pm2 restart anchor-point             # Restart backend
pm2 restart all                      # Restart everything

# ── Debugging ──────────────────────────────────
cat deploy.log | tail -30            # Deploy log
pm2 logs --err --lines 30            # Error-only logs
npx prisma migrate status            # DB migration status
curl http://localhost:3012/api/       # Test backend locally
curl http://localhost:3011/           # Test frontend locally
```
