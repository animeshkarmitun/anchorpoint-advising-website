# Anchor Point Advising — Credentials & Access

> **⚠️ CONFIDENTIAL** — Do not commit this file to public repositories.
> All passwords must be changed immediately in production environments.

---

## Admin Panel

| Item | Value |
|------|-------|
| **Backend API** | `http://localhost:3012` |
| **Swagger Docs** | `http://localhost:3012/api/docs` |
| **Frontend** | `http://localhost:3011` |

---

## Super Admin (1 account)

| Field | Value |
|-------|-------|
| **Email** | `admin@anchorpoint.com` |
| **Password** | `AnchorAdmin@2026` |
| **Role** | `SUPER_ADMIN` |
| **Access** | Full access to all admin endpoints, staff management, analytics, audit logs, settings |

---

## Staff Accounts

### Tax Advisors (2 accounts)

| Email | Password | Role |
|-------|----------|------|
| `rafiq.advisor@anchorpoint.com` | `Advisor@2026` | `TAX_ADVISOR` |
| `nusrat.advisor@anchorpoint.com` | `Advisor@2026` | `TAX_ADVISOR` |

**Access:** Assigned filings, documents, consultations, customer messaging

### Operations (1 account)

| Email | Password | Role |
|-------|----------|------|
| `ops@anchorpoint.com` | `OpsTeam@2026` | `OPERATIONS` |

**Access:** CMS, analytics, dashboard, payments, filings management, SEO, messaging

### Support (1 account)

| Email | Password | Role |
|-------|----------|------|
| `support@anchorpoint.com` | `Support@2026` | `SUPPORT` |

**Access:** Support tickets, customer messaging

---

## Test Customer Accounts (5 accounts)

All customers share the same password: **`Customer@2026`**

| # | Email | Phone | Name | Profile |
|---|-------|-------|------|---------|
| 1 | `karim.customer@example.com` | +8801711000001 | Abdul Karim | ✅ Complete — Individual, salaried at Grameenphone, TIN + NID |
| 2 | `fatima.customer@example.com` | +8801711000002 | Fatima Begum | ✅ Complete — Business owner (Fatima Textiles), trade license, Bangla UI |
| 3 | `tanvir.customer@example.com` | +8801711000003 | Tanvir Hassan | ⏳ Incomplete onboarding — Freelancer, no TIN/NID yet |
| 4 | `rezaul.customer@example.com` | +8801711000004 | Rezaul Karim | ✅ Complete — NRB (Singapore), VIP flag, multiple income sources |
| 5 | `shirin.customer@example.com` | +8801711000005 | Shirin Akter | ❌ Inactive — Unverified email & phone, incomplete onboarding |

---

## Seeding

Run the seeder to create all accounts:

```bash
cd backend
npx prisma db seed
```

The seeder uses `upsert`, so it is **safe to run multiple times** without duplicating data.

---

## Role Permission Matrix

| Capability | CUSTOMER | TAX_ADVISOR | OPERATIONS | SUPPORT | SUPER_ADMIN |
|-----------|----------|-------------|------------|---------|-------------|
| Own profile & filings | ✅ | — | — | — | — |
| Upload documents | ✅ | — | — | — | — |
| Book consultations | ✅ | — | — | — | — |
| View assigned filings | — | ✅ | — | — | ✅ |
| Review documents | — | ✅ | — | — | ✅ |
| Manage all filings | — | — | ✅ | — | ✅ |
| Manage CMS & SEO | — | — | ✅ | — | ✅ |
| Admin dashboard | — | — | ✅ | — | ✅ |
| Manage payments | — | — | ✅ | — | ✅ |
| Handle tickets | — | — | — | ✅ | ✅ |
| Manage staff | — | — | — | — | ✅ |
| Audit logs | — | — | — | — | ✅ |
| System settings | — | — | — | — | ✅ |
