# Anchor Point Advising — Frontend Implementation Prompts

> **Last Updated:** 05 March 2026  
> **Stack:** Next.js 16 (App Router) · TailwindCSS 4 · TypeScript · React 19  
> **State:** Zustand · React Query · React Hook Form + Zod  
> **UI:** Framer Motion · Lucide Icons · Sonner (toasts) · Recharts  
> **Backend:** NestJS API at `NEXT_PUBLIC_API_URL`

---

## How to Use This Document

Each prompt below is a **self-contained instruction** you can give to an AI coding assistant. They are ordered by dependency — complete earlier segments before later ones. Each prompt references:

- **FR IDs** from `FUNCTIONAL_REQUIREMENTS.md`
- **Feature IDs** from `FEATURE_LIST.md` (C-xx = Customer, A-xx = Admin, W-xx = Website)
- **Roadmap Phase** from `ROADMAP.md`

---

## Existing Frontend Structure

```
src/
├── app/
│   ├── page.tsx                    # Landing page (Home)
│   ├── layout.tsx                  # Root layout
│   ├── providers.tsx               # React Query + global providers
│   ├── globals.css                 # TailwindCSS globals
│   ├── services/                   # Service detail pages (individual-tax, corporate-tax, nrb-tax, etc.)
│   ├── cookie-policy/              # Cookie policy page
│   ├── (portal)/portal/            # Customer portal (login, register, dashboard, documents, filings)
│   ├── (admin)/admin/              # Admin panel (login, dashboard)
│   └── api/                        # Next.js API routes
├── components/
│   ├── [Landing].tsx               # Hero, Navbar, Services, Pricing, FAQ, Team, About, etc.
│   ├── portal/layout/              # PortalSidebar, PortalTopbar, PortalBottomNav
│   └── shared/                     # EmptyState, Skeletons, StatusBadge
├── content/
│   ├── en/                         # English JSON content (20 files)
│   └── bn/                         # Bangla JSON content (15 files)
├── lib/
│   ├── api/                        # API clients (auth, admin, documents, filings, client)
│   ├── store/                      # Zustand stores
│   ├── hooks/                      # Custom hooks
│   ├── constants.ts
│   ├── content.ts                  # Content loader utility
│   └── utils.ts
└── middleware.ts                   # Auth middleware
```

**Backend modules already built:** auth, profile, documents, filings, payments, consultations, messages, notifications, tickets, cms, seo, analytics, settings, upload

---

## SEGMENT 1 — Foundation & Design System

> **Phase:** 0 | **Priority:** P0 | **Estimated:** 8-10h

### Prompt 1.1 — Design System & Theme Setup

```
Set up a comprehensive design system for Anchor Point Advising, a Bangladeshi tax consulting platform.

CURRENT STATE:
- Next.js 16 with App Router, TailwindCSS 4, globals.css exists
- Brand colors are dark green/emerald tones (check existing components for exact values)
- Bilingual: English + Bangla

TASKS:
1. Define a complete design token system in globals.css using CSS custom properties:
   - Colors: primary (emerald/green), secondary, accent, neutral, semantic (success, warning, error, info)
   - Typography: font sizes scale, font weights, line heights
   - Spacing scale, border radius scale, shadow scale
   - Dark mode variables (prepare for future X-02)

2. Create `src/lib/cn.ts` - a utility combining clsx + tailwind-merge (we already have both packages)

3. Create `src/components/ui/` directory with these base components:
   - Button (variants: primary, secondary, outline, ghost, danger; sizes: sm, md, lg; loading state)
   - Input (with label, error state, helper text, left/right icons)
   - Select (native select with consistent styling)
   - Textarea (with character count)
   - Badge (variants: success, warning, error, info, neutral)
   - Card (with optional header, footer)
   - Modal/Dialog (with overlay, close button, sizes)
   - Spinner/Loading
   - Avatar (with fallback initials)

4. All components must:
   - Be TypeScript with proper interfaces
   - Support `className` prop for extension
   - Use forwardRef where appropriate
   - Use the design tokens, not hardcoded colors
   - Be accessible (proper aria attributes, keyboard navigation for modals)

REFS: X-01, FR-USR-004 (bilingual prep)
```

### Prompt 1.2 — Layout Components

```
Create the shared layout components for the Anchor Point platform.

EXISTING:
- Portal layout exists at src/components/portal/layout/ (PortalSidebar, PortalTopbar, PortalBottomNav)
- Admin layout exists at src/app/(admin)/admin/layout.tsx

TASKS:
1. Create `src/components/ui/Table.tsx` — reusable data table with:
   - Column definitions (header, accessor, render, sortable, width)
   - Built-in sorting (client-side)
   - Empty state
   - Loading skeletons
   - Responsive: horizontal scroll on mobile

2. Create `src/components/ui/Pagination.tsx`:
   - Page numbers with prev/next
   - "Showing X-Y of Z" text
   - Page size selector (10, 25, 50)
   - Works with React Query pagination

3. Create `src/components/ui/Tabs.tsx`:
   - Horizontal tab navigation
   - Active state animation (underline slide)
   - Support URL-based tab state (searchParams)

4. Create `src/components/ui/Breadcrumb.tsx`:
   - Auto-generate from pathname
   - Support custom labels
   - Truncate on mobile

5. Create `src/components/ui/ConfirmDialog.tsx`:
   - Reusable confirmation modal
   - Danger variant for destructive actions
   - Cancel/Confirm buttons

6. Create `src/components/ui/FileUpload.tsx`:
   - Drag-and-drop zone (react-dropzone already installed)
   - File type and size validation
   - Preview thumbnails for images
   - Progress bar per file
   - Remove file button
   - Props for maxFiles, maxSize, acceptedTypes

REFS: FR-DOC-001, FR-DOC-008, X-01
```

---

## SEGMENT 2 — Authentication & Registration

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 12-16h | **Depends on:** Segment 1

### Prompt 2.1 — Auth Infrastructure

```
Set up the authentication infrastructure for the customer portal.

EXISTING:
- src/lib/api/auth.api.ts exists (review and extend)
- src/lib/api/client.ts exists (Axios instance with interceptors)
- src/lib/store/ has Zustand stores
- src/middleware.ts exists (review and extend)
- Backend auth endpoints: POST /auth/register, POST /auth/login, POST /auth/refresh, POST /auth/logout, POST /auth/forgot-password, POST /auth/reset-password, POST /auth/verify-email

TASKS:
1. Review and enhance `src/lib/api/client.ts`:
   - Ensure 401 interceptor attempts token refresh before failing
   - Queue failed requests during refresh
   - Redirect to login on refresh failure

2. Create/update `src/lib/store/authStore.ts` (Zustand):
   - State: user (id, email, name, role, emailVerified, phoneVerified), isAuthenticated, isLoading
   - Actions: login, register, logout, refreshUser, setUser
   - Persist auth state (but NOT tokens — those are httpOnly cookies)

3. Create `src/lib/api/auth.api.ts` functions:
   - register(data) — email, password, name, phone
   - login(data) — email, password
   - logout()
   - forgotPassword(email)
   - resetPassword(token, newPassword)
   - verifyEmail(token)
   - refreshToken()
   - getMe() — get current user profile

4. Update `src/middleware.ts`:
   - Protect /portal/* routes (redirect to /portal/login if no auth)
   - Protect /admin/* routes (redirect to /admin/login if no auth)
   - Allow public routes: /, /services/*, /cookie-policy, /portal/login, /portal/register
   - Check registration mode for /portal/register (OPEN/INVITE_ONLY/DISABLED)

REFS: FR-AUTH-001, FR-AUTH-006, FR-AUTH-009, C-07
```

### Prompt 2.2 — Auth Pages

```
Build the customer authentication pages.

EXISTING:
- src/app/(portal)/portal/login/page.tsx exists (review and rebuild if needed)
- src/app/(portal)/portal/register/page.tsx exists (review and rebuild if needed)
- UI components from Segment 1
- Auth store and API from Prompt 2.1
- Brand: emerald/green theme, bilingual (en/bn)

TASKS:
1. Login Page (`/portal/login`):
   - Email + password form with validation (react-hook-form + zod)
   - "Remember me" checkbox
   - "Forgot password?" link
   - "Don't have an account? Register" link
   - Error handling with inline messages + toast
   - Loading state on submit
   - Redirect to dashboard on success
   - Clean, modern card design centered on page

2. Register Page (`/portal/register`):
   - Full name, email, phone (+880), password, confirm password
   - Phone input with BD country code prefix
   - Password strength indicator
   - Terms & conditions checkbox
   - Handle registration gate modes:
     - OPEN: normal form
     - INVITE_ONLY: requires invite token (from URL query param)
     - DISABLED: show "Registration is currently closed" message
   - On success: redirect to email verification pending page

3. Forgot Password Page (`/portal/forgot-password`):
   - Email input → sends reset link
   - Success state: "Check your email" message

4. Reset Password Page (`/portal/reset-password`):
   - Token from URL params
   - New password + confirm password
   - Success → redirect to login

5. Email Verification Page (`/portal/verify-email`):
   - Token from URL params → auto-verify on mount
   - Success/error states
   - "Resend verification" button

DESIGN: Professional, trustworthy (it's a financial platform). Use the brand green as
accent. Subtle animations with framer-motion on form transitions.

REFS: FR-AUTH-001 to FR-AUTH-005, FR-AUTH-009, C-01, C-04, C-05
```

---

## SEGMENT 3 — Customer Dashboard

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 10-14h | **Depends on:** Segment 2

### Prompt 3.1 — Dashboard Overview

```
Build the customer dashboard at /portal/dashboard.

EXISTING:
- src/app/(portal)/portal/dashboard/page.tsx exists (review and rebuild)
- Portal layout with sidebar, topbar, bottom nav already exists
- API clients at src/lib/api/

TASKS:
1. Dashboard KPI Cards Row:
   - Active Filing Status (with current stage name + colored dot)
   - Documents (uploaded count / required count)
   - Next Deadline (date + countdown "X days left")
   - Pending Payments (count or "All clear ✓")
   - Each card: icon, value, label, subtle hover effect

2. Filing Progress Tracker:
   - Horizontal stepper showing stages: Initiated → Documents Pending → Documents Received → Under Preparation → Review Ready → Customer Approved → E-Filed → Acknowledged → Completed
   - Current stage highlighted, completed stages with checkmarks
   - Date below each completed stage
   - If no active filing: show "Start Your Tax Filing" CTA card

3. Quick Actions Grid:
   - Upload Document, Book Consultation, View Payments, Contact Support
   - Icon + label cards with hover animations
   - Link to respective pages

4. Recent Activity Feed:
   - Last 5 notifications/events (document reviewed, status changed, etc.)
   - Timestamp, type icon, description
   - "View All" link to notifications page

5. Upcoming Deadlines:
   - List of approaching deadlines with countdown
   - Color coding: green (>30 days), yellow (7-30), red (<7 days)

Use React Query for all data fetching. Loading skeleton states for each section.
Mobile responsive: stack cards vertically, stepper becomes vertical on mobile.

REFS: FR-FIL-002, FR-FIL-006, C-08, C-09, C-10, C-11, C-12
```

---

## SEGMENT 4 — Document Management

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 14-18h | **Depends on:** Segment 3

### Prompt 4.1 — Document Upload & List

```
Build the document management system for customers at /portal/documents.

EXISTING:
- src/app/(portal)/portal/documents/page.tsx exists (review and extend)
- src/lib/api/documents.api.ts exists (review and extend)
- react-dropzone is installed
- FileUpload UI component from Segment 1

BACKEND ENDPOINTS:
- POST /documents/upload (multipart, fields: file, category, filingId)
- GET /documents/my (query: category, status, filingId, page, limit)
- GET /documents/:id
- GET /documents/:id/download (returns presigned URL)
- DELETE /documents/:id (only PENDING status)

TASKS:
1. Document Upload Section:
   - Upload Checklist: dynamic list based on active filing's service type
     - Individual: NID, TIN Certificate, Salary Certificate, Bank Statement
     - Corporate: Trade License, TIN, Audited Accounts, Bank Statement
     - NRB: Passport, TIN, Property Documents, Bank Statement
   - Each checklist item shows: ⬜ Not uploaded / ⏳ Pending / ✅ Accepted / ❌ Rejected
   - Click checklist item → opens upload modal pre-selecting that category
   - Drag-and-drop zone for quick upload (must select category after drop)
   - File validation: PDF, JPG, JPEG, PNG, DOCX only, max 10MB
   - Upload progress bar per file
   - Bulk upload: up to 10 files at once

2. Document List:
   - Table/card view toggle
   - Columns: filename, category, status (color-coded badge), upload date, size, actions
   - Filters: category dropdown, status dropdown
   - Sort by: date, name, category
   - Pagination
   - Actions: preview (images in lightbox, PDFs in iframe), download, delete (only PENDING)
   - Rejected documents show rejection reason prominently with "Re-upload" button

3. Document Preview Modal:
   - Images: lightbox with zoom
   - PDFs: iframe viewer
   - Other: "Download to view" with download button

REFS: FR-DOC-001 to FR-DOC-008, C-13 to C-21
```

---

## SEGMENT 5 — Tax Filing Workspace

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 10-12h | **Depends on:** Segment 4

### Prompt 5.1 — Filing Pages

```
Build the tax filing workspace at /portal/filings.

EXISTING:
- src/app/(portal)/portal/filings/page.tsx exists
- src/lib/api/filings.api.ts exists

BACKEND ENDPOINTS:
- POST /filings (body: assessmentYear, serviceType)
- GET /filings/my (list customer's filings)
- GET /filings/:id (detail with status history)
- GET /filings/:id/return-preview (when status REVIEW_READY)
- POST /filings/:id/approve (customer approves return)
- POST /filings/:id/dispute (customer disputes with reason)

TASKS:
1. Filing List Page (/portal/filings):
   - List all filings as cards (not table — more visual)
   - Each card: assessment year, service type, current status (badge), progress bar mini-preview
   - "Start New Filing" button → modal:
     - Select assessment year (dropdown)
     - Select service type (Individual/Corporate/NRB)
     - One filing per year constraint (show error if exists)
   - If no filings: empty state with illustration + CTA

2. Filing Detail Page (/portal/filings/[id]):
   - Full progress stepper (same as dashboard but expanded)
   - Status History Timeline: each status change with date, who changed it, notes
   - Documents Section: linked documents for this filing with upload shortcut
   - Return Preview Section (visible only when REVIEW_READY):
     - Read-only summary: Total Income, Tax Payable, Tax Already Paid, Net Payable/Refund
     - "Approve & Proceed" and "Dispute" buttons
     - Dispute opens textarea modal for reason
   - Download Section (visible when E_FILED or later):
     - Download Filed Return PDF
     - Download Acknowledgement Receipt
   - Payment info linked to this filing

3. Year-over-Year Comparison (P2 — prepare the route, minimal implementation):
   - Compare key figures across years in a table
   - Bar chart using Recharts

REFS: FR-FIL-001 to FR-FIL-007, C-49 to C-54
```

---

## SEGMENT 6 — Payments & Billing

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 10-14h | **Depends on:** Segment 3

### Prompt 6.1 — Payment Flow & History

```
Build the payment system for customers.

BACKEND ENDPOINTS:
- POST /payments/initiate (body: serviceType, filingId, paymentMethod, couponCode?)
- GET /payments/my (list with pagination)
- GET /payments/:id
- GET /payments/:id/invoice-download
- POST /payments/:id/refund-request (body: reason)
- POST /payments/validate-coupon (body: code)

TASKS:
1. Payment/Checkout Page (/portal/payments/checkout):
   - Service selection (if not coming from a filing)
   - Price display with breakdown
   - Promo code input with real-time validation (valid/invalid/expired feedback)
   - Payment method selection: bKash, Nagad, Rocket, Card
   - Each method shows its logo
   - "Pay Now" → redirects to gateway (handle in backend)
   - Handle return from gateway: success/failure pages

2. Payment Success Page (/portal/payments/success):
   - Confirmation animation (checkmark)
   - Transaction details summary
   - "Download Invoice" button
   - "Go to Dashboard" / "Go to Filing" CTAs

3. Payment Failure Page (/portal/payments/failed):
   - Error message
   - "Try Again" button
   - "Contact Support" link

4. Payment History Page (/portal/payments):
   - Table: date, service, amount (BDT), method, status (badge), invoice
   - Total spent summary at top
   - Filter by date range, status
   - Each row: "Download Invoice" button
   - Refund request button (only for COMPLETED payments)
   - Refund request modal: reason textarea (min 20 chars)

REFS: FR-PAY-001 to FR-PAY-007, C-23 to C-30
```

---

## SEGMENT 7 — Profile & Settings

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 6-8h | **Depends on:** Segment 2

### Prompt 7.1 — Profile Management

```
Build the customer profile and settings pages.

BACKEND ENDPOINTS:
- GET /profile/me
- PATCH /profile/me (body: partial profile fields)
- POST /profile/change-password (body: currentPassword, newPassword)
- PATCH /profile/language (body: language)
- PATCH /profile/notification-preferences (body: preferences object)

TASKS:
1. Profile Page (/portal/profile):
   - Tabbed layout: Personal Info | Taxpayer Info | Security | Preferences

   - Personal Info Tab:
     - Avatar upload (or initials fallback)
     - Full name, email (read-only, change requires re-verification), phone
     - Phone shows masked, "Change" button triggers OTP flow
     - Address, district
     - NID (masked, show last 4), date of birth
     - Save button per section

   - Taxpayer Info Tab:
     - TIN (masked, show last 4)
     - Tax zone/circle
     - Income sources (multi-select checkboxes: salary, business, freelance, rental, investment, other)
     - Taxpayer category (individual, company, partnership)
     - Employer/business name

   - Security Tab:
     - Change password form (current, new, confirm new)
     - Password strength indicator
     - Active sessions list (future P2)
     - 2FA toggle (future — show "Coming Soon" badge)

   - Preferences Tab:
     - Language switcher (English/Bangla) with instant preview
     - Notification toggles by category:
       - Filing Updates (email, SMS)
       - Payment Receipts (email, SMS)
       - Deadline Reminders (email, SMS)
       - Promotions (email, SMS)
     - Note: "Security alerts cannot be disabled"

REFS: FR-USR-001 to FR-USR-005, C-42 to C-48
```

---

## SEGMENT 8 — Consultation Booking

> **Phase:** 2 | **Priority:** P1 | **Estimated:** 12-16h | **Depends on:** Segment 6

### Prompt 8.1 — Booking System

```
Build the consultation booking system for customers.

EXISTING: react-calendly is installed but we're building a custom system.

BACKEND ENDPOINTS:
- GET /consultations/available-slots?date=YYYY-MM-DD
- POST /consultations/book (body: date, slotId, medium, paymentMethod)
- GET /consultations/my (list)
- GET /consultations/:id
- PATCH /consultations/:id/reschedule (body: newDate, newSlotId)
- POST /consultations/:id/cancel

TASKS:
1. Booking Page (/portal/consultations/book):
   - Calendar month view showing available dates (highlighted green)
   - Click date → show available time slots as selectable chips
   - Select medium: Phone / Video / In-Person (radio cards with icons)
   - Payment: BDT 300 consultation fee
   - Summary before confirmation
   - On payment success: show confirmation with details

2. Consultation List (/portal/consultations):
   - Tabs: Upcoming | Past | Cancelled
   - Each card: date, time, medium, advisor name, status
   - Upcoming: "Reschedule" and "Cancel" action buttons
   - Reschedule modal (same slot picker)
   - Cancel → confirm dialog with policy note (24h+ = full refund)
   - Past: show advisor notes if available
   - Video: "Join Meeting" link/button (Google Meet)

3. Single Consultation Detail (/portal/consultations/[id]):
   - Full details card
   - Meeting link (if video)
   - Advisor info
   - Session notes (from advisor, read-only)
   - Follow-up actions list
   - Status timeline

REFS: FR-CON-001 to FR-CON-006, C-31 to C-36
```

---

## SEGMENT 9 — Communication & Support

> **Phase:** 2 | **Priority:** P1 | **Estimated:** 16-20h | **Depends on:** Segment 3

### Prompt 9.1 — Messaging & Tickets

```
Build the communication features for customers.

EXISTING: socket.io-client is installed

BACKEND ENDPOINTS:
- GET /messages/conversations (list)
- GET /messages/conversations/:id/messages (paginated)
- POST /messages/conversations/:id/send (body: content, attachmentId?)
- WebSocket: ws://API_URL/messages (events: newMessage, typing, read)
- POST /tickets (body: subject, category, description, attachment?)
- GET /tickets/my (list)
- GET /tickets/:id (with replies)
- POST /tickets/:id/reply (body: content, attachment?)

TASKS:
1. Messages Page (/portal/messages):
   - Sidebar: conversation list (advisor name, last message preview, unread badge, timestamp)
   - Main area: message thread
   - Messages: sender avatar, content, timestamp, read receipts (✓✓)
   - Typing indicator ("Advisor is typing...")
   - File attachment button (S3 upload, max 5MB)
   - Image attachments: inline preview. PDF: download link
   - Real-time via WebSocket (socket.io-client)
   - Mobile: full-screen conversation list → tap → full-screen thread

2. Notification Center:
   - Bell icon in PortalTopbar with unread count badge
   - Click → dropdown with last 10 notifications
   - Each: type icon, message, timestamp, read/unread style
   - "Mark all as read" button
   - "View All" → /portal/notifications (full list, paginated)
   - Click notification → navigate to relevant page
   - Real-time updates via WebSocket

3. Support Tickets Page (/portal/tickets):
   - "Create Ticket" button → modal/page:
     - Subject, category (Billing, Technical, Tax Query, Document, General), description
     - Optional file attachment
   - Ticket list: subject, category, status (badge), created date
   - Click → ticket detail with threaded replies
   - Reply textarea + attachment
   - Status visible: Open, In Progress, Waiting on Customer, Resolved, Closed

REFS: FR-MSG-001 to FR-MSG-002, FR-NTF-001, FR-TKT-001 to FR-TKT-003, C-37 to C-41
```

---

## SEGMENT 10 — Admin Panel Core

> **Phase:** 1 | **Priority:** P0 | **Estimated:** 20-28h | **Depends on:** Segment 1

### Prompt 10.1 — Admin Layout & Dashboard

```
Build the admin panel layout and dashboard.

EXISTING:
- src/app/(admin)/admin/layout.tsx exists (review and enhance)
- src/app/(admin)/admin/dashboard/ exists
- src/app/(admin)/admin/login/ exists
- src/lib/api/admin.api.ts exists

TASKS:
1. Admin Layout:
   - Collapsible sidebar with sections:
     - Dashboard, Customers, Documents, Filings, Payments, Consultations,
       Messages, Tickets, CMS, SEO, Analytics, Settings, Staff, Audit Log
   - Each item: icon + label, active state, badge for pending counts
   - Top bar: admin name + avatar, notification bell, quick search
   - Breadcrumbs below topbar
   - Responsive: sidebar becomes sheet/drawer on mobile

2. Admin Login Page (/admin/login):
   - Email + password form
   - 2FA step (TOTP input — 6 digits) — prepare UI, backend P2
   - Branded with admin-specific styling (darker theme)

3. Admin Dashboard (/admin/dashboard):
   - KPI Cards (6): Total Customers, Active Filings, Revenue (MTD), Revenue (YTD), Pending Documents, Open Tickets
   - Each card: icon, value, % change vs previous period (green/red arrow)
   - Revenue Chart: bar chart last 12 months (Recharts)
   - Recent Activity Feed: last 10 admin actions from audit log
   - Deadline Alert Panel: filings approaching deadline (sorted by urgency)
   - Quick Stats Row: documents reviewed today, filings completed this week

REFS: FR-RPT-001, A-01, A-06, Roadmap 1.9
```

### Prompt 10.2 — Customer & Document Management (Admin)

```
Build admin pages for customer and document management.

TASKS:
1. Customer List (/admin/customers):
   - Data table: name, email, phone, status (badge), filings count, joined date
   - Search: by name, email, phone, TIN, NID
   - Filters: status (Active/Inactive/Suspended/VIP), has active filing, date range
   - Sort: name, date joined, filings count
   - Bulk actions: export CSV, send email, change status
   - Click row → customer detail

2. Customer 360° Detail (/admin/customers/[id]):
   - Header: avatar, name, status badge, email, phone, quick actions
   - Tabbed sections:
     - Overview: personal info, taxpayer info, onboarding status
     - Documents: all documents with review actions inline
     - Filings: filing history with status management
     - Payments: payment history
     - Messages: conversation thread
     - Activity Log: all events for this customer
     - Notes: internal admin notes (CRUD)
   - "Assign Advisor" button with advisor dropdown (shows workload count)

3. Document Review Queue (/admin/documents):
   - Table: customer name, category, filename, thumbnail, upload date, filing deadline, status
   - Default filter: PENDING status
   - Sort by: oldest first (default), customer name, category
   - Click → document preview + action panel:
     - "Approve" button (one-click)
     - "Reject" → reason textarea (min 10 chars)
     - "Request Re-upload" → instruction textarea
   - Batch actions: approve multiple

REFS: FR-DOC-010, FR-DOC-011, A-13 to A-26, Roadmap 1.9
```

### Prompt 10.3 — Filing, Payment & Staff Management (Admin)

```
Build admin pages for filings, payments, and staff.

TASKS:
1. Filing Queue (/admin/filings):
   - Table: customer, assessment year, service type, status (badge), advisor, deadline, progress
   - Filters: status, service type, advisor, year, deadline range
   - Click → filing detail with status management
   - Status update: dropdown with valid next statuses + note field
   - Bulk status update for multiple filings
   - "Assign Advisor" action per filing (dropdown with workload indicators)
   - Upload return/acknowledgement PDFs (when status appropriate)
   - Deadline tracker view: sorted by days remaining, color-coded urgency

2. Payment Overview (/admin/payments):
   - Table: customer, service, amount (BDT), method, status, date, invoice
   - Filters: status, method, date range, amount range
   - Revenue summary cards at top: today, this week, this month, this year
   - Refund queue tab: pending refund requests → approve (full/partial) or reject
   - Export CSV/Excel

3. Staff Management (/admin/staff):
   - Table: name, email, role, status, last login
   - Create staff: name, email, role (TAX_ADVISOR, OPERATIONS, SUPPORT, SUPER_ADMIN)
   - Edit: update role, personal info
   - Deactivate/reactivate toggle (not delete)
   - Cannot deactivate own account

4. Settings Page (/admin/settings):
   - Tabs: Company Info | Tax Season | Registration | Payment Gateways
   - Company Info: name, logo upload, address, phone, email, social links
   - Tax Season: current assessment year, filing deadline date
   - Registration Gate:
     - Radio: Open / Invite Only / Disabled
     - Invite Only: generate invite links table (link, uses, expiry, status, revoke)
     - Confirmation dialog on mode switch
   - Payment Gateways: API key fields (masked), enable/disable toggle per gateway

REFS: FR-FIL-003, FR-FIL-008, FR-PAY-007, FR-SYS-001 to FR-SYS-005, A-27 to A-40, A-66 to A-69
```

---

## SEGMENT 11 — Admin Communication & Tickets

> **Phase:** 2 | **Priority:** P1 | **Estimated:** 10-14h | **Depends on:** Segment 10

### Prompt 11.1 — Admin Messaging, Tickets & Consultations

```
Build admin communication management pages.

TASKS:
1. Message Center (/admin/messages):
   - Sidebar: all conversations (customer name, last message, unread badge)
   - Search conversations by customer name
   - Message thread with reply functionality
   - File sharing capabilities
   - Real-time via WebSocket

2. Ticket Management (/admin/tickets):
   - Table: subject, customer, category, priority (badge), status, assigned to, SLA timer
   - Filters: status, category, priority, assigned agent
   - Click → ticket detail:
     - Threaded conversation (customer + admin replies)
     - Admin reply box with "Internal Note" toggle (not visible to customer)
     - Assign to agent dropdown
     - Change priority and status
     - File attachments

3. Broadcast Notifications (/admin/broadcasts):
   - Create broadcast: title, body, optional link
   - Target: All customers, or filter by status/filing status/year
   - Channels: in-app + email toggle + SMS toggle
   - Schedule: send now or schedule for later
   - Broadcast history with delivery report

4. Consultation Management (/admin/consultations):
   - Table: customer, advisor, date/time, medium, status
   - Advisor schedule management: working hours per day, holidays, blocked slots
   - Admin reschedule/cancel with customer notification
   - Post-consultation notes form
   - Analytics: bookings per week, completion rate

REFS: FR-MSG-003, FR-TKT-002, FR-CON-001 to FR-CON-006, A-41 to A-51
```

---

## SEGMENT 12 — CMS & SEO Admin

> **Phase:** 3 | **Priority:** P1 | **Estimated:** 14-18h | **Depends on:** Segment 10

### Prompt 12.1 — CMS Editor & SEO Management

```
Build the CMS and SEO management admin pages.

EXISTING:
- Content JSON files exist in src/content/en/ and src/content/bn/ (20 + 15 files)
- These are the fallback if no CMS database record exists

BACKEND ENDPOINTS:
- GET/PUT /cms/sections/:section/:locale
- GET/POST/PUT/DELETE /cms/testimonials
- GET/PUT /seo/:page/:locale
- GET /seo (list all)
- DELETE /seo/:page/:locale

TASKS:
1. CMS Editor (/admin/cms):
   - Section tabs: Hero, Services, About, Team, Pricing, FAQ, Testimonials, Video, Stats
   - Each section: JSON-aware form (dynamically render fields from the JSON structure)
   - Locale switcher: en / bn (edit each locale separately)
   - Live preview panel (side-by-side on desktop)
   - Save button → API update + frontend cache invalidation
   - Testimonial Management:
     - Card grid: name, quote preview, rating stars, photo, visibility toggle
     - Drag-and-drop reorder (dnd-kit already installed)
     - Add/edit modal: name, designation, photo upload, quote (en + bn), rating 1-5
     - Toggle visibility without deleting
   - Announcement Banner editor:
     - Text, link, background color picker, start/end date
     - Preview banner, activate/deactivate

2. SEO Management (/admin/seo):
   - Table: page name, locale, meta title, description, last updated, status indicator
   - Filter by locale
   - Pages with missing SEO: warning indicator
   - Character counts: title (max 60), description (max 160) with color coding
   - Click → SEO edit form:
     - Fields: meta title, meta description, OG title, OG description, OG image, canonical URL, robots directive
     - JSON-LD structured data editor (code editor)
     - Google Search Preview: blue title, green URL, grey description
     - Save → cache invalidation

3. Update Public Website:
   - Modify landing page components to fetch from CMS API with fallback to JSON files
   - Use React Query with long stale time for CMS data
   - SSR: fetch SEO data in server components for proper <head> rendering

REFS: FR-CMS-001 to FR-CMS-003, FR-SEO-001 to FR-SEO-005, A-52 to A-60
```

---

## SEGMENT 13 — Analytics & Reporting

> **Phase:** 3 | **Priority:** P1 | **Estimated:** 10-14h | **Depends on:** Segment 10

### Prompt 13.1 — Admin Analytics Dashboard

```
Build the analytics and reporting pages for admin.

EXISTING: recharts is installed

BACKEND ENDPOINTS:
- GET /analytics/revenue?from=&to=&groupBy=month
- GET /analytics/customers?from=&to=
- GET /analytics/filings?from=&to=
- GET /analytics/consultations?from=&to=
- GET /analytics/export?entity=customers|payments|filings&format=csv|xlsx&filters=...

TASKS:
1. Revenue Analytics (/admin/analytics/revenue):
   - Date range filter (preset: 7d, 30d, 90d, 1y, custom)
   - Bar chart: revenue by month (last 12 months)
   - Pie chart: revenue by service type
   - Stack chart: revenue by payment method
   - Summary cards: total, average monthly, highest month
   - Export as CSV/PDF

2. Customer Growth (/admin/analytics/customers):
   - Line chart: new signups per week/month
   - Cumulative total line (dual axis)
   - Date range filter
   - Breakdown: by registration method (email, phone, Google)

3. Filing Performance (/admin/analytics/filings):
   - Pie chart: filings by status
   - Average processing time card (days: INITIATED → COMPLETED)
   - Per-advisor table: filings count, avg time, completion rate
   - Deadline compliance rate donut chart
   - Filing season comparison bars (year over year)

4. Audit Log Viewer (/admin/audit-log):
   - Table: timestamp, admin name, action, entity type, entity ID, IP address
   - Filters: admin user, action type, entity type, date range
   - Search by entity ID or description
   - Export CSV
   - Read-only: no edit/delete actions

5. Data Export Hub (/admin/export):
   - Entity selector: Customers, Payments, Filings, Invoices
   - Format: CSV, Excel
   - Date range and status filters
   - "Generate Export" → background job → download link (or direct download for small sets)

REFS: FR-RPT-001 to FR-RPT-005, FR-SYS-004, A-07 to A-12, A-61 to A-65
```

---

## SEGMENT 14 — Public Website Enhancements

> **Phase:** 3-4 | **Priority:** P1-P2 | **Estimated:** 12-16h | **Depends on:** Segment 12

### Prompt 14.1 — Website Upgrades

```
Enhance the public-facing website.

EXISTING:
- Landing page with all sections (Hero, Services, About, Stats, Team, Consultation, Pricing, FAQ, Footer)
- Service detail pages (5 services)
- Bilingual content (en/bn)
- Navbar, WhatsApp button, Cookie consent

TASKS:
1. Add Login/Register to Navbar:
   - "Login" and "Register" buttons in navbar (right side)
   - Respect registration gate mode (hide Register when INVITE_ONLY or DISABLED)
   - When logged in: show user avatar dropdown (Dashboard, Profile, Logout)
   - Mobile: add to hamburger menu

2. Announcement Banner Component:
   - Top of page, above navbar
   - Fetch from CMS API
   - Dismissible (cookie remembers dismissal)
   - Auto-hide after end date

3. Dynamic Testimonials:
   - Fetch from CMS/database instead of static JSON
   - Fallback to JSON if API fails

4. Tax Calculator Widget (/tools/tax-calculator):
   - Input fields: annual income, investment amount, source type
   - Calculate estimated tax based on BD tax slabs
   - Show breakdown: taxable income, applicable rates, investment rebate, net tax
   - "Get Professional Help" CTA → leads to registration or consultation booking
   - SEO optimized landing page

5. Blog/Resource Center (/blog) — skeleton:
   - Blog list page with article cards (title, excerpt, date, category)
   - Blog detail page (/blog/[slug])
   - Categories: Tax Tips, News, Guides
   - Prepare routes and layout (content management in Segment 12)

6. Enhanced Language Switcher:
   - URL-based locale routing (/en/..., /bn/...)
   - Persistent preference via cookie
   - Proper hreflang tags for SEO

REFS: W-01 to W-10, FR-CMS-003, Roadmap Phase 4
```

---

## SEGMENT 15 — Onboarding & Polish

> **Phase:** 2 | **Priority:** P1 | **Estimated:** 8-10h | **Depends on:** Segment 3

### Prompt 15.1 — Onboarding Wizard & UX Polish

```
Build the customer onboarding wizard and polish the overall UX.

TASKS:
1. Onboarding Wizard (/portal/onboarding):
   - Triggered after first registration (redirect from dashboard if not completed)
   - Multi-step form with progress indicator:
     - Step 1: Full name, NID (optional), date of birth
     - Step 2: TIN (optional), tax zone/circle (optional)
     - Step 3: Income sources (multi-select: salary, business, freelance, rental, investment, other)
     - Step 4: Taxpayer category (individual, company, partnership)
   - Each step skippable ("Skip for now" link)
   - Progress saved on each step (PATCH to profile API)
   - Back/Next navigation with validation
   - Final step: "Complete Setup" → animated success → redirect to dashboard
   - "Complete Onboarding" reminder card on dashboard if incomplete

2. Global Loading State:
   - Page transition loading bar (top of page, like YouTube)
   - Consistent skeleton loading patterns across all pages

3. Error Boundary:
   - Global error boundary with friendly error page
   - "Retry" and "Go Home" actions
   - Report error to Sentry (future)

4. Toast System:
   - Consistent toast usage across all actions (sonner already installed)
   - Success, error, warning, info variants
   - Position: bottom-right

5. 404 Page:
   - Custom not-found page with brand styling
   - "Go Home" and "Contact Support" links

REFS: FR-USR-001, C-06, X-01, X-06
```

---

## Dependency Graph

```
Segment 1 (Foundation)
    │
    ├──► Segment 2 (Auth) ──► Segment 3 (Dashboard) ──► Segment 4 (Documents)
    │         │                      │                         │
    │         │                      ├──► Segment 5 (Filings) ◄┘
    │         │                      │
    │         ├──► Segment 7 (Profile)
    │         │
    │         └──► Segment 15 (Onboarding)
    │
    ├──► Segment 6 (Payments) ──► Segment 8 (Consultations)
    │
    ├──► Segment 9 (Communication) ──── requires Segment 3
    │
    ├──► Segment 10 (Admin Core) ──► Segment 11 (Admin Comms)
    │         │
    │         ├──► Segment 12 (CMS/SEO) ──► Segment 14 (Public Website)
    │         │
    │         └──► Segment 13 (Analytics)
    │
    └──► Segment 14 also depends on Segment 12
```

---

## Quick Reference — Technology Choices

| Concern | Solution |
|---------|----------|
| Styling | TailwindCSS 4 + custom design tokens |
| State Management | Zustand (auth, UI state) |
| Server State | React Query (API data) |
| Forms | React Hook Form + Zod schemas |
| Animations | Framer Motion |
| Charts | Recharts |
| Icons | Lucide React |
| Toasts | Sonner |
| File Upload | React Dropzone |
| Drag & Drop | dnd-kit |
| Real-time | Socket.IO Client |
| HTTP | Axios (with interceptors) |
| Dates | date-fns |
