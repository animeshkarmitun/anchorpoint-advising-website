# Anchor Point Advising — Comprehensive Testing Plan

> **Stack:** NestJS · Jest · Supertest · Prisma · PostgreSQL  
> **Philosophy:** Test the contract, not the implementation. Fast unit tests first, slower E2E tests for critical paths.

---

## Table of Contents

1. [Testing Pyramid & Strategy](#1-testing-pyramid--strategy)
2. [Directory Structure & Conventions](#2-directory-structure--conventions)
3. [Quick-Start Commands](#3-quick-start-commands)
4. [Unit Tests](#4-unit-tests)
5. [Integration Tests](#5-integration-tests)
6. [Regression Tests](#6-regression-tests)
7. [End-to-End (E2E) Tests](#7-end-to-end-e2e-tests)
8. [Test Database Setup](#8-test-database-setup)
9. [CI/CD Integration](#9-cicd-integration)
10. [Coverage Targets](#10-coverage-targets)
11. [Professional Best Practices](#11-professional-best-practices)

---

## 1. Testing Pyramid & Strategy

```
         ┌─────────┐
         │  E2E    │  ← Few: critical user journeys (login → file → pay)
         ├─────────┤
         │ Integr. │  ← Medium: service + database interactions
         ├─────────┤
         │  Unit   │  ← Many: pure business logic, validators, guards
         └─────────┘
```

| Layer         | What It Tests                                | Speed    | Count   |
|---------------|----------------------------------------------|----------|---------|
| **Unit**      | Individual functions, services (mocked deps) | < 1s     | ~200+   |
| **Integration** | Service ↔ real DB, module wiring           | 2-10s    | ~80     |
| **Regression** | Previously broken scenarios (bugfix proofs) | < 1s     | Grows   |
| **E2E**       | HTTP request → response (full stack)         | 5-30s    | ~30     |

---

## 2. Directory Structure & Conventions

```
backend/
├── src/
│   ├── auth/
│   │   ├── auth.service.ts
│   │   ├── auth.service.spec.ts          ← Unit test (co-located)
│   │   ├── auth.controller.spec.ts       ← Unit test (co-located)
│   │   └── guards/
│   │       └── jwt-auth.guard.spec.ts
│   ├── payments/
│   │   ├── payments.service.spec.ts
│   │   └── payments.controller.spec.ts
│   └── ... (every service/controller gets a .spec.ts)
│
├── test/
│   ├── jest-e2e.json                     ← E2E Jest config
│   ├── helpers/
│   │   ├── test-app.ts                   ← Shared NestJS test app factory
│   │   ├── test-db.ts                    ← Database setup/teardown
│   │   └── auth.helper.ts               ← Login helper for authenticated tests
│   ├── e2e/
│   │   ├── auth.e2e-spec.ts
│   │   ├── payments.e2e-spec.ts
│   │   ├── filings.e2e-spec.ts
│   │   ├── consultations.e2e-spec.ts
│   │   └── tickets.e2e-spec.ts
│   ├── integration/
│   │   ├── payments.integration-spec.ts
│   │   ├── filings.integration-spec.ts
│   │   └── analytics.integration-spec.ts
│   └── regression/
│       └── regression.spec.ts            ← All bugfix proof tests
```

### Naming Conventions

| Type        | File Pattern                     | Jest Config Match              |
|-------------|----------------------------------|--------------------------------|
| Unit        | `*.spec.ts`                      | Default jest config            |
| Integration | `*.integration-spec.ts`          | `--testPathPattern integration` |
| E2E         | `*.e2e-spec.ts`                  | `--config ./test/jest-e2e.json` |
| Regression  | `test/regression/*.spec.ts`      | `--testPathPattern regression` |

---

## 3. Quick-Start Commands

### Run All Tests

```bash
# Unit tests only (fast, run frequently)
npm test

# Unit tests in watch mode (during development)
npm run test:watch

# Unit tests with coverage report
npm run test:cov

# Integration tests
npx jest --testPathPattern="integration" --runInBand

# E2E tests (requires test database)
npm run test:e2e

# Regression tests
npx jest --testPathPattern="regression"

# Everything at once (CI pipeline)
npm test && npx jest --testPathPattern="integration" --runInBand && npm run test:e2e
```

### Run Specific Module Tests

```bash
# Test a single service
npx jest auth.service.spec.ts

# Test a single module (all files matching "payments")
npx jest payments

# Test with verbose output
npx jest payments --verbose

# Test and stop on first failure
npx jest --bail

# Debug a failing test
npx jest --detectOpenHandles --forceExit auth.e2e-spec.ts
```

### Coverage Commands

```bash
# Full coverage report (HTML + text)
npx jest --coverage --coverageReporters="text" --coverageReporters="html"

# Coverage for a specific module
npx jest --coverage --collectCoverageFrom="src/payments/**/*.ts" payments

# Open coverage report in browser (after generating)
start coverage/lcov-report/index.html
```

---

## 4. Unit Tests

Unit tests are **fast, isolated, and co-located** with the source file. All external dependencies (Prisma, other services) are mocked.

### What to Unit Test

| Target                  | What to Assert                                    |
|-------------------------|---------------------------------------------------|
| **Services**            | Business logic, calculations, conditional flows   |
| **Guards**              | Allow/deny based on role, token validity           |
| **Pipes / Validators**  | DTO validation passes/fails correctly              |
| **Interceptors**        | Response transformation                            |
| **Utilities**           | Helper functions, formatters, date logic           |

### Example: Service Unit Test

```typescript
// src/payments/payments.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { PaymentsService } from './payments.service';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { BadRequestException } from '@nestjs/common';

describe('PaymentsService', () => {
  let service: PaymentsService;
  let prisma: jest.Mocked<PrismaService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PaymentsService,
        {
          provide: PrismaService,
          useValue: {
            payment: {
              create: jest.fn(),
              findMany: jest.fn(),
              findFirst: jest.fn(),
              aggregate: jest.fn(),
              count: jest.fn(),
            },
            coupon: {
              findUnique: jest.fn(),
              update: jest.fn(),
            },
            refund: {
              create: jest.fn(),
              findMany: jest.fn(),
              findFirst: jest.fn(),
            },
            user: {
              findMany: jest.fn(),
            },
            notification: {
              create: jest.fn(),
              createMany: jest.fn(),
            },
          },
        },
        {
          provide: NotificationsService,
          useValue: { createNotification: jest.fn() },
        },
      ],
    }).compile();

    service = module.get<PaymentsService>(PaymentsService);
    prisma = module.get(PrismaService);
  });

  describe('initiatePayment', () => {
    it('should create a payment without coupon', async () => {
      prisma.payment.create.mockResolvedValue({
        id: 'pay_1', amount: 5000, status: 'PENDING',
      } as any);

      const result = await service.initiatePayment('user_1', {
        amount: 5000,
        method: 'BKASH',
        filingId: 'filing_1',
      });

      expect(result.success).toBe(true);
      expect(prisma.payment.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ amount: 5000 }),
        }),
      );
    });

    it('should throw on expired coupon', async () => {
      prisma.coupon.findUnique.mockResolvedValue({
        id: 'c1', active: false,
      } as any);

      await expect(
        service.initiatePayment('user_1', {
          amount: 5000,
          method: 'BKASH',
          couponCode: 'EXPIRED',
        }),
      ).rejects.toThrow(BadRequestException);
    });
  });
});
```

### Example: Guard Unit Test

```typescript
// src/auth/guards/roles.guard.spec.ts
import { RolesGuard } from './roles.guard';
import { Reflector } from '@nestjs/core';
import { ExecutionContext } from '@nestjs/common';

describe('RolesGuard', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  beforeEach(() => {
    reflector = new Reflector();
    guard = new RolesGuard(reflector);
  });

  it('should allow when no roles are required', () => {
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(undefined);
    const context = createMockContext({ role: 'CUSTOMER' });
    expect(guard.canActivate(context)).toBe(true);
  });

  it('should deny customer from admin route', () => {
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(['SUPER_ADMIN']);
    const context = createMockContext({ role: 'CUSTOMER' });
    expect(guard.canActivate(context)).toBe(false);
  });
});

function createMockContext(user: any): ExecutionContext {
  return {
    switchToHttp: () => ({
      getRequest: () => ({ user }),
    }),
    getHandler: () => jest.fn(),
    getClass: () => jest.fn(),
  } as any;
}
```

### Command to Run Unit Tests

```bash
# All unit tests
npm test

# Specific module
npx jest payments.service.spec

# Watch mode (re-runs on file save)
npm run test:watch
```

---

## 5. Integration Tests

Integration tests verify that **services interact correctly with the real database**. They use an actual PostgreSQL test database (not mocks).

### What to Integration Test

| Target                             | What to Assert                                      |
|------------------------------------|-----------------------------------------------------|
| Service + Prisma                   | Records actually created/queried                    |
| Cross-service flows                | Payment → Filing status update                      |
| Complex queries                    | Filters, pagination, aggregations return correct data |
| Unique constraints                 | Duplicate email, duplicate coupon code rejection     |
| Cascade deletes                    | User deletion removes related records               |

### Example: Integration Test

```typescript
// test/integration/payments.integration-spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { PaymentsService } from '../../src/payments/payments.service';
import { PrismaService } from '../../src/prisma/prisma.service';
import { cleanDatabase, seedTestUser, seedTestFiling } from '../helpers/test-db';

describe('PaymentsService (Integration)', () => {
  let service: PaymentsService;
  let prisma: PrismaService;
  let testUserId: string;

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PaymentsService, PrismaService],
    }).compile();

    service = module.get(PaymentsService);
    prisma = module.get(PrismaService);
    await prisma.onModuleInit();
  });

  beforeEach(async () => {
    await cleanDatabase(prisma);
    testUserId = await seedTestUser(prisma);
  });

  afterAll(async () => {
    await cleanDatabase(prisma);
    await prisma.$disconnect();
  });

  it('should persist payment and return in history', async () => {
    const filingId = await seedTestFiling(prisma, testUserId);

    await service.initiatePayment(testUserId, {
      amount: 5000,
      method: 'BKASH',
      filingId,
    });

    const history = await service.getPaymentHistory(testUserId, {});
    expect(history.data).toHaveLength(1);
    expect(history.data[0].amount).toEqual(5000);
    expect(history.totalSpent).toEqual(5000);
  });

  it('should apply percentage coupon discount', async () => {
    // Seed a 20% off coupon
    await prisma.coupon.create({
      data: {
        code: 'SAVE20',
        discountType: 'percentage',
        discountValue: 20,
        active: true,
      },
    });

    const result = await service.initiatePayment(testUserId, {
      amount: 10000,
      method: 'CARD',
      couponCode: 'SAVE20',
    });

    expect(result.data.discountAmount).toEqual(2000);
    expect(result.data.amount).toEqual(8000);
  });
});
```

### Command to Run Integration Tests

```bash
# All integration tests (--runInBand = sequential, avoids DB conflicts)
npx jest --testPathPattern="integration" --runInBand

# Specific module
npx jest --testPathPattern="integration" payments.integration

# With verbose output
npx jest --testPathPattern="integration" --runInBand --verbose
```

---

## 6. Regression Tests

Regression tests **prove that a previously found bug stays fixed**. Every time you fix a bug, add a test here.

### Convention

Each test is tagged with the date and a brief description of the bug:

```typescript
// test/regression/regression.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { PaymentsService } from '../../src/payments/payments.service';
import { PrismaService } from '../../src/prisma/prisma.service';

describe('Regression Tests', () => {
  let paymentsService: PaymentsService;
  let prisma: jest.Mocked<PrismaService>;

  beforeEach(async () => {
    /* ... standard mock setup ... */
  });

  // ─── 2026-02-15: Refund on already-refunded payment ────────
  it('[BUG-001] should reject duplicate refund request', async () => {
    prisma.refund.findFirst.mockResolvedValue({ id: 'ref_1' } as any);
    prisma.payment.findFirst.mockResolvedValue({
      id: 'pay_1', userId: 'u1', status: 'COMPLETED',
    } as any);

    await expect(
      paymentsService.requestRefund('u1', 'pay_1', { reason: 'test' }),
    ).rejects.toThrow('refund request already exists');
  });

  // ─── 2026-02-18: Ticket status not reopening on customer reply ──
  it('[BUG-002] should reopen RESOLVED ticket when customer replies', async () => {
    // ... test that status changes from RESOLVED → OPEN on reply
  });

  // ─── 2026-02-20: Coupon usedCount not incrementing ────────
  it('[BUG-003] should increment coupon usedCount after payment', async () => {
    // ... test coupon.update is called with usedCount increment
  });
});
```

### Command to Run Regression Tests

```bash
# All regression tests
npx jest --testPathPattern="regression"

# Verbose (see which bugs are covered)
npx jest --testPathPattern="regression" --verbose
```

---

## 7. End-to-End (E2E) Tests

E2E tests make real HTTP requests to a running NestJS application. They test the **full request lifecycle**: route → guard → pipe → controller → service → DB → response.

### What to E2E Test

| Critical Path               | Steps                                               |
|-----------------------------|-----------------------------------------------------|
| Authentication Flow         | Register → Login → Get Token → Access Protected     |
| Filing Journey              | Create Filing → Upload Doc → Review → Complete      |
| Payment Flow                | Initiate → Complete → View History → Request Refund  |
| Ticket Lifecycle            | Create → Reply → Admin Reply → Resolve → Close      |
| Consultation Booking        | Get Slots → Book → Reschedule → Cancel               |

### Example: E2E Test

```typescript
// test/e2e/auth.e2e-spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';

describe('Auth (E2E)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('POST /api/v1/auth/register - should register a new user', () => {
    return request(app.getHttpServer())
      .post('/api/v1/auth/register')
      .send({
        email: 'test@example.com',
        password: 'SecureP@ss1',
        fullName: 'Test User',
      })
      .expect(201)
      .expect((res) => {
        expect(res.body.success).toBe(true);
        expect(res.body.data).toHaveProperty('accessToken');
      });
  });

  it('POST /api/v1/auth/login - should login with valid credentials', () => {
    return request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({
        email: 'test@example.com',
        password: 'SecureP@ss1',
      })
      .expect(200)
      .expect((res) => {
        expect(res.body.data.accessToken).toBeDefined();
      });
  });

  it('GET /api/v1/auth/me - should reject unauthenticated request', () => {
    return request(app.getHttpServer())
      .get('/api/v1/auth/me')
      .expect(401);
  });

  it('GET /api/v1/auth/me - should return user with valid token', async () => {
    // Login first
    const loginRes = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: 'test@example.com', password: 'SecureP@ss1' });

    const token = loginRes.body.data.accessToken;

    return request(app.getHttpServer())
      .get('/api/v1/auth/me')
      .set('Authorization', `Bearer ${token}`)
      .expect(200)
      .expect((res) => {
        expect(res.body.data.email).toBe('test@example.com');
      });
  });
});
```

### Example: Protected Route E2E Test

```typescript
// test/e2e/payments.e2e-spec.ts
import request from 'supertest';
import { loginAsCustomer, loginAsAdmin } from '../helpers/auth.helper';

describe('Payments (E2E)', () => {
  let app: INestApplication;
  let customerToken: string;
  let adminToken: string;

  beforeAll(async () => {
    // ... app setup ...
    customerToken = await loginAsCustomer(app);
    adminToken = await loginAsAdmin(app);
  });

  it('POST /api/v1/payments - customer can initiate payment', () => {
    return request(app.getHttpServer())
      .post('/api/v1/payments')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({ amount: 5000, method: 'BKASH', filingId: 'test-filing' })
      .expect(201)
      .expect((res) => {
        expect(res.body.data.status).toBe('PENDING');
      });
  });

  it('GET /api/v1/admin/payments - customer cannot access admin route', () => {
    return request(app.getHttpServer())
      .get('/api/v1/admin/payments')
      .set('Authorization', `Bearer ${customerToken}`)
      .expect(403);
  });

  it('GET /api/v1/admin/payments/stats - admin can view revenue stats', () => {
    return request(app.getHttpServer())
      .get('/api/v1/admin/payments/stats')
      .set('Authorization', `Bearer ${adminToken}`)
      .expect(200)
      .expect((res) => {
        expect(res.body.data).toHaveProperty('thisMonth');
      });
  });
});
```

### Command to Run E2E Tests

```bash
# All E2E tests
npm run test:e2e

# Specific E2E test
npx jest --config ./test/jest-e2e.json auth.e2e-spec

# With debug output for hanging tests
npx jest --config ./test/jest-e2e.json --detectOpenHandles --forceExit

# E2E with coverage
npx jest --config ./test/jest-e2e.json --coverage
```

---

## 8. Test Database Setup

### Environment Variable

Create a `.env.test` file:

```env
DATABASE_URL="postgresql://user:pass@localhost:5432/anchorpoint_test"
DIRECT_URL="postgresql://user:pass@localhost:5432/anchorpoint_test"
JWT_SECRET="test-jwt-secret-not-for-production"
JWT_REFRESH_SECRET="test-refresh-secret"
```

### Database Helper

```typescript
// test/helpers/test-db.ts
import { PrismaService } from '../../src/prisma/prisma.service';

export async function cleanDatabase(prisma: PrismaService) {
  // Delete in dependency order (children first)
  await prisma.ticketReply.deleteMany();
  await prisma.ticket.deleteMany();
  await prisma.message.deleteMany();
  await prisma.conversation.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.refund.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.consultation.deleteMany();
  await prisma.document.deleteMany();
  await prisma.filingStatusLog.deleteMany();
  await prisma.filing.deleteMany();
  await prisma.customerProfile.deleteMany();
  await prisma.refreshToken.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.user.deleteMany();
  await prisma.coupon.deleteMany();
}

export async function seedTestUser(prisma: PrismaService): Promise<string> {
  const user = await prisma.user.create({
    data: {
      email: 'testuser@test.com',
      passwordHash: '$2b$10$hashedpassword',
      role: 'CUSTOMER',
      emailVerified: true,
      profile: {
        create: { fullName: 'Test User' },
      },
    },
  });
  return user.id;
}

export async function seedTestAdmin(prisma: PrismaService): Promise<string> {
  const admin = await prisma.user.create({
    data: {
      email: 'admin@test.com',
      passwordHash: '$2b$10$hashedpassword',
      role: 'SUPER_ADMIN',
      emailVerified: true,
      profile: {
        create: { fullName: 'Test Admin' },
      },
    },
  });
  return admin.id;
}

export async function seedTestFiling(
  prisma: PrismaService,
  userId: string,
): Promise<string> {
  const filing = await prisma.filing.create({
    data: {
      userId,
      assessmentYear: '2025-2026',
      serviceType: 'individual',
      status: 'INITIATED',
    },
  });
  return filing.id;
}
```

### Auth Helper

```typescript
// test/helpers/auth.helper.ts
import { INestApplication } from '@nestjs/common';
import request from 'supertest';

export async function loginAsCustomer(app: INestApplication): Promise<string> {
  const res = await request(app.getHttpServer())
    .post('/api/v1/auth/login')
    .send({ email: 'testuser@test.com', password: 'TestPass123!' });
  return res.body.data.accessToken;
}

export async function loginAsAdmin(app: INestApplication): Promise<string> {
  const res = await request(app.getHttpServer())
    .post('/api/v1/auth/login')
    .send({ email: 'admin@test.com', password: 'AdminPass123!' });
  return res.body.data.accessToken;
}
```

### Setup Script

```bash
# Create test database (run once)
npx prisma db push --force-reset --schema=prisma/schema.prisma

# Or use migrations
npx prisma migrate deploy
```

---

## 9. CI/CD Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml
name: Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: anchorpoint_test
        ports: ['5432:5432']
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '22' }

      - name: Install
        run: cd backend && npm ci

      - name: Generate Prisma
        run: cd backend && npx prisma generate

      - name: Push Schema
        run: cd backend && npx prisma db push --force-reset
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/anchorpoint_test

      - name: Unit Tests
        run: cd backend && npm test -- --ci --coverage

      - name: Integration Tests
        run: cd backend && npx jest --testPathPattern="integration" --runInBand
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/anchorpoint_test

      - name: E2E Tests
        run: cd backend && npm run test:e2e -- --forceExit
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/anchorpoint_test
          JWT_SECRET: ci-test-secret
```

### Pre-Commit Hook (Optional)

```bash
# Run unit tests before every commit
npx husky add .husky/pre-commit "cd backend && npm test -- --bail --onlyChanged"
```

---

## 10. Coverage Targets

| Module          | Target | Priority |
|-----------------|--------|----------|
| **Auth**        | 90%+   | 🔴 Critical — security  |
| **Payments**    | 85%+   | 🔴 Critical — money     |
| **Filings**     | 80%+   | 🟡 High                 |
| **Documents**   | 75%+   | 🟡 High                 |
| **Consultations** | 75%+ | 🟡 High                |
| **Tickets**     | 70%+   | 🟢 Medium               |
| **Messages**    | 70%+   | 🟢 Medium               |
| **CMS / SEO**   | 60%+   | 🟢 Medium               |
| **Analytics**   | 50%+   | ⚪ Low (read-only)      |
| **Overall**     | **75%+** | —                     |

### Enforce in CI

```json
// Add to package.json jest config
{
  "jest": {
    "coverageThreshold": {
      "global": {
        "branches": 70,
        "functions": 75,
        "lines": 75,
        "statements": 75
      }
    }
  }
}
```

---

## 11. Professional Best Practices

### ✅ Do

| Practice | Why |
|----------|-----|
| **Co-locate unit tests** with source (`auth.service.spec.ts` next to `auth.service.ts`) | Easy to find, encourages writing tests |
| **Use `--runInBand` for DB tests** | Prevents parallel tests from conflicting on the same database |
| **Clean the database before each test** (`beforeEach`) | Each test starts with a known state |
| **Use factories/helpers** for test data | Avoids repetitive setup code |
| **Test error paths, not just happy paths** | Bugs live in edge cases |
| **Name tests as specifications** (`'should reject expired coupon'`) | Tests document behavior |
| **Add regression tests for every bug fix** | Prevents the same bug from returning |

### ❌ Don't

| Anti-Pattern | Why It's Bad |
|-------------|-------------|
| Test implementation details (e.g., "method X was called 3 times") | Breaks when you refactor |
| Share state between tests | Causes flaky, order-dependent failures |
| Skip tests with `xit` or `.skip` indefinitely | Dead tests rot the suite |
| Write E2E tests for everything | Slow, fragile — use the pyramid |
| Test third-party code (Prisma, NestJS internals) | That's their job, not yours |

### Test Priority Order (What to Write First)

1. ⚡ **Auth guards & JWT validation** — security gate
2. 💰 **Payment calculations & coupon logic** — money logic
3. 📋 **Filing status transitions** — core business workflow
4. 📄 **Document upload/review** — file handling edge cases
5. 🎫 **Ticket lifecycle** — customer-facing support
6. 📊 **Analytics queries** — read-only, lower risk

---

## Command Reference (Quick Copy)

```bash
# ──────────── DAILY DEVELOPMENT ────────────
npm run test:watch                              # Watch mode
npx jest payments --verbose                     # Test one module

# ──────────── BEFORE COMMIT ────────────────
npm test -- --bail                              # Fast fail
npx jest --testPathPattern="regression"         # Regression check

# ──────────── BEFORE MERGE/DEPLOY ──────────
npm test                                        # All unit tests
npx jest --testPathPattern="integration" --runInBand  # DB tests
npm run test:e2e -- --forceExit                 # Full E2E
npm run test:cov                                # Coverage report

# ──────────── DEBUGGING ───────────────────
npx jest --detectOpenHandles --forceExit        # Find hanging tests
npx jest --verbose --no-cache                   # Force fresh run
npx jest --coverage --collectCoverageFrom="src/auth/**" auth  # Module coverage
```

---

*Last updated: 21 February 2026*
