# Anchor Point Advising — User Journeys & Stories

> **Last Updated:** 21 February 2026  
> **Purpose:** Map every meaningful interaction path through the platform

---

## Table of Contents

1. [Personas](#1-personas)
2. [Visitor Journeys (Pre-Signup)](#2-visitor-journeys)
3. [Customer Journeys (Post-Signup)](#3-customer-journeys)
4. [Admin / Advisor Journeys](#4-admin--advisor-journeys)
5. [User Stories (Epics & Stories)](#5-user-stories)
6. [Edge Cases & Recovery Flows](#6-edge-cases--recovery-flows)

---

## 1. Personas

### 🧑‍💼 Rahim — The Salaried Employee
- **Age:** 32  |  **Location:** Dhaka  |  **Income:** BDT 60,000/month
- **Pain:** Gets anxious every November. Doesn't understand tax zones, rebates, or asset statements. Last year he paid a local "tax guy" BDT 5,000 and isn't even sure it was filed correctly.
- **Goal:** File his return correctly, on time, without headaches.
- **Tech comfort:** Uses smartphone daily, comfortable with bKash, basic English.

### 👩‍💻 Fatima — The Freelancer
- **Age:** 27  |  **Location:** Chittagong  |  **Income:** Variable (Upwork, Fiverr)
- **Pain:** Multiple income sources, receives USD, confused about whether freelancing income is taxable. Has never filed a return.
- **Goal:** Understand her obligations and get compliant before she gets flagged.
- **Tech comfort:** Very comfortable, prefers English UI, expects modern UX.

### 🏢 Mr. Karim — The Business Owner
- **Age:** 48  |  **Location:** Sylhet  |  **Income:** Runs a garments trading business
- **Pain:** Needs corporate tax filing, bookkeeping, and audit services. Currently uses a CA firm that charges BDT 50,000+ and is unresponsive.
- **Goal:** Reliable, transparent, affordable tax + accounting services.
- **Tech comfort:** Moderate. His office manager handles most of the online work.

### 🌍 Tanvir — The NRB (Non-Resident Bangladeshi)
- **Age:** 38  |  **Location:** Melbourne, Australia  |  **Owns:** Flat in Gulshan, land in Mymensingh
- **Pain:** Owns properties in Bangladesh, needs to file returns but can't visit. Doesn't know the current rules for NRB taxation. Time zone difference makes phone calls difficult.
- **Goal:** File remotely, upload documents online, get it done without traveling to BD.
- **Tech comfort:** High. Expects a polished, English-first web experience.

### 👨‍👩‍👧 Nasreen — The First-Time Taxpayer
- **Age:** 24  |  **Location:** Rajshahi  |  **Income:** Just got her first job (BDT 25,000/month)
- **Pain:** Her employer asked for a TIN certificate. She has no idea what TIN is, how to get one, or if she even needs to file.
- **Goal:** Get a TIN, understand if she needs to file, and if so, get help.
- **Tech comfort:** High, mobile-first, prefers Bangla UI.

### 🛡️ Arif — The Tax Advisor (Staff)
- **Age:** 35  |  **Role:** Senior Tax Consultant at Anchor Point
- **Daily work:** Reviews documents, prepares returns, files on NBR portal, handles 15-20 clients during peak season.
- **Pain:** Currently uses WhatsApp + email + Google Drive. Documents get lost, status tracking is manual, clients keep asking "is my return done yet?"
- **Goal:** A single system to manage all clients, documents, and filings.

### 👑 Admin — The Business Owner (You)
- **Role:** Super Admin / Founder of Anchor Point Advising
- **Goal:** See the big picture — revenue, customer growth, advisor workload, website content — all from one dashboard.

---

## 2. Visitor Journeys (Pre-Signup)

### Journey 1: "I Need to File My Tax" (Rahim)

```
Google Search: "income tax return filing service bangladesh"
        │
        ▼
┌─────────────────────────────────┐
│  LANDING PAGE                    │
│  Hero: "Expert Tax Solution      │
│         For Your Business"       │
│  [Our Services]  [Contact Us]    │
└──────────┬──────────────────────┘
           │ scrolls down
           ▼
┌──────────────────────────────────┐
│  SERVICES SECTION                │
│  Tax Preparation • Financial     │
│  Planning • Business Consulting  │
│  → Clicks "Learn More" on Tax    │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  INDIVIDUAL TAX SERVICE PAGE     │
│  Detailed info about the process │
│  Documents needed, timeline      │
│  [Get Started — BDT 1,500]       │
└──────────┬───────────────────────┘
           │ not ready yet, scrolls back
           ▼
┌──────────────────────────────────┐
│  FAQ SECTION                     │
│  "Who needs to file?"            │
│  "What documents do I need?"     │
│  → Reads 3-4 questions           │
│  → Confidence increases          │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  PRICING SECTION                 │
│  BDT 1,500 — Complete Solution   │
│  ✓ Everything included           │
│  [Get Started Now] ← CLICKS      │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  REGISTRATION PAGE               │
│  Name, Email, Phone, Password    │
│  ──── or ────                    │
│  [Continue with Google]          │
│  → Signs up with email/password  │
└──────────┬───────────────────────┘
           │
           ▼
        CUSTOMER DASHBOARD
        (Journey continues in §3)
```

**Key Moments:**
- 🔍 **SEO matters** — Must rank for "income tax filing Bangladesh", "tax return service Dhaka"
- 📖 **FAQ builds trust** — Rahim needs education before he commits
- 💰 **Price transparency** — "BDT 1,500 all-inclusive" removes purchase anxiety
- ⏱️ **Time on site:** ~4-6 minutes before signup

---

### Journey 2: "Am I Even Required to File?" (Nasreen)

```
WhatsApp Forward: "এই ওয়েবসাইটে ট্যাক্স ফাইল করতে পারবে"
        │
        ▼
┌──────────────────────────────────┐
│  LANDING PAGE (Bangla)           │
│  Switches to Bengali via 🌐      │
│  Reads hero & services           │
└──────────┬───────────────────────┘
           │ confused, needs guidance
           ▼
┌──────────────────────────────────┐
│  FAQ: "কাদের আয়কর রিটার্ন         │
│        জমা দিতে হবে?"              │
│  → Reads answer                  │
│  → Still unsure about her case   │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  CONSULTATION SECTION            │
│  "বিশেষজ্ঞ পরামর্শ — ৩০০ টাকা"     │
│  [এখনই বুক করুন] ← CLICKS        │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  REGISTRATION (Quick)            │
│  Phone + OTP only                │
│  → Verified in 30 seconds        │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  CONSULTATION BOOKING            │
│  Select date → time → medium     │
│  → Pays BDT 300 via bKash        │
│  → Gets confirmation + reminder  │
└──────────────────────────────────┘
```

**Key Moments:**
- 🌐 **Language is critical** — She arrived via a Bangla WhatsApp forward, the site must feel native in Bangla
- 💬 **Consultation is the entry point** — She's not ready to buy the full service; the BDT 300 consultation is the low-barrier first step
- 📱 **Phone-first registration** — She may not have a "professional" email; phone OTP is faster
- 🔄 **Upsell opportunity** — After the consultation, the advisor recommends the full filing service

---

### Journey 3: "I Need This Done Remotely" (Tanvir — NRB)

```
Google Search: "bangladesh tax filing NRB non-resident"
        │
        ▼
┌──────────────────────────────────┐
│  NRB TAX SERVICE PAGE            │
│  (Direct landing via SEO)        │
│  "Complete NRB Tax Solution"     │
│  Property tax, rental income...  │
│  [Get Started]                   │
└──────────┬───────────────────────┘
           │ wants to know more
           ▼
┌──────────────────────────────────┐
│  ABOUT SECTION                   │
│  "10 years experience"           │
│  Team photos, credentials        │
│  → Trust established             │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  WHATSAPP BUTTON (floating)      │
│  → Opens WhatsApp chat           │
│  → Quick question answered       │
│  → Advisor says "Sign up and     │
│    upload your documents online"  │
└──────────┬───────────────────────┘
           │
           ▼
        REGISTERS (Google OAuth)
        → Completes onboarding wizard
        → Selects "NRB" taxpayer type
        → Dashboard shows NRB-specific checklist
```

**Key Moments:**
- 🔗 **Direct landing on service page** — NRBs search for specific terms; the service page IS the landing page
- 💬 **WhatsApp is the trust bridge** — NRBs are cautious about paying an unknown BD firm; a quick WhatsApp exchange builds confidence
- 🌍 **Time zone aware** — His consultation should show Melbourne time alongside BD time
- 📤 **Document upload is THE feature** — This is why he needs an account; he can't physically hand over documents

---

### Journey 4: "We Need a Better CA" (Mr. Karim's Office Manager)

```
Referral from business associate
        │
        ▼
┌──────────────────────────────────┐
│  LANDING PAGE                    │
│  → Clicks "Services"            │
│  → Corporate Tax page           │
│  → Reads scope of services:     │
│    Audit, Bookkeeping, Payroll   │
└──────────┬───────────────────────┘
           │ wants to talk, not read
           ▼
┌──────────────────────────────────┐
│  "Strategy Call" BUTTON (Navbar) │
│  → Books consultation            │
│  → BDT 300 (or waived for corp)  │
│  → Video call with senior advisor│
└──────────┬───────────────────────┘
           │ after consultation
           ▼
┌──────────────────────────────────┐
│  CUSTOM QUOTE via Email          │
│  → Admin creates manual invoice  │
│  → Corporate package: BDT 25,000 │
│  → Client pays via bank transfer │
└──────────┬───────────────────────┘
           │
           ▼
        ACCOUNT CREATED BY ADMIN
        → Office manager gets credentials
        → Uploads business documents
        → Monthly bookkeeping begins
```

**Key Moments:**
- 🤝 **Referral-driven** — Corporate clients rarely come from Google; they come from word-of-mouth
- 📞 **Human touch first** — They want a conversation before any online interaction
- 💼 **Custom pricing** — The BDT 1,500 package doesn't apply; admin creates a custom quote
- 👥 **Delegated account** — The business owner won't use the portal; his office manager will

---

## 3. Customer Journeys (Post-Signup)

### Journey 5: Full Tax Filing (Happy Path — Rahim)

```
         ┌──────────┐
         │  SIGNUP   │
         └────┬─────┘
              │
              ▼
┌──────────────────────────────────┐
│  ONBOARDING WIZARD               │
│  Step 1: Personal Info            │
│    Name, NID, TIN, DOB            │
│  Step 2: Income Details           │
│    □ Salary  □ Business           │
│    □ Rental  □ Freelance          │
│  Step 3: Select Assessment Year   │
│    "2025-2026"                    │
│  Step 4: Select Service           │
│    "Complete Tax Solution - ১,৫০০" │
│  → [Continue to Payment]          │
└────────────┬─────────────────────┘
             │
             ▼
┌──────────────────────────────────┐
│  PAYMENT                          │
│  Amount: BDT 1,500                │
│  Method: [bKash] [Nagad] [Card]   │
│  → Pays via bKash                 │
│  → Invoice generated              │
│  → Confirmation email sent        │
└────────────┬─────────────────────┘
             │
             ▼
┌──────────────────────────────────┐
│  DASHBOARD                        │
│  ┌─────────────────────────────┐  │
│  │ Filing: 2025-2026           │  │
│  │ Status: ● Documents Pending │  │
│  │ ██░░░░░░░░ 10%              │  │
│  │ Deadline: 30 Nov 2025       │  │
│  └─────────────────────────────┘  │
│                                   │
│  ⚡ Quick Actions:                │
│  [Upload Documents]               │
│  [View Checklist]                 │
│  [Message Advisor]                │
└────────────┬─────────────────────┘
             │ clicks "Upload Documents"
             ▼
┌──────────────────────────────────┐
│  DOCUMENT UPLOAD                  │
│                                   │
│  Required Documents:              │
│  ✅ NID (uploaded)                │
│  ⬜ TIN Certificate               │
│  ⬜ Salary Certificate            │
│  ⬜ Bank Statement (Jan-Jun)      │
│  ⬜ Previous Return               │
│                                   │
│  ┌─────────────────────────────┐  │
│  │  📎 Drag & drop files here  │  │
│  │     or click to browse      │  │
│  └─────────────────────────────┘  │
│                                   │
│  → Uploads 4 documents            │
│  → Progress bars show upload %    │
│  → Each shows "⏳ Pending Review" │
└────────────┬─────────────────────┘
             │ 1-2 days later
             ▼
┌──────────────────────────────────┐
│  🔔 NOTIFICATION                  │
│  "Your Salary Certificate has     │
│   been accepted ✓"                │
│                                   │
│  🔔 NOTIFICATION                  │
│  "Bank Statement rejected ✗       │
│   Reason: Only Jan-Mar provided.  │
│   Please upload Apr-Jun as well." │
└────────────┬─────────────────────┘
             │ re-uploads corrected doc
             ▼
┌──────────────────────────────────┐
│  DASHBOARD (updated)              │
│  Status: ● Under Preparation     │
│  ██████░░░░ 50%                   │
│  "Your tax advisor Arif is        │
│   preparing your return"          │
└────────────┬─────────────────────┘
             │ 3-5 days later
             ▼
┌──────────────────────────────────┐
│  🔔 NOTIFICATION                  │
│  "Your return is ready for review"│
│                                   │
│  RETURN PREVIEW PAGE              │
│  Total Income: BDT 7,20,000      │
│  Tax Payable: BDT 12,500         │
│  Tax Already Paid (TDS): 10,000  │
│  Net Payable: BDT 2,500          │
│                                   │
│  [✓ Approve & File]  [✗ Dispute]  │
│  → Clicks "Approve & File"        │
└────────────┬─────────────────────┘
             │ advisor files on NBR
             ▼
┌──────────────────────────────────┐
│  DASHBOARD (final)                │
│  Status: ● Completed ✓           │
│  ██████████ 100%                  │
│                                   │
│  📄 Downloads Available:          │
│  [Download Filed Return PDF]      │
│  [Download Acknowledgement]       │
│  [Download Invoice]               │
│                                   │
│  ⭐ "Rate your experience"        │
│  → Leaves 5-star review           │
└──────────────────────────────────┘
```

**Timeline:** ~7-14 days from signup to completion

---

### Journey 6: Consultation → Upsell (Nasreen)

```
CONSULTATION COMPLETED
  → Advisor explains: "You need a TIN, and yes, you should file"
  → Advisor's notes visible in her account
        │
        ▼
🔔 FOLLOW-UP NOTIFICATION (next day)
  "Based on your consultation, we recommend
   our Complete Tax Solution. Get started for
   just BDT 1,500."
  [Purchase Now]
        │
        ▼
  → Clicks "Purchase Now"
  → Redirected to payment
  → BDT 300 consultation fee deducted? (business decision)
  → Pays BDT 1,500 (or BDT 1,200 if credited)
        │
        ▼
  → Journey continues as Journey 5
```

---

### Journey 7: Returning Customer (Next Year — Rahim)

```
🔔 EMAIL: "Tax season 2026-2027 is approaching"
  (Sent Oct 1, 60 days before deadline)
        │
        ▼
  → Logs in to existing account
  → Dashboard shows: "Start Filing for 2026-2027"
  → Previous year's data pre-filled
  → Document checklist shows: "Reuse NID? ✓ Yes"
  → Only uploads new salary certificate + bank statement
  → Pays BDT 1,500 (or discounted returning rate)
        │
        ▼
  → Filed within 5 days (advisor already knows his profile)
```

**Key Insight:** Returning customers are 3x faster to serve. The system should make their experience feel effortless.

---

### Journey 8: Document Rejection & Recovery (Fatima)

```
  Fatima uploads her "income proof" — a screenshot of her Upwork earnings page
        │
        ▼
  🔔 NOTIFICATION
  "Document Rejected: Income Proof
   Reason: Screenshots are not accepted.
   Please upload your Upwork Annual Statement
   or bank statements showing deposits."
        │
        ▼
  → Fatima is confused, opens in-app chat:
    "Where do I find the Upwork Annual Statement?"
        │
        ▼
  Advisor Arif replies with step-by-step guide
  (possibly using a canned response template)
        │
        ▼
  → Fatima downloads from Upwork, re-uploads PDF
  → Document status: ✅ Accepted
  → Filing proceeds
```

---

## 4. Admin / Advisor Journeys

### Journey 9: Morning Workflow (Advisor Arif)

```
  9:00 AM — Arif logs into Admin Panel
        │
        ▼
┌──────────────────────────────────┐
│  ADVISOR DASHBOARD                │
│                                   │
│  📊 My Workload Today:            │
│  • 3 documents to review          │
│  • 2 returns to prepare           │
│  • 1 consultation at 2 PM        │
│  • 5 unread messages              │
│                                   │
│  ⏰ Upcoming Deadlines:           │
│  • Rahim (3 days left)            │
│  • Fatima (7 days left)           │
│  • Tanvir (12 days left)          │
└────────────┬─────────────────────┘
             │
             ▼
  STEP 1: Review Documents (30 min)
  → Opens Document Review Queue
  → Filters: "Pending, sorted by oldest"
  → Reviews each:
    • NID scan — clear, readable → ✅ Approve
    • Bank stmt — wrong date range → ✗ Reject (types reason)
    • Salary cert — OK → ✅ Approve
  → Customer auto-notified for each
             │
             ▼
  STEP 2: Prepare Returns (2 hours)
  → Opens Rahim's filing
  → All documents ✅
  → Prepares return offline (NBR portal)
  → Updates status: "Under Preparation" → "Review Ready"
  → Rahim receives notification
             │
             ▼
  STEP 3: Handle Messages (20 min)
  → Opens Message Center
  → Replies to Fatima's question about Upwork statement
  → Replies to Tanvir's query about property valuation
  → Uses canned response for a common TIN question
             │
             ▼
  STEP 4: Consultation at 2 PM
  → Dashboard shows reminder at 1:45 PM
  → Opens consultation details — Nasreen, video call
  → Clicks Google Meet link
  → After call: writes session notes, creates follow-up task
  → Follow-up auto-sent to Nasreen: "Please upload your NID"
```

---

### Journey 10: Admin — End of Month Review

```
  Last day of the month — Admin logs in
        │
        ▼
┌──────────────────────────────────┐
│  SUPER ADMIN DASHBOARD            │
│                                   │
│  💰 Revenue This Month: ৳47,500   │
│  📈 vs Last Month: +23%           │
│  👥 New Customers: 12             │
│  📄 Filings Completed: 8          │
│  📋 Open Tickets: 3               │
│  🔴 Overdue Filings: 1            │
└────────────┬─────────────────────┘
             │
             ▼
  → Clicks "Revenue Analytics"
  → Bar chart: Revenue by service
    Tax Filing: ৳36,000
    Consultations: ৳6,000
    Corporate: ৳0
    Other: ৳5,500
             │
             ▼
  → Exports monthly report as PDF
  → Checks advisor performance:
    Arif: 15 filings, avg 4.2 days/filing, 4.8★ rating
    Sarah: 8 filings, avg 6.1 days/filing, 4.5★ rating
             │
             ▼
  → Updates website content via CMS:
    Changes hero text for tax season push
    Adds a new testimonial from a happy client
    Creates announcement banner: "Filing deadline in 30 days!"
             │
             ▼
  → Sends broadcast notification to all customers:
    "Reminder: Tax filing deadline is 30 November.
     Start your filing today to avoid penalties."
```

---

### Journey 11: Admin — Handling a Refund Request

```
  🔔 New support ticket from customer
  Subject: "I was charged twice for the same service"
        │
        ▼
  → Admin opens ticket
  → Checks payment history for customer
  → Confirms duplicate payment
  → Navigates to Payments → finds both transactions
             │
             ▼
  → Clicks "Process Refund" on the duplicate
  → Selects amount: BDT 1,500 (full)
  → Writes reason: "Duplicate payment confirmed"
  → Submits for processing
             │
             ▼
  → Refund processed via bKash API
  → Customer auto-notified: "Your refund of BDT 1,500 has been processed"
  → Ticket auto-updated to "Resolved"
  → Audit log entry created
```

---

## 5. User Stories (Epics & Stories)

### Epic 1: Discovery & Trust

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-01 | visitor | see clear pricing with no hidden fees | I can trust this service and make a quick decision |
| US-02 | visitor | read FAQ answers in Bangla | I understand my tax obligations in my own language |
| US-03 | visitor | see team photos and credentials | I know real, qualified people are behind this |
| US-04 | visitor | read testimonials from similar customers | I feel confident others like me have been helped |
| US-05 | visitor | click a WhatsApp button for instant questions | I can get a quick answer without signing up |
| US-06 | NRB visitor | find an NRB-specific service page via Google | I know this firm handles NRB cases specifically |

### Epic 2: Registration & Onboarding

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-07 | visitor | register with my phone number and OTP | I can sign up quickly without needing email |
| US-08 | visitor | register with Google one-click | I don't have to create yet another password |
| US-09 | new customer | go through a guided onboarding wizard | the system knows my taxpayer type and shows relevant options |
| US-10 | new customer | skip onboarding and complete it later | I'm not blocked from exploring the dashboard |

### Epic 3: Document Management

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-11 | customer | see a checklist of required documents for my filing | I know exactly what to upload |
| US-12 | customer | drag-and-drop multiple files at once | uploading is fast and convenient |
| US-13 | customer | see the status of each document (pending/accepted/rejected) | I know if any action is needed from me |
| US-14 | customer | receive a clear reason when a document is rejected | I know what to fix and re-upload |
| US-15 | customer | preview my uploaded PDFs and images in-browser | I can verify I uploaded the right file |
| US-16 | customer | re-upload a corrected document | the old version is replaced but kept for history |
| US-17 | returning customer | reuse documents from last year (NID, TIN) | I don't have to upload the same things every year |

### Epic 4: Tax Filing Lifecycle

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-18 | customer | see a visual progress bar for my filing | I know exactly where things stand at any moment |
| US-19 | customer | receive notifications at each status change | I'm never left wondering what's happening |
| US-20 | customer | preview my prepared return before it's filed | I can verify the numbers and approve or raise concerns |
| US-21 | customer | download my filed return and acknowledgement receipt | I have proof of filing for my records |
| US-22 | customer | see my filing history across years | I can compare and track my tax journey |
| US-23 | customer | see a countdown to the filing deadline | I feel urgency and act before it's too late |

### Epic 5: Payments

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-24 | customer | pay via bKash or Nagad | I can use the payment method I'm most comfortable with |
| US-25 | customer | receive an instant invoice after payment | I have a receipt for my records |
| US-26 | customer | see all my past payments in one place | I can track my spending and download invoices |
| US-27 | customer | apply a promo code at checkout | I can save money if I have a discount |
| US-28 | customer | request a refund if I'm not satisfied | I feel safe purchasing the service |

### Epic 6: Consultation

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-29 | visitor | book a consultation without full registration | the barrier to entry is as low as possible |
| US-30 | customer | see available time slots in a calendar | I can pick a convenient time |
| US-31 | customer | get a reminder 1 hour before my consultation | I don't forget the appointment |
| US-32 | customer | see my advisor's notes after the consultation | I remember what was discussed and what to do next |
| US-33 | customer | reschedule my consultation | plans change and I shouldn't lose my payment |

### Epic 7: Communication

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-34 | customer | message my assigned tax advisor in-app | I don't have to use WhatsApp or email separately |
| US-35 | customer | share files within the chat | I can quickly send a document the advisor needs |
| US-36 | customer | receive email/SMS for critical updates | I don't miss important filing deadlines or status changes |
| US-37 | customer | submit a support ticket for billing issues | my issue is tracked and resolved properly |

### Epic 8: Admin Operations

| ID | As a... | I want to... | So that... |
|----|---------|-------------|-----------|
| US-38 | advisor | see my daily workload at a glance | I can prioritize my day efficiently |
| US-39 | advisor | review and approve/reject documents in a queue | I can process documents quickly without searching |
| US-40 | advisor | update a filing's status with one click | the customer is automatically notified |
| US-41 | advisor | use canned responses for common questions | I save time on repetitive communications |
| US-42 | admin | see total revenue broken down by service and month | I understand business performance |
| US-43 | admin | assign customers to specific advisors | workload is distributed evenly |
| US-44 | admin | send broadcast notifications to all customers | I can announce deadlines or promotions |
| US-45 | admin | update website content without editing code | I can keep the site fresh and relevant |
| US-46 | admin | see an audit log of all admin actions | I maintain accountability and compliance |
| US-47 | admin | create and manage discount coupons | I can run promotions to attract customers |
| US-48 | admin | export financial data as CSV/Excel | I can share it with my accountant |

---

## 6. Edge Cases & Recovery Flows

### 6.1 Failed Payment
```
Customer → Pays via bKash → Gateway timeout/failure
  → Payment status: PENDING (not FAILED yet)
  → System waits for IPN callback (up to 30 min)
  → If IPN confirms: status → COMPLETED, proceed normally
  → If IPN fails: status → FAILED
    → Customer sees: "Payment could not be confirmed.
       If money was deducted, it will be refunded in 3-5 days.
       [Try Again] [Contact Support]"
  → Admin can manually mark as COMPLETED if customer provides proof
```

### 6.2 Customer Goes Inactive
```
Filing initiated → Documents uploaded → No activity for 14 days
  → System sends reminder: "Your filing is waiting for documents"
  → 7 more days → Second reminder
  → 30 days total → Filing status: ON_HOLD
  → Admin can see "Inactive Filings" report
  → Advisor can reach out via phone/WhatsApp
```

### 6.3 Deadline Approaching
```
30 days before deadline → Email + in-app notification
14 days → SMS + email + dashboard banner (yellow)
7 days → Urgent SMS + email + dashboard banner (red)
3 days → Phone call from advisor (manual)
1 day → Final SMS: "TOMORROW is the last day to file"
After deadline → Guide to late filing + penalty calculator
```

### 6.4 Advisor Leaves Company
```
Advisor Arif resigns
  → Admin reassigns all his customers to other advisors
  → Each customer gets notification:
    "Your new tax advisor is Sarah Ahmed"
  → All chat history preserved
  → Filing continuity maintained
```

### 6.5 Customer Dispute
```
Customer: "The return has the wrong income figure"
  → Files dispute via dashboard (clicks "Dispute" instead of "Approve")
  → Enters note: "My actual salary is BDT 65,000, not 60,000"
  → Filing status reverts: "Review Ready" → "Under Preparation"
  → Advisor gets notification with dispute details
  → Advisor corrects and re-submits for review
  → Customer re-reviews and approves
```

### 6.6 Simultaneous Upload Issue
```
Customer opens upload page on phone + laptop simultaneously
  → Uploads same document from both
  → System detects duplicate (same filename + hash within 5 min)
  → Keeps one, discards duplicate
  → Shows: "This file was already uploaded"
```
