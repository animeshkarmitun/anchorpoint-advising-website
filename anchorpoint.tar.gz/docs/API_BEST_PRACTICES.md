# Anchor Point Advising — API Best Practices

> **Last Updated:** 21 February 2026  
> **Stack:** NestJS + Prisma + PostgreSQL  
> **API Base:** `/api/v1`

---

## Table of Contents

1. [URL & Endpoint Design](#1-url--endpoint-design)
2. [Standard Response Envelope](#2-standard-response-envelope)
3. [Request Bodies](#3-request-bodies)
4. [Pagination](#4-pagination)
5. [Filtering, Sorting & Searching](#5-filtering-sorting--searching)
6. [Error Handling](#6-error-handling)
7. [Authentication Responses](#7-authentication-responses)
8. [File Uploads](#8-file-uploads)
9. [Partial Updates (PATCH vs PUT)](#9-partial-updates)
10. [Sensitive Data Handling](#10-sensitive-data-handling)
11. [Date & Time Formatting](#11-date--time-formatting)
12. [Naming Conventions](#12-naming-conventions)
13. [HTTP Status Code Reference](#13-http-status-code-reference)
14. [Real Examples (Anchor Point)](#14-real-examples)

---

## 1. URL & Endpoint Design

### Rules

| Rule | ✅ Correct | ❌ Wrong |
|------|-----------|---------|
| Use nouns, not verbs | `/customers` | `/getCustomers` |
| Plural resource names | `/documents` | `/document` |
| Lowercase with hyphens | `/filing-status` | `/filingStatus`, `/Filing_Status` |
| Nest for relationships | `/customers/:id/documents` | `/customer-documents` |
| Max 2 levels of nesting | `/filings/:id/documents` | `/customers/:id/filings/:fid/documents/:did/versions` |
| Actions as sub-resources | `/documents/:id/approve` | `/approveDocument/:id` |
| Always version | `/api/v1/customers` | `/api/customers` |

### HTTP Method Mapping

| Action | Method | Endpoint | Body? |
|--------|--------|----------|-------|
| List resources | `GET` | `/customers` | No |
| Get single resource | `GET` | `/customers/:id` | No |
| Create resource | `POST` | `/customers` | Yes |
| Full update | `PUT` | `/customers/:id` | Yes |
| Partial update | `PATCH` | `/customers/:id` | Yes |
| Delete resource | `DELETE` | `/customers/:id` | No |
| Custom action | `POST` | `/documents/:id/approve` | Optional |

---

## 2. Standard Response Envelope

**Every API response** must follow this envelope. No exceptions.

### Success Response

```json
{
  "success": true,
  "message": "Documents retrieved successfully",
  "data": { ... },
  "meta": { ... }
}
```

### Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `success` | `boolean` | Always | `true` for 2xx, `false` for 4xx/5xx |
| `message` | `string` | Always | Human-readable summary |
| `data` | `object \| array \| null` | Always | The actual payload. `null` on errors or deletes |
| `meta` | `object \| undefined` | On lists | Pagination info, counts, etc. |

### Single Resource Response

```json
{
  "success": true,
  "message": "Customer retrieved successfully",
  "data": {
    "id": "clx1abc2d0001",
    "email": "rahim@example.com",
    "phone": "+8801712345678",
    "role": "CUSTOMER",
    "status": "ACTIVE",
    "createdAt": "2026-01-15T10:30:00.000Z",
    "profile": {
      "fullName": "Rahim Ahmed",
      "tin": "****5678",
      "taxpayerCategory": "INDIVIDUAL"
    }
  }
}
```

### List Response (with Pagination)

```json
{
  "success": true,
  "message": "Customers retrieved successfully",
  "data": [
    { "id": "clx1abc2d0001", "email": "rahim@example.com", ... },
    { "id": "clx1abc2d0002", "email": "fatima@example.com", ... }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "totalItems": 156,
    "totalPages": 8,
    "hasNextPage": true,
    "hasPreviousPage": false
  }
}
```

### Empty List Response

```json
{
  "success": true,
  "message": "No documents found",
  "data": [],
  "meta": {
    "page": 1,
    "limit": 20,
    "totalItems": 0,
    "totalPages": 0,
    "hasNextPage": false,
    "hasPreviousPage": false
  }
}
```

> ⚠️ **Never return `null` for lists.** Always return an empty array `[]`.

### Delete Response

```json
{
  "success": true,
  "message": "Document deleted successfully",
  "data": null
}
```

### NestJS Implementation

```typescript
// src/common/interfaces/api-response.interface.ts
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T | null;
  meta?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  totalItems: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}
```

```typescript
// src/common/interceptors/transform.interceptor.ts
@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, ApiResponse<T>> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<ApiResponse<T>> {
    return next.handle().pipe(
      map(data => ({
        success: true,
        message: data?.message || 'Success',
        data: data?.data ?? data,
        ...(data?.meta && { meta: data.meta }),
      })),
    );
  }
}
```

---

## 3. Request Bodies

### Creation (POST) — Send all required fields

```json
// POST /api/v1/customer/documents
{
  "filingId": "clx1filing001",
  "category": "SALARY_CERTIFICATE",
  "file": "<multipart>"
}
```

### Rules for Request Bodies

| Rule | Detail |
|------|--------|
| **Use camelCase** | `assessmentYear`, not `assessment_year` or `AssessmentYear` |
| **Don't send IDs for creation** | Server generates all IDs (cuid) |
| **Don't send timestamps** | `createdAt`, `updatedAt` are server-managed |
| **Don't send computed fields** | `totalPages`, `unreadCount` — server calculates these |
| **Send only what's changing** | PATCH requests send only modified fields |
| **Validate everything** | Use DTOs with `class-validator` — never trust client input |
| **Enums as strings** | `"status": "PENDING"`, not `"status": 0` |
| **Boolean as boolean** | `"active": true`, not `"active": "true"` or `"active": 1` |

### DTO Example (NestJS)

```typescript
// src/modules/documents/dto/create-document.dto.ts
import { IsEnum, IsNotEmpty, IsString, IsOptional } from 'class-validator';
import { DocumentCategory } from '@prisma/client';

export class CreateDocumentDto {
  @IsString()
  @IsNotEmpty()
  filingId: string;

  @IsEnum(DocumentCategory)
  category: DocumentCategory;

  @IsString()
  @IsOptional()
  notes?: string;
}
```

### What Clients Should NEVER Send

```json
// ❌ BAD — client trying to set server-controlled fields
{
  "id": "my-custom-id",
  "status": "ACCEPTED",
  "reviewedBy": "admin123",
  "createdAt": "2026-01-01T00:00:00Z",
  "version": 5
}
```

These fields are **ignored or rejected** on the server side. The DTO simply doesn't include them.

---

## 4. Pagination

### Request (Query Parameters)

```
GET /api/v1/admin/customers?page=2&limit=20
```

| Param | Type | Default | Max | Description |
|-------|------|---------|-----|-------------|
| `page` | integer | `1` | — | 1-indexed page number |
| `limit` | integer | `20` | `100` | Items per page |

### Response Meta

```json
{
  "meta": {
    "page": 2,
    "limit": 20,
    "totalItems": 156,
    "totalPages": 8,
    "hasNextPage": true,
    "hasPreviousPage": true
  }
}
```

### NestJS DTO

```typescript
// src/common/dto/pagination.dto.ts
import { IsOptional, IsInt, Min, Max } from 'class-validator';
import { Type } from 'class-transformer';

export class PaginationDto {
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page: number = 1;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit: number = 20;

  get skip(): number {
    return (this.page - 1) * this.limit;
  }
}
```

### Prisma Query Pattern

```typescript
async findAll(dto: PaginationDto) {
  const [data, totalItems] = await Promise.all([
    this.prisma.customer.findMany({
      skip: dto.skip,
      take: dto.limit,
      orderBy: { createdAt: 'desc' },
    }),
    this.prisma.customer.count(),
  ]);

  const totalPages = Math.ceil(totalItems / dto.limit);

  return {
    data,
    meta: {
      page: dto.page,
      limit: dto.limit,
      totalItems,
      totalPages,
      hasNextPage: dto.page < totalPages,
      hasPreviousPage: dto.page > 1,
    },
  };
}
```

---

## 5. Filtering, Sorting & Searching

### URL Pattern

```
GET /api/v1/admin/documents?status=PENDING&category=SALARY_CERTIFICATE&sort=createdAt&order=asc&search=rahim
```

| Param | Type | Description |
|-------|------|-------------|
| `status` | enum | Filter by exact status |
| `category` | enum | Filter by document category |
| `filingYear` | string | Filter by assessment year |
| `dateFrom` | ISO date | Created after this date |
| `dateTo` | ISO date | Created before this date |
| `sort` | string | Field to sort by (default: `createdAt`) |
| `order` | `asc` \| `desc` | Sort direction (default: `desc`) |
| `search` | string | Full-text search on name, email, phone |

### Rules

| Rule | Detail |
|------|--------|
| **Filters in query params** | Never put filters in the request body for GET requests |
| **Unknown filters are ignored** | Don't error on unrecognized query params |
| **Empty filters return all** | `/documents` with no params = all documents (paginated) |
| **Multiple values** | Use comma-separated: `?status=PENDING,ACCEPTED` |
| **Validate enums** | Invalid enum values return 400 with valid options listed |

### DTO Pattern

```typescript
// src/modules/documents/dto/filter-documents.dto.ts
export class FilterDocumentsDto extends PaginationDto {
  @IsOptional()
  @IsEnum(DocumentStatus)
  status?: DocumentStatus;

  @IsOptional()
  @IsEnum(DocumentCategory)
  category?: DocumentCategory;

  @IsOptional()
  @IsString()
  sort?: string = 'createdAt';

  @IsOptional()
  @IsIn(['asc', 'desc'])
  order?: 'asc' | 'desc' = 'desc';

  @IsOptional()
  @IsString()
  search?: string;
}
```

---

## 6. Error Handling

### Error Response Envelope

```json
{
  "success": false,
  "message": "Validation failed",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [
      {
        "field": "email",
        "message": "Email is not a valid email address"
      },
      {
        "field": "phone",
        "message": "Phone number must be a valid BD number (+880XXXXXXXXXX)"
      }
    ]
  },
  "data": null
}
```

### Error Shape

| Field | Type | Description |
|-------|------|-------------|
| `success` | `false` | Always false for errors |
| `message` | `string` | User-friendly summary |
| `error.code` | `string` | Machine-readable error code |
| `error.details` | `array` | Field-level errors (for validation) |
| `data` | `null` | Always null on errors |

### Standard Error Codes

| Code | HTTP | When |
|------|------|------|
| `VALIDATION_ERROR` | 400 | DTO validation failed |
| `BAD_REQUEST` | 400 | Malformed request (not validation) |
| `UNAUTHORIZED` | 401 | Missing or invalid JWT |
| `FORBIDDEN` | 403 | Valid JWT but insufficient role |
| `NOT_FOUND` | 404 | Resource doesn't exist |
| `CONFLICT` | 409 | Duplicate (e.g., email already exists) |
| `GONE` | 410 | Resource was deleted |
| `PAYLOAD_TOO_LARGE` | 413 | File exceeds 10 MB |
| `UNSUPPORTED_MEDIA` | 415 | Invalid file type |
| `RATE_LIMITED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Unhandled server error |

### NestJS Exception Filter

```typescript
// src/common/filters/http-exception.filter.ts
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    let status = 500;
    let message = 'Internal server error';
    let code = 'INTERNAL_ERROR';
    let details = undefined;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const exResponse = exception.getResponse();

      if (typeof exResponse === 'object' && exResponse !== null) {
        message = (exResponse as any).message || message;
        // Handle class-validator errors
        if (Array.isArray(message)) {
          details = message.map(msg => this.parseValidationMessage(msg));
          message = 'Validation failed';
          code = 'VALIDATION_ERROR';
        }
      }
    }

    response.status(status).json({
      success: false,
      message,
      error: { code, ...(details && { details }) },
      data: null,
    });
  }
}
```

### Examples

**404 — Resource Not Found:**
```json
{
  "success": false,
  "message": "Filing not found",
  "error": {
    "code": "NOT_FOUND"
  },
  "data": null
}
```

**409 — Conflict (Duplicate):**
```json
{
  "success": false,
  "message": "A filing already exists for assessment year 2025-2026",
  "error": {
    "code": "CONFLICT"
  },
  "data": null
}
```

**429 — Rate Limited:**
```json
{
  "success": false,
  "message": "Too many requests. Please try again in 45 seconds",
  "error": {
    "code": "RATE_LIMITED",
    "retryAfter": 45
  },
  "data": null
}
```

---

## 7. Authentication Responses

### Login Response

```json
// POST /api/v1/auth/login
// Response: 200
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "clx1abc2d0001",
      "email": "rahim@example.com",
      "role": "CUSTOMER",
      "emailVerified": true,
      "profile": {
        "fullName": "Rahim Ahmed"
      }
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 900
  }
}
```

> ⚠️ **Refresh token** is sent via `Set-Cookie` header (httpOnly, secure, sameSite), **never in the JSON body**.

### Token Refresh Response

```json
// POST /api/v1/auth/refresh
// (refresh token sent via cookie)
// Response: 200
{
  "success": true,
  "message": "Token refreshed",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 900
  }
}
```

### Auth Error — Wrong Credentials

```json
// Response: 401
{
  "success": false,
  "message": "Invalid email or password",
  "error": {
    "code": "UNAUTHORIZED"
  },
  "data": null
}
```

> ⚠️ **Never reveal which field is wrong.** Don't say "password is incorrect" — say "invalid email or password." This prevents email enumeration.

---

## 8. File Uploads

### Upload Request

```
POST /api/v1/customer/documents
Content-Type: multipart/form-data

Fields:
  file: <binary>
  filingId: "clx1filing001"
  category: "SALARY_CERTIFICATE"
```

### Upload Response

```json
{
  "success": true,
  "message": "Document uploaded successfully",
  "data": {
    "id": "clx1doc001",
    "fileName": "salary-2025.pdf",
    "fileSize": 245760,
    "mimeType": "application/pdf",
    "category": "SALARY_CERTIFICATE",
    "status": "PENDING",
    "createdAt": "2026-02-21T10:30:00.000Z"
  }
}
```

### Download Response

```json
// GET /api/v1/customer/documents/:id/download
// Response: 302 redirect to presigned URL
// OR
{
  "success": true,
  "message": "Download URL generated",
  "data": {
    "url": "https://s3.amazonaws.com/...",
    "expiresIn": 900
  }
}
```

### Rules

| Rule | Detail |
|------|--------|
| **Never return S3 keys to clients** | Return presigned URLs or use redirect |
| **Validate MIME on server** | Don't trust `Content-Type` header or file extension |
| **Return file metadata, not file content** | Upload response returns the Document record, not the raw file |
| **Use multipart/form-data** | Not base64 in JSON — that's 33% larger and blocks JSON parsing |
| **Progress on client side** | Use `XMLHttpRequest` or `axios` with `onUploadProgress` |

---

## 9. Partial Updates

### PATCH vs PUT

| Method | When | Body Contains |
|--------|------|--------------|
| `PUT` | Replace the entire resource | All fields (required + optional) |
| `PATCH` | Update specific fields only | Only the fields being changed |

### Our Convention: Use PATCH for most updates

```json
// PATCH /api/v1/customer/profile
// Only updating the phone number
{
  "phone": "+8801812345678"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "id": "clx1profile001",
    "fullName": "Rahim Ahmed",
    "phone": "+8801812345678",
    "email": "rahim@example.com",
    "tin": "****5678",
    ...
  }
}
```

> ⚠️ **Always return the full updated resource** after a PATCH. This prevents the client from needing a separate GET request.

### Use PUT for status actions

```json
// PUT /api/v1/admin/documents/:id/approve
// This is an action, not a partial update
{
  "note": "Document is clear and valid"
}
```

```json
// PUT /api/v1/admin/filings/:id/status
{
  "status": "UNDER_PREPARATION",
  "note": "Starting return preparation"
}
```

---

## 10. Sensitive Data Handling

### Never Expose in Responses

| Field | Rule |
|-------|------|
| `passwordHash` | Never returned. Not even to the user. |
| `refreshToken` | Only in httpOnly cookie, never in JSON |
| `twoFactorSecret` | Never returned after initial setup |
| `internalNotes` | Only in admin responses, never in customer responses |
| `reviewedBy` (internal) | Return reviewer name, not their user ID |

### Mask Sensitive Fields

```json
// ✅ Customer sees their own profile
{
  "tin": "****5678",
  "nid": "********9012",
  "phone": "+880171***5678"
}

// ✅ Admin sees full values (authorized role)
{
  "tin": "123456785678",
  "nid": "1234567890129012",
  "phone": "+8801712345678"
}
```

### NestJS Implementation

```typescript
// Use @Exclude() from class-transformer on sensitive fields
import { Exclude, Transform } from 'class-transformer';

export class UserResponseDto {
  id: string;
  email: string;

  @Exclude()
  passwordHash: string;

  @Exclude()
  twoFactorSecret: string;

  @Transform(({ value }) => value ? `****${value.slice(-4)}` : null)
  tin: string;
}
```

---

## 11. Date & Time Formatting

### Rules

| Rule | Format | Example |
|------|--------|---------|
| All dates in ISO 8601 | `YYYY-MM-DDTHH:mm:ss.sssZ` | `2026-02-21T10:30:00.000Z` |
| Always in UTC | Server stores and returns UTC | Never `+06:00` in responses |
| Client converts to local | Frontend handles timezone display | Bangladesh = UTC+6 |
| Date-only fields | `YYYY-MM-DD` | `2026-11-30` |
| Time-only fields | `HH:mm` | `09:30` |

### Request Example

```json
// Booking a consultation
{
  "scheduledAt": "2026-02-25T08:00:00.000Z",
  "medium": "VIDEO"
}
```

> The client converts "2:00 PM Bangladesh time" to UTC before sending.

### Response Example

```json
{
  "scheduledAt": "2026-02-25T08:00:00.000Z",
  "deadline": "2026-11-30"
}
```

> The frontend displays: "25 Feb 2026, 2:00 PM" (converted from UTC to local).

---

## 12. Naming Conventions

### JSON Fields

| Convention | Example | ❌ Wrong |
|-----------|---------|---------|
| camelCase | `firstName` | `first_name`, `FirstName` |
| Boolean as `is`/`has`/`can` | `isVerified`, `hasFilings` | `verified`, `filingsExist` |
| Counts as `xxxCount` | `unreadCount` | `unread`, `numUnread` |
| IDs as `xxxId` | `filingId`, `userId` | `filing`, `user_id` |
| Dates as `xxxAt` | `createdAt`, `filedAt` | `createDate`, `date_filed` |
| Arrays as plural | `documents`, `tags` | `documentList`, `tagArray` |

### Enum Values

```
// SCREAMING_SNAKE_CASE
"status": "UNDER_PREPARATION"
"category": "SALARY_CERTIFICATE"
"role": "SUPER_ADMIN"
"medium": "VIDEO"
```

### URL Segments

```
// kebab-case
/api/v1/customer/filing-status
/api/v1/admin/audit-logs
/api/v1/admin/email-templates
```

---

## 13. HTTP Status Code Reference

### Success Codes

| Code | When to Use | Example |
|------|-------------|---------|
| `200 OK` | GET, PATCH, PUT, action succeeded | Get customer, update profile |
| `201 Created` | POST that creates a resource | Create filing, upload document |
| `204 No Content` | DELETE with no response body | Delete a draft document |

### Client Error Codes

| Code | When to Use | Example |
|------|-------------|---------|
| `400 Bad Request` | Malformed request or validation error | Missing required field |
| `401 Unauthorized` | No token or expired token | Unauthenticated request |
| `403 Forbidden` | Valid token but wrong role | Customer accessing admin endpoint |
| `404 Not Found` | Resource doesn't exist | Filing ID that doesn't exist |
| `409 Conflict` | Duplicate or state conflict | Filing already exists for this year |
| `413 Payload Too Large` | File exceeds size limit | Upload > 10 MB |
| `415 Unsupported Media Type` | Wrong file type | .exe file uploaded |
| `422 Unprocessable Entity` | Semantically invalid | Booking a past date |
| `429 Too Many Requests` | Rate limit hit | 6th login attempt in 1 minute |

### Server Error Codes

| Code | When to Use |
|------|-------------|
| `500 Internal Server Error` | Unhandled exception (log it, alert Sentry) |
| `502 Bad Gateway` | Upstream service failed (payment gateway, SMS API) |
| `503 Service Unavailable` | Maintenance mode active |

### Decision Flowchart

```
Is the request valid?
├── No → Is it a format issue? → 400
│       Is it an auth issue? → 401 (no token) / 403 (wrong role)
│       Does the resource exist? → 404
│       Is it a duplicate? → 409
│       Is it semantically wrong? → 422
├── Yes → Did we create something? → 201
│         Did we delete with no response? → 204
│         Everything else successful → 200
│         Did our server break? → 500
│         Did an external service fail? → 502
```

---

## 14. Real Examples (Anchor Point)

### Example 1: Customer Uploads a Document

**Request:**
```
POST /api/v1/customer/documents
Authorization: Bearer eyJhbGc...
Content-Type: multipart/form-data

file: salary-certificate-2025.pdf (245 KB)
filingId: clx1filing001
category: SALARY_CERTIFICATE
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Document uploaded successfully",
  "data": {
    "id": "clx1doc001",
    "filingId": "clx1filing001",
    "category": "SALARY_CERTIFICATE",
    "fileName": "salary-certificate-2025.pdf",
    "fileSize": 251904,
    "mimeType": "application/pdf",
    "status": "PENDING",
    "version": 1,
    "createdAt": "2026-02-21T10:30:00.000Z"
  }
}
```

### Example 2: Admin Rejects a Document

**Request:**
```
PUT /api/v1/admin/documents/clx1doc002/reject
Authorization: Bearer eyJhbGc...
Content-Type: application/json

{
  "reason": "Bank statement only covers January to March. Please upload the full 6-month statement (January to June 2025)."
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Document rejected",
  "data": {
    "id": "clx1doc002",
    "category": "BANK_STATEMENT",
    "status": "REJECTED",
    "rejectionNote": "Bank statement only covers January to March. Please upload the full 6-month statement (January to June 2025).",
    "reviewedAt": "2026-02-21T11:00:00.000Z",
    "reviewedBy": "Arif Hossain"
  }
}
```

### Example 3: Customer Lists Their Filings

**Request:**
```
GET /api/v1/customer/filings?page=1&limit=10&sort=assessmentYear&order=desc
Authorization: Bearer eyJhbGc...
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Filings retrieved successfully",
  "data": [
    {
      "id": "clx1filing001",
      "assessmentYear": "2025-2026",
      "serviceType": "individual",
      "status": "UNDER_PREPARATION",
      "deadline": "2026-11-30",
      "daysRemaining": 282,
      "advisor": {
        "id": "clx1advisor001",
        "name": "Arif Hossain"
      },
      "documentStats": {
        "required": 5,
        "uploaded": 4,
        "accepted": 3,
        "rejected": 1
      },
      "createdAt": "2026-02-15T08:00:00.000Z"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 10,
    "totalItems": 1,
    "totalPages": 1,
    "hasNextPage": false,
    "hasPreviousPage": false
  }
}
```

### Example 4: Payment Initiation

**Request:**
```
POST /api/v1/customer/payments/initiate
Authorization: Bearer eyJhbGc...
Content-Type: application/json

{
  "serviceType": "TAX_FILING",
  "filingId": "clx1filing001",
  "method": "BKASH",
  "couponCode": "WELCOME2026"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Payment initiated. Redirecting to bKash...",
  "data": {
    "paymentId": "clx1pay001",
    "amount": 1500.00,
    "discount": 150.00,
    "finalAmount": 1350.00,
    "currency": "BDT",
    "method": "BKASH",
    "gatewayUrl": "https://tokenized.sandbox.bka.sh/v1.2.0-beta/...",
    "expiresAt": "2026-02-21T11:00:00.000Z"
  }
}
```

### Example 5: Validation Error

**Request:**
```
POST /api/v1/auth/register
Content-Type: application/json

{
  "email": "not-an-email",
  "phone": "123",
  "password": "weak"
}
```

**Response (400 Bad Request):**
```json
{
  "success": false,
  "message": "Validation failed",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [
      {
        "field": "email",
        "message": "Must be a valid email address"
      },
      {
        "field": "phone",
        "message": "Must be a valid Bangladesh phone number (+880XXXXXXXXXX)"
      },
      {
        "field": "password",
        "message": "Must be at least 8 characters with uppercase, lowercase, and number"
      }
    ]
  },
  "data": null
}
```

### Example 6: Admin Dashboard KPIs

**Request:**
```
GET /api/v1/admin/dashboard
Authorization: Bearer eyJhbGc...
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Dashboard data retrieved",
  "data": {
    "totalCustomers": 156,
    "totalCustomersChange": 12.5,
    "activeFilings": 23,
    "activeFilingsChange": -4.2,
    "revenueThisMonth": 47500.00,
    "revenueThisMonthChange": 23.1,
    "revenueYtd": 285000.00,
    "pendingDocuments": 8,
    "openTickets": 3,
    "overdueFilings": 1,
    "upcomingConsultations": 4,
    "recentActivity": [
      {
        "type": "PAYMENT",
        "description": "Rahim Ahmed paid BDT 1,500 for Tax Filing",
        "createdAt": "2026-02-21T09:15:00.000Z"
      },
      {
        "type": "DOCUMENT",
        "description": "Fatima Khan uploaded Salary Certificate",
        "createdAt": "2026-02-21T08:45:00.000Z"
      }
    ]
  }
}
```

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────┐
│              API RESPONSE CHEAT SHEET                │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ✅ SUCCESS                 ❌ ERROR                 │
│  {                          {                       │
│    "success": true,           "success": false,     │
│    "message": "...",          "message": "...",     │
│    "data": { ... },           "error": {            │
│    "meta": { ... }              "code": "...",      │
│  }                              "details": [...]    │
│                               },                    │
│                               "data": null          │
│                             }                       │
│                                                     │
│  LIST: data = []  (never null)                      │
│  DELETE: data = null                                │
│  CREATE: 201 + data = created resource              │
│  UPDATE: 200 + data = full updated resource         │
│                                                     │
│  Dates: Always UTC ISO 8601                         │
│  Enums: SCREAMING_SNAKE_CASE                        │
│  Fields: camelCase                                  │
│  URLs: kebab-case                                   │
│  Sensitive: Mask or exclude                         │
└─────────────────────────────────────────────────────┘
```
