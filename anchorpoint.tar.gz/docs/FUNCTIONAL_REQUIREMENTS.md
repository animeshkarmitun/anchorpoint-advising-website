# Anchor Point Advising — Functional Requirements Document (FRD)

> **Last Updated:** 21 February 2026
> **Version:** 1.0
> **Traceability:** Each FR maps to User Stories (US-xx) from `USER_JOURNEYS.md`

---

## Conventions

| Field | Format | Example |
|-------|--------|---------|
| **FR ID** | `FR-{MODULE}-{NNN}` | `FR-AUTH-001` |
| **Priority** | P0 (MVP), P1 (Core), P2 (Growth), P3 (Future) | P0 |
| **Source** | User Story ID(s) | US-07, US-08 |
| **Acceptance Criteria** | Testable conditions that must all pass | Given/When/Then |

### Module Codes

| Code | Module |
|------|--------|
| AUTH | Authentication & Authorization |
| USR | User Profile & Settings |
| DOC | Document Management |
| FIL | Tax Filing Lifecycle |
| PAY | Payments & Billing |
| CON | Consultation & Appointments |
| MSG | Messaging & Communication |
| NTF | Notifications |
| TKT | Support Tickets |
| CMS | Content Management |
| SEO | SEO Management |
| RPT | Reporting & Analytics |
| SYS | System & Settings |
| SEC | Security & Infrastructure |

---

## FR-AUTH: Authentication & Authorization

### FR-AUTH-001 — Email/Password Registration
- **Priority:** P0 | **Source:** US-07
- **Description:** A visitor can create a customer account using name, email, phone number, and password.
- **Acceptance Criteria:**
  1. Email must be unique and valid format
  2. Phone must be unique and valid BD format (+880XXXXXXXXXX)
  3. Password must be min 8 chars, include uppercase, lowercase, and number
  4. On success: account created with role `CUSTOMER`, status `ACTIVE`, `emailVerified: false`
  5. A verification email is sent automatically
  6. User is redirected to the onboarding wizard

### FR-AUTH-002 — Phone/OTP Registration & Login
- **Priority:** P0 | **Source:** US-07
- **Description:** A visitor can register or log in using their phone number and a one-time password sent via SMS.
- **Acceptance Criteria:**
  1. System sends a 6-digit OTP to the provided BD phone number
  2. OTP expires after 5 minutes
  3. Max 3 OTP requests per phone number per hour
  4. On verification: if phone exists → login; if new → create account
  5. `phoneVerified` is set to `true`

### FR-AUTH-003 — Google OAuth
- **Priority:** P1 | **Source:** US-08
- **Description:** A visitor can sign up or log in using their Google account.
- **Acceptance Criteria:**
  1. "Continue with Google" button initiates OAuth 2.0 flow
  2. On first login: account created with Google email, `emailVerified: true`, `authProvider: GOOGLE`
  3. On subsequent login: existing account matched by email
  4. Google profile photo is saved if available

### FR-AUTH-004 — Email Verification
- **Priority:** P0 | **Source:** US-07
- **Description:** Customers who register via email must verify their email address.
- **Acceptance Criteria:**
  1. Verification link sent to registered email
  2. Link contains a signed token, valid for 24 hours
  3. Clicking the link sets `emailVerified: true`
  4. Expired links show "link expired" with a "Resend" option
  5. Unverified users can access the dashboard but cannot initiate filings

### FR-AUTH-005 — Password Reset
- **Priority:** P0 | **Source:** US-07
- **Description:** A customer can reset their forgotten password via email.
- **Acceptance Criteria:**
  1. "Forgot Password" sends a reset link to the registered email
  2. Reset token valid for 1 hour, single-use
  3. New password must meet the same strength requirements as registration
  4. All existing sessions are invalidated after password reset
  5. Confirmation email sent after successful reset

### FR-AUTH-006 — JWT Session Management
- **Priority:** P0 | **Source:** US-07
- **Description:** The system uses JWT-based authentication with refresh token rotation.
- **Acceptance Criteria:**
  1. Access token: 15 minutes expiry, sent in Authorization header
  2. Refresh token: 7 days expiry, stored in httpOnly secure cookie
  3. Refresh endpoint issues new access + refresh token (rotation)
  4. Old refresh tokens are invalidated on use
  5. Logout invalidates all tokens for that user

### FR-AUTH-007 — Role-Based Access Control
- **Priority:** P0 | **Source:** US-38, US-42
- **Description:** The system enforces role-based permissions on all protected resources.
- **Acceptance Criteria:**
  1. Five roles: `CUSTOMER`, `TAX_ADVISOR`, `OPERATIONS`, `SUPPORT`, `SUPER_ADMIN`
  2. Customer endpoints reject non-CUSTOMER roles (and vice versa for admin)
  3. SUPER_ADMIN has access to all admin endpoints
  4. TAX_ADVISOR can only access filings/documents/messages assigned to them
  5. SUPPORT can only access tickets and messages
  6. OPERATIONS can access CMS, analytics, and settings
  7. Unauthorized access returns 403 with a descriptive error

### FR-AUTH-008 — Admin Login with 2FA
- **Priority:** P1 | **Source:** US-46
- **Description:** Admin/staff accounts require two-factor authentication.
- **Acceptance Criteria:**
  1. After email/password, admin is prompted for TOTP code
  2. Supports Google Authenticator / Authy
  3. 2FA setup includes QR code + backup codes (8 codes)
  4. Failed 2FA attempts: max 5 before account lockout (30 min)

### FR-AUTH-009 — Premium-Gated Registration (Configurable)
- **Priority:** P0 | **Source:** —
- **Description:** Public visitor registration can be restricted by the admin. When gated, visitors cannot create accounts freely — they must be invited or registration is disabled. When open, standard self-service registration is available.
- **Acceptance Criteria:**
  1. Registration behavior is controlled by a system setting `registration_mode` with values:
     - `OPEN` — Anyone can register (default)
     - `INVITE_ONLY` — Registration requires a valid invite token (generated by admin)
     - `DISABLED` — Registration page shows "Registration is currently closed" message
  2. When `INVITE_ONLY`:
     - Registration form requires an `inviteToken` field
     - Admin can generate invite links from `Admin: Settings → Registration`
     - Each invite can be single-use or multi-use (with max uses)
     - Invite links have configurable expiry (default: 7 days)
  3. When `DISABLED`:
     - `/register` route redirects to landing page with a toast: "Registration is currently closed. Contact us for access."
     - Login still works for existing users
  4. Admin can switch modes instantly from the admin panel (FR-SYS-005)
  5. The current mode is reflected on the public website navbar:
     - `OPEN`: "Register" button visible
     - `INVITE_ONLY`: "Register" button hidden (invite link contains the token)
     - `DISABLED`: "Register" button hidden
  6. Mode change logged in AuditLog

---

## FR-USR: User Profile & Settings

### FR-USR-001 — Onboarding Wizard
- **Priority:** P1 | **Source:** US-09, US-10
- **Description:** After registration, the customer is guided through a multi-step onboarding process.
- **Acceptance Criteria:**
  1. Step 1: Full name, NID number (optional), date of birth
  2. Step 2: TIN number (optional), tax zone/circle (optional)
  3. Step 3: Income sources (multi-select: salary, business, freelance, rental, investment, other)
  4. Step 4: Taxpayer category (individual, company, partnership)
  5. Each step is skippable (can complete later from profile)
  6. Progress is saved if user navigates away
  7. Completed flag shown on dashboard

### FR-USR-002 — Profile Management
- **Priority:** P0 | **Source:** US-09
- **Description:** Customers can view and edit their personal and taxpayer information.
- **Acceptance Criteria:**
  1. Editable fields: name, phone, address, district, NID, TIN, tax zone/circle, income sources, employer/business name
  2. Email change requires re-verification
  3. Phone change requires OTP verification
  4. NID and TIN are masked in the UI (show last 4 digits only)
  5. Changes are saved immediately with success feedback

### FR-USR-003 — Change Password
- **Priority:** P0 | **Source:** US-07
- **Description:** Customers can change their password from their profile settings.
- **Acceptance Criteria:**
  1. Requires current password to set new password
  2. New password must meet strength requirements
  3. All other sessions are invalidated
  4. Confirmation email sent

### FR-USR-004 — Language Preference
- **Priority:** P1 | **Source:** US-02
- **Description:** Customers can switch the interface language between English and Bangla.
- **Acceptance Criteria:**
  1. Language toggle visible in navbar and profile settings
  2. Preference saved to `CustomerProfile.language`
  3. All UI labels, buttons, notifications respect the preference
  4. Language persists across sessions (not just the current visit)

### FR-USR-005 — Notification Preferences
- **Priority:** P1 | **Source:** US-36
- **Description:** Customers can control which notification channels are active.
- **Acceptance Criteria:**
  1. Toggle email notifications on/off
  2. Toggle SMS notifications on/off
  3. Categories: Filing Updates, Payment Receipts, Deadline Reminders, Promotions
  4. Critical system notifications (security alerts) cannot be disabled
  5. Preferences saved to `CustomerProfile`

---

## FR-DOC: Document Management

### FR-DOC-001 — Document Upload
- **Priority:** P0 | **Source:** US-12
- **Description:** Customers can upload documents to their account, associated with a specific filing.
- **Acceptance Criteria:**
  1. Supports drag-and-drop and file browser
  2. Accepted formats: PDF, JPG, JPEG, PNG, DOCX
  3. Max file size: 10 MB per file
  4. Upload shows real-time progress bar (percentage)
  5. File is stored in S3 with a unique key: `users/{userId}/filings/{filingId}/{category}/{timestamp}_{filename}`
  6. On success: Document record created with status `PENDING`
  7. Invalid file type or size shows clear error message before upload attempt

### FR-DOC-002 — Document Categorization
- **Priority:** P0 | **Source:** US-11
- **Description:** Each uploaded document must be categorized.
- **Acceptance Criteria:**
  1. Customer selects category from dropdown before/during upload: NID, TIN Certificate, Salary Certificate, Bank Statement, Rental Agreement, Investment Proof, Previous Return, Trade License, Asset Statement, Other
  2. Category is stored in the `Document` record
  3. Documents filterable by category in the customer's document list

### FR-DOC-003 — Upload Checklist
- **Priority:** P0 | **Source:** US-11, US-17
- **Description:** The system shows a dynamic checklist of required documents based on the customer's filing type.
- **Acceptance Criteria:**
  1. Checklist is generated based on `serviceType` (individual, corporate, NRB)
  2. Individual filing requires: NID, TIN Certificate, Salary Certificate, Bank Statement
  3. Corporate filing requires: Trade License, TIN, Audited Accounts, Bank Statement
  4. NRB filing requires: Passport, TIN, Property Documents, Bank Statement
  5. Each item shows: ⬜ Not uploaded / ⏳ Pending review / ✅ Accepted / ❌ Rejected
  6. Previously accepted documents from prior years can be "reused" with one click (FR-DOC-009)

### FR-DOC-004 — Document Status Tracking
- **Priority:** P0 | **Source:** US-13, US-14
- **Description:** Each document has a visible status that changes as admins review it.
- **Acceptance Criteria:**
  1. Statuses: `PENDING` → `ACCEPTED` or `REJECTED` or `NEEDS_REUPLOAD`
  2. Status visible on document card/row in customer's document list
  3. Color-coded: yellow (pending), green (accepted), red (rejected), orange (needs re-upload)
  4. Rejected documents show the admin's rejection reason prominently
  5. Status change triggers a notification (FR-NTF-002)

### FR-DOC-005 — Document Preview
- **Priority:** P1 | **Source:** US-15
- **Description:** Customers can preview uploaded documents in the browser without downloading.
- **Acceptance Criteria:**
  1. PDF preview via embedded viewer (iframe or PDF.js)
  2. Image preview (JPG, PNG) shown in lightbox/modal
  3. DOCX shows "Preview not available — download to view" with download button
  4. Preview loads from S3 presigned URL (valid 15 min)

### FR-DOC-006 — Document Download
- **Priority:** P0 | **Source:** US-21
- **Description:** Customers and admins can download documents.
- **Acceptance Criteria:**
  1. Download generates a short-lived presigned S3 URL (15 min)
  2. URL is never exposed in the frontend; backend redirects to it
  3. Download logged in audit trail (who downloaded what, when)

### FR-DOC-007 — Document Re-Upload (Version History)
- **Priority:** P1 | **Source:** US-16
- **Description:** Customers can replace a rejected document with a corrected version.
- **Acceptance Criteria:**
  1. "Re-upload" button visible only on `REJECTED` or `NEEDS_REUPLOAD` documents
  2. New upload creates a new Document record with `parentId` pointing to the original
  3. `version` field incremented (v1 → v2 → v3)
  4. Previous versions remain accessible to admins but hidden from customer by default
  5. New upload resets status to `PENDING`

### FR-DOC-008 — Bulk Upload
- **Priority:** P1 | **Source:** US-12
- **Description:** Customers can upload multiple files at once.
- **Acceptance Criteria:**
  1. Multi-file selection via file browser or drag-and-drop
  2. Max 10 files per upload batch
  3. Each file shows individual progress bar
  4. Failed uploads don't block successful ones
  5. After batch: summary showing ✅ uploaded / ❌ failed per file

### FR-DOC-009 — Reuse Previous Year Documents
- **Priority:** P1 | **Source:** US-17
- **Description:** Returning customers can carry forward accepted documents from the previous assessment year.
- **Acceptance Criteria:**
  1. Checklist shows "Reuse from 2024-2025?" toggle per document category
  2. Reused documents are cloned (new Document record pointing to same S3 key)
  3. Status set to `ACCEPTED` (no re-review needed)
  4. Only `ACCEPTED` documents from the most recent prior filing are eligible

### FR-DOC-010 — Admin: Document Review Queue
- **Priority:** P0 | **Source:** US-39
- **Description:** Admins see a prioritized queue of documents awaiting review.
- **Acceptance Criteria:**
  1. Queue shows all documents with status `PENDING` across all customers
  2. Sortable by: upload date (oldest first), customer name, document category
  3. Filterable by: category, filing year, assigned advisor
  4. Each row shows: customer name, category, file thumbnail, upload date, filing deadline
  5. Click opens document preview + action buttons

### FR-DOC-011 — Admin: Approve/Reject Document
- **Priority:** P0 | **Source:** US-39
- **Description:** Admins can approve or reject a document from the review queue.
- **Acceptance Criteria:**
  1. "Approve" → status changes to `ACCEPTED`, `reviewedBy` and `reviewedAt` set
  2. "Reject" → modal requires a rejection reason (min 10 chars), status → `REJECTED`
  3. "Request Re-upload" → status → `NEEDS_REUPLOAD` with specific instructions
  4. Each action triggers customer notification
  5. Action is logged in `AuditLog`

### FR-DOC-012 — Admin: Request Additional Documents
- **Priority:** P1 | **Source:** US-39
- **Description:** Admins can send a document request to a customer specifying what's needed.
- **Acceptance Criteria:**
  1. Admin selects customer, selects document category, writes a note
  2. Customer receives notification with the request details
  3. Request appears as a "missing document" in the customer's checklist
  4. Admin can see pending requests per customer

---

## FR-FIL: Tax Filing Lifecycle

### FR-FIL-001 — Initiate Filing
- **Priority:** P0 | **Source:** US-18
- **Description:** A customer can start a new tax filing for a specific assessment year.
- **Acceptance Criteria:**
  1. Customer selects assessment year (e.g., "2025-2026") and service type
  2. Only one filing per customer per assessment year (unique constraint)
  3. Filing created with status `INITIATED`
  4. Document checklist auto-generated based on service type (FR-DOC-003)
  5. If unpaid: status remains `INITIATED`, prompts payment

### FR-FIL-002 — Filing Status Progress Bar
- **Priority:** P0 | **Source:** US-18, US-23
- **Description:** The dashboard displays a visual progress tracker for each active filing.
- **Acceptance Criteria:**
  1. Progress stages displayed as a horizontal stepper or progress bar:
     `Initiated → Documents Pending → Documents Received → Under Preparation → Review Ready → Customer Approved → E-Filed → Acknowledged → Completed`
  2. Current stage highlighted with active color
  3. Completed stages show checkmarks
  4. Each stage shows the date it was reached (if applicable)
  5. Deadline countdown shown below: "X days remaining"

### FR-FIL-003 — Filing Status Updates (Admin)
- **Priority:** P0 | **Source:** US-40
- **Description:** Admins can advance or change the filing status.
- **Acceptance Criteria:**
  1. Status dropdown with all valid statuses
  2. Status change creates a `FilingStatusLog` entry (from, to, changedBy, note)
  3. Customer notification triggered on every status change
  4. Status can only move forward (or to `ON_HOLD`) — no arbitrary backwards jumps without admin note
  5. Bulk status update available (select multiple filings → change status)

### FR-FIL-004 — Return Preview (Customer Approval)
- **Priority:** P1 | **Source:** US-20
- **Description:** When the return is prepared, the customer can preview key figures before approving.
- **Acceptance Criteria:**
  1. Available only when filing status is `REVIEW_READY`
  2. Read-only view showing: Total Income, Tax Payable, Tax Already Paid (TDS), Net Payable/Refund
  3. Two actions: "Approve & Proceed to Filing" or "Dispute" (with reason text area)
  4. Approve → status moves to `CUSTOMER_APPROVED`
  5. Dispute → status reverts to `UNDER_PREPARATION`, admin notified with dispute note

### FR-FIL-005 — Upload Filed Return (Admin)
- **Priority:** P0 | **Source:** US-21
- **Description:** After e-filing, the admin uploads the return copy and acknowledgement.
- **Acceptance Criteria:**
  1. Admin uploads 1-2 PDFs: Filed Return, Acknowledgement Receipt
  2. Documents saved with category `FILED_RETURN` and `ACKNOWLEDGEMENT`
  3. Filing status updated to `E_FILED` or `ACKNOWLEDGED`
  4. Customer notified and can download from their dashboard

### FR-FIL-006 — Deadline Tracker
- **Priority:** P0 | **Source:** US-23, US-43
- **Description:** The system tracks filing deadlines and escalates approaching ones.
- **Acceptance Criteria:**
  1. Default deadline: 30 November of the assessment year
  2. Dashboard shows countdown for each active filing
  3. Automated notifications at: 30 days, 14 days, 7 days, 3 days, 1 day before deadline
  4. Admin view: sorted list of all filings by deadline proximity
  5. Overdue filings highlighted in red across both customer and admin dashboards

### FR-FIL-007 — Filing History
- **Priority:** P1 | **Source:** US-22
- **Description:** Customers can view their filing history across all assessment years.
- **Acceptance Criteria:**
  1. List of all filings: assessment year, status, service type, filed date, key figures
  2. Click to expand: full detail view with documents, status history, payments
  3. Year-over-year comparison view (income, tax paid, refund — side by side)

### FR-FIL-008 — Advisor Assignment
- **Priority:** P0 | **Source:** US-43
- **Description:** Admins can assign or reassign a filing to a specific tax advisor.
- **Acceptance Criteria:**
  1. Assignment dropdown showing available advisors with current workload count
  2. Auto-assignment option: based on lowest workload
  3. Reassignment notifies both old advisor, new advisor, and customer
  4. Advisor can only see filings assigned to them (unless SUPER_ADMIN)

---

## FR-PAY: Payments & Billing

### FR-PAY-001 — Payment Initiation
- **Priority:** P0 | **Source:** US-24
- **Description:** Customers can pay for services via integrated payment gateways.
- **Acceptance Criteria:**
  1. Payment methods: bKash, Nagad, Rocket, Credit/Debit Card (via SSLCommerz)
  2. Customer selects service → sees amount → selects payment method → redirected to gateway
  3. Payment record created with status `PENDING`
  4. On success callback (IPN): status → `COMPLETED`, filing activated
  5. On failure: status → `FAILED`, customer shown retry option

### FR-PAY-002 — IPN (Instant Payment Notification) Handling
- **Priority:** P0 | **Source:** US-24
- **Description:** The system handles asynchronous payment confirmations from gateways.
- **Acceptance Criteria:**
  1. Dedicated IPN endpoint per gateway
  2. Validates gateway signature/hash to prevent tampering
  3. Idempotent: duplicate IPN for same transaction is ignored
  4. Updates payment status and triggers downstream actions (filing activation, notifications)
  5. Failed IPN validation logged as security event

### FR-PAY-003 — Invoice Generation
- **Priority:** P0 | **Source:** US-25
- **Description:** An invoice is automatically generated for every completed payment.
- **Acceptance Criteria:**
  1. Invoice number format: `APA-{YEAR}-{SEQ}` (e.g., `APA-2026-0042`)
  2. Invoice contains: company details, customer details, service description, amount, tax (if applicable), payment method, date
  3. Generated as PDF and stored in S3
  4. Available for download from customer's payment history

### FR-PAY-004 — Payment History
- **Priority:** P0 | **Source:** US-26
- **Description:** Customers can view all their past transactions.
- **Acceptance Criteria:**
  1. List shows: date, service name, amount, payment method, status, invoice link
  2. Filterable by: date range, status
  3. Each row has: "Download Invoice" button
  4. Total spent shown at top

### FR-PAY-005 — Coupon/Promo Code
- **Priority:** P2 | **Source:** US-27
- **Description:** Customers can apply discount codes during checkout.
- **Acceptance Criteria:**
  1. "Have a promo code?" field on payment page
  2. Real-time validation: valid/invalid/expired/already used
  3. Shows discount amount before payment
  4. Discount recorded in Payment record (`couponId`, `discountAmount`)

### FR-PAY-006 — Refund Request (Customer)
- **Priority:** P1 | **Source:** US-28
- **Description:** Customers can request a refund for a completed payment.
- **Acceptance Criteria:**
  1. "Request Refund" button on payment detail (only for `COMPLETED` payments)
  2. Customer provides reason (text, min 20 chars)
  3. Refund record created with status `pending`
  4. Admin notified of new refund request

### FR-PAY-007 — Refund Processing (Admin)
- **Priority:** P1 | **Source:** US-28
- **Description:** Admins can approve and process refund requests.
- **Acceptance Criteria:**
  1. Refund queue shows all pending requests
  2. Admin can: Approve (full/partial amount), or Reject (with reason)
  3. Approved refunds processed via original payment method's API
  4. Payment status updated to `REFUNDED` or `PARTIALLY_REFUNDED`
  5. Customer notified of outcome
  6. Audit log entry created

---

## FR-CON: Consultations & Appointments

### FR-CON-001 — View Available Slots
- **Priority:** P0 | **Source:** US-30
- **Description:** Customers can see available consultation time slots.
- **Acceptance Criteria:**
  1. Calendar view showing available dates (highlighted) for the next 30 days
  2. Selecting a date shows available time slots (based on AdvisorSchedule minus existing bookings)
  3. Slots shown in customer's timezone (detected or manually set)
  4. Past dates and fully booked dates are greyed out

### FR-CON-002 — Book Consultation
- **Priority:** P0 | **Source:** US-29, US-30
- **Description:** Customers can book a consultation by selecting a slot and paying.
- **Acceptance Criteria:**
  1. Customer selects: date, time slot, medium (phone/video/in-person)
  2. Payment of BDT 300 required to confirm
  3. On payment success: consultation created with status `SCHEDULED`
  4. Auto-assigned to available advisor (or customer chooses)
  5. Confirmation email/SMS sent with details and calendar invite (.ics)
  6. If video: Google Meet link auto-generated and included

### FR-CON-003 — Reschedule Consultation
- **Priority:** P1 | **Source:** US-33
- **Description:** Customers can reschedule their upcoming consultation.
- **Acceptance Criteria:**
  1. Reschedule allowed up to 2 hours before the scheduled time
  2. Customer picks new slot from available options
  3. Old slot freed for others
  4. Updated confirmation sent
  5. Max 2 reschedules per booking

### FR-CON-004 — Cancel Consultation
- **Priority:** P1 | **Source:** US-33
- **Description:** Customers can cancel their consultation.
- **Acceptance Criteria:**
  1. Cancellation allowed up to 24 hours before → full refund
  2. Within 24 hours → no refund (or 50% — business decision)
  3. Status → `CANCELLED`, `cancelledAt` and `cancelReason` recorded
  4. Refund processed automatically if eligible

### FR-CON-005 — Consultation Reminders
- **Priority:** P1 | **Source:** US-31
- **Description:** Automated reminders before each consultation.
- **Acceptance Criteria:**
  1. Email reminder: 24 hours before
  2. SMS reminder: 1 hour before
  3. In-app notification: 15 minutes before
  4. Includes: time, medium, meeting link (if video), advisor name

### FR-CON-006 — Post-Consultation Notes
- **Priority:** P1 | **Source:** US-32
- **Description:** Advisors write session notes after a consultation; customers can view them.
- **Acceptance Criteria:**
  1. After status changes to `COMPLETED`, advisor can add/edit notes and follow-up actions
  2. Notes visible to the customer in their consultation history
  3. Follow-up items appear as tasks/notifications on the customer's dashboard

---

## FR-MSG: Messaging & Communication

### FR-MSG-001 — In-App Chat
- **Priority:** P1 | **Source:** US-34
- **Description:** Customers can send real-time messages to their assigned tax advisor.
- **Acceptance Criteria:**
  1. Chat window accessible from dashboard sidebar or dedicated messages page
  2. Messages delivered in real-time via WebSocket
  3. Offline messages stored and delivered on next connection
  4. Message shows: sender avatar, content, timestamp, read receipt (✓✓)
  5. Typing indicator shown when the other party is typing

### FR-MSG-002 — File Sharing in Chat
- **Priority:** P1 | **Source:** US-35
- **Description:** Users can share files within the chat.
- **Acceptance Criteria:**
  1. Attachment button allows file selection (same validations as FR-DOC-001)
  2. File uploaded to S3, link embedded in message
  3. Inline preview for images; download link for PDFs/other
  4. Max 5 MB per chat attachment

### FR-MSG-003 — Admin: Broadcast Notification
- **Priority:** P1 | **Source:** US-44
- **Description:** Admins can send a message to all customers or a filtered segment.
- **Acceptance Criteria:**
  1. Compose broadcast: title, body, optional link
  2. Target: All customers, or filtered by: status (active/inactive), filing status, assessment year
  3. Delivery channels: In-app notification + email (optional) + SMS (optional)
  4. Scheduled send option (send now or schedule for later)
  5. Delivery report: sent count, opened count

---

## FR-NTF: Notifications

### FR-NTF-001 — In-App Notification Center
- **Priority:** P0 | **Source:** US-19
- **Description:** A notification bell in the header showing unread notifications.
- **Acceptance Criteria:**
  1. Bell icon with unread count badge
  2. Dropdown shows last 10 notifications
  3. "View All" opens full notification list with pagination
  4. Click notification → mark as read + navigate to relevant page
  5. "Mark all as read" button
  6. Real-time updates via WebSocket (new notification appears instantly)

### FR-NTF-002 — Notification Triggers
- **Priority:** P0 | **Source:** US-19, US-36
- **Description:** Specific events auto-generate notifications to the relevant user.
- **Triggers:**
  1. Document status changed (accepted/rejected) → Customer
  2. Filing status changed → Customer
  3. Payment confirmed → Customer
  4. Consultation reminder (24h, 1h) → Customer
  5. New message received → Recipient
  6. Refund processed → Customer
  7. New support ticket reply → Customer or Admin
  8. Document request from admin → Customer
  9. New filing assigned → Advisor
  10. Deadline approaching (30d, 14d, 7d, 3d, 1d) → Customer
  11. Broadcast message → Targeted customers

### FR-NTF-003 — Email Notifications
- **Priority:** P0 | **Source:** US-36
- **Description:** Critical events send branded HTML emails.
- **Acceptance Criteria:**
  1. Emails use branded templates (Anchor Point logo, colors)
  2. Supports Bangla and English based on customer preference
  3. Unsubscribe link at bottom (respects FR-USR-005 preferences)
  4. Sent via Brevo/Resend transactional email API

### FR-NTF-004 — SMS Notifications
- **Priority:** P1 | **Source:** US-36
- **Description:** Critical events send SMS to the customer's phone.
- **Acceptance Criteria:**
  1. SMS sent for: payment confirmation, consultation reminder (1h), deadline warning (7d, 1d)
  2. SMS in Bangla or English based on preference
  3. Uses BD SMS gateway API (BulkSMSBD or similar)
  4. Max 160 chars (standard SMS)

---

## FR-TKT: Support Tickets

### FR-TKT-001 — Create Ticket (Customer)
- **Priority:** P1 | **Source:** US-37
- **Description:** Customers can submit support tickets for issues.
- **Acceptance Criteria:**
  1. Fields: subject, category (Billing, Technical, Tax Query, Document, General), description
  2. Optional file attachment
  3. Ticket created with status `OPEN`, priority auto-set (`MEDIUM` default)
  4. Admin notified of new ticket

### FR-TKT-002 — Ticket Management (Admin)
- **Priority:** P1 | **Source:** US-37
- **Description:** Admins can view, assign, prioritize, and resolve tickets.
- **Acceptance Criteria:**
  1. Filterable queue: by status, category, priority, assigned agent, date range
  2. Assign to support agent
  3. Change priority: Low, Medium, High, Urgent
  4. Change status: Open → In Progress → Waiting on Customer → Resolved → Closed
  5. Internal notes (not visible to customer) via `isInternal` flag on replies
  6. SLA tracking: time since creation, time since last reply

### FR-TKT-003 — Ticket Replies
- **Priority:** P1 | **Source:** US-37
- **Description:** Both customers and admins can reply to tickets.
- **Acceptance Criteria:**
  1. Threaded conversation view
  2. Customer replies re-open `RESOLVED` tickets automatically
  3. Admin replies can include file attachments
  4. Each reply triggers notification to the other party

---

## FR-SEO: SEO Management

### FR-SEO-001 — Per-Page SEO Metadata Storage
- **Priority:** P1 | **Source:** A-59
- **Description:** The system stores SEO metadata for every public-facing page, per locale.
- **Acceptance Criteria:**
  1. Each public page has a record with: `page` (slug), `locale`, `metaTitle`, `metaDescription`, `ogTitle`, `ogDescription`, `ogImage`, `canonicalUrl`, `robots` (index/noindex), `structuredData` (JSON-LD)
  2. Supported pages: home, about, services (each sub-service), pricing, contact, blog posts (future)
  3. Unique constraint on (`page`, `locale`)
  4. Frontend reads SEO data from the API and renders it server-side (SSR) in `<head>`
  5. Falls back to default content JSON values if no database record exists

### FR-SEO-002 — Admin: View All SEO Records
- **Priority:** P1 | **Source:** A-59
- **Description:** Admins can see a list of all pages and their current SEO metadata.
- **Acceptance Criteria:**
  1. Table view: page name, locale, meta title, meta description, last updated, updated by
  2. Filterable by locale (en/bn)
  3. Visual indicator for pages with missing or incomplete SEO data
  4. Character count shown for meta title (max 60) and meta description (max 160)

### FR-SEO-003 — Admin: Create/Edit SEO Record
- **Priority:** P1 | **Source:** A-59
- **Description:** Admins can create or edit SEO metadata for any public page.
- **Acceptance Criteria:**
  1. Form fields: page slug, locale, meta title, meta description, OG title, OG description, OG image (upload or URL), canonical URL, robots directive, structured data (JSON editor)
  2. Live preview: "This is how it will appear in Google search results" — title in blue, URL in green, description in grey
  3. Character count with color warnings (green → yellow → red)
  4. Save triggers cache invalidation so the frontend picks up changes immediately
  5. Change logged in AuditLog

### FR-SEO-004 — Admin: Delete SEO Record
- **Priority:** P2 | **Source:** A-59
- **Description:** Admins can delete a custom SEO record, reverting the page to default content.
- **Acceptance Criteria:**
  1. Confirmation dialog: "This will revert to default SEO values from content files"
  2. On delete: frontend falls back to static JSON content for that page's `<head>`
  3. Deletion logged in AuditLog

### FR-SEO-005 — SEO Sitemap & Robots
- **Priority:** P1 | **Source:** A-59
- **Description:** The system auto-generates a sitemap.xml and robots.txt.
- **Acceptance Criteria:**
  1. `/sitemap.xml` generated dynamically from all public pages + blog posts (future)
  2. Each entry includes: URL, lastmod date, changefreq, priority
  3. `/robots.txt` allows all crawlers, points to sitemap
  4. Pages marked as `noindex` are excluded from sitemap
  5. Regenerated on content/SEO changes (or cached for 1 hour)

---

## FR-CMS: Content Management

### FR-CMS-001 — Section Content CRUD
- **Priority:** P1 | **Source:** US-45
- **Description:** Admins can edit website section content (hero, services, FAQ, team, etc.) without code changes.
- **Acceptance Criteria:**
  1. Each section stored as a JSON object in `CmsContent` table with (`section`, `locale`) key
  2. Admin UI shows form fields matching the JSON structure of each section
  3. Changes are validated (no empty required fields)
  4. Changes published immediately
  5. Change logged with `updatedBy` in AuditLog

### FR-CMS-002 — Testimonial Management
- **Priority:** P1 | **Source:** US-45
- **Description:** Admins can add, edit, reorder, and remove customer testimonials.
- **Acceptance Criteria:**
  1. Fields: customer name, designation/company, photo (upload), quote text, rating (1-5)
  2. Drag-and-drop reorder
  3. Toggle visibility (show/hide without deleting)
  4. Bilingual support (en/bn entries per testimonial)

### FR-CMS-003 — Announcement Banner
- **Priority:** P2 | **Source:** US-44
- **Description:** Admins can create a top banner displayed on the public website.
- **Acceptance Criteria:**
  1. Fields: text, link (optional), background color, start date, end date
  2. Dismissible by visitors (uses cookie to remember dismissal)
  3. Only one active banner at a time
  4. Auto-deactivates after end date

---

## FR-RPT: Reporting & Analytics

### FR-RPT-001 — Admin Dashboard KPIs
- **Priority:** P0 | **Source:** US-42
- **Description:** Admin dashboard shows key performance indicators at a glance.
- **Acceptance Criteria:**
  1. KPI cards: Total Customers, Active Filings, Revenue (This Month), Revenue (YTD), Pending Documents, Open Tickets
  2. Each card shows value + % change vs previous period
  3. Data refreshes on page load (no real-time needed)

### FR-RPT-002 — Revenue Analytics
- **Priority:** P1 | **Source:** US-42
- **Description:** Detailed revenue charts and breakdowns.
- **Acceptance Criteria:**
  1. Bar chart: revenue by month (last 12 months)
  2. Pie chart: revenue by service type
  3. Breakdown by payment method
  4. Date range filter
  5. Export as CSV or PDF

### FR-RPT-003 — Customer Growth Report
- **Priority:** P1 | **Source:** US-42
- **Description:** Chart showing new customer signups over time.
- **Acceptance Criteria:**
  1. Line chart: new signups per week/month
  2. Cumulative total line overlaid
  3. Filterable by date range

### FR-RPT-004 — Filing Performance Report
- **Priority:** P1 | **Source:** US-42
- **Description:** Reports on filing operations efficiency.
- **Acceptance Criteria:**
  1. Total filings by status (pie chart)
  2. Average processing time (days from INITIATED to COMPLETED)
  3. Per-advisor stats: filings count, average time, completion rate
  4. Deadline compliance rate (% filed before deadline)

### FR-RPT-005 — Data Export
- **Priority:** P1 | **Source:** US-48
- **Description:** Admins can export data for external use.
- **Acceptance Criteria:**
  1. Exportable entities: Customers, Payments, Filings, Invoices
  2. Formats: CSV, Excel (.xlsx)
  3. Filterable before export (date range, status, etc.)
  4. Large exports processed as background job with download link sent via notification

---

## FR-SYS: System & Settings

### FR-SYS-001 — Company Settings
- **Priority:** P0 | **Source:** -
- **Description:** Configure core business information.
- **Acceptance Criteria:**
  1. Fields: Company name, logo, address, phone, email, social links
  2. Used in emails, invoices, and footer

### FR-SYS-002 — Tax Season Configuration
- **Priority:** P0 | **Source:** -
- **Description:** Configure the current assessment year and deadlines.
- **Acceptance Criteria:**
  1. Current assessment year (e.g., "2025-2026")
  2. Filing deadline date (default: 30 November)
  3. Late fee rules (for display purposes)
  4. Changes reflected across all dashboards and notifications

### FR-SYS-003 — Staff Management
- **Priority:** P0 | **Source:** US-43
- **Description:** SUPER_ADMIN can manage staff accounts.
- **Acceptance Criteria:**
  1. Create staff: name, email, role assignment
  2. Edit staff: change role, update info
  3. Deactivate: disable login without deleting data
  4. View staff list with role, status, last login

### FR-SYS-004 — Audit Log
- **Priority:** P1 | **Source:** US-46
- **Description:** Immutable log of all admin actions.
- **Acceptance Criteria:**
  1. Every create/update/delete by any admin is logged
  2. Fields: who, what action, which entity, old value, new value, timestamp, IP
  3. Searchable by: user, action type, entity, date range
  4. Read-only: entries cannot be edited or deleted by anyone
  5. Exportable as CSV

### FR-SYS-005 — Registration Gate Configuration
- **Priority:** P0 | **Source:** FR-AUTH-009
- **Description:** Admins can configure whether public registration is open, invite-only, or disabled.
- **Acceptance Criteria:**
  1. Settings page: `Admin → Settings → Registration`
  2. Radio buttons: `Open Registration` / `Invite Only` / `Disabled`
  3. When "Invite Only" selected:
     - "Generate Invite Link" button appears
     - Table of existing invites with: link, created date, expiry, uses/max uses, status (active/expired/depleted), revoke button
     - Generate form: max uses (1 or unlimited), expiry (1 day / 3 days / 7 days / 30 days / custom)
  4. Confirmation dialog on mode switch: "Changing to Invite Only will prevent new visitors from registering. Existing accounts are unaffected."
  5. Change takes effect immediately (no deploy/restart needed)
  6. Action logged in AuditLog with old and new mode

---

## FR-SEC: Security & Infrastructure

### FR-SEC-001 — Rate Limiting
- **Priority:** P0 | **Source:** -
- **Description:** Protect all endpoints from abuse.
- **Acceptance Criteria:**
  1. Auth endpoints: 5 requests/minute per IP
  2. Password reset: 3 requests/hour per email
  3. OTP requests: 3 requests/hour per phone
  4. File uploads: 20 requests/minute per user
  5. General API: 100 requests/minute per user

### FR-SEC-002 — Input Validation & Sanitization
- **Priority:** P0 | **Source:** -
- **Description:** All user inputs are validated and sanitized.
- **Acceptance Criteria:**
  1. All DTOs validated via class-validator
  2. HTML stripped from text inputs to prevent XSS
  3. File uploads: MIME type validated server-side (not just extension)
  4. SQL injection prevented by Prisma parameterized queries

### FR-SEC-003 — Data Encryption
- **Priority:** P0 | **Source:** -
- **Description:** Sensitive data encrypted at rest and in transit.
- **Acceptance Criteria:**
  1. All traffic over HTTPS (TLS 1.2+)
  2. Passwords hashed with bcrypt (12 rounds)
  3. TIN and NID encrypted at rest with AES-256 (application-level)
  4. S3 bucket: server-side encryption enabled (SSE-S3)
  5. Database: encrypted connections (SSL)

### FR-SEC-004 — Automated Backups
- **Priority:** P0 | **Source:** -
- **Description:** Database is backed up automatically on a schedule.
- **Acceptance Criteria:**
  1. Daily backup via `pg_dump`
  2. Backup compressed and uploaded to S3 (separate bucket/folder)
  3. Retain last 30 daily backups
  4. Admin can trigger manual backup from settings
  5. Backup job status visible in admin panel

---

## Architecture Adjustments Required

Based on this FRD, the following changes are needed in `BACKEND_ARCHITECTURE.md`:

### 1. New Database Model: `SeoMeta`

```prisma
model SeoMeta {
  id              String   @id @default(cuid())
  page            String   // "home", "about", "services/individual-tax", etc.
  locale          String   @default("en")
  metaTitle       String?
  metaDescription String?
  ogTitle         String?
  ogDescription   String?
  ogImage         String?  // S3 key or URL
  canonicalUrl    String?
  robots          String   @default("index, follow")
  structuredData  Json?    // JSON-LD
  updatedBy       String?
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  @@unique([page, locale])
}
```

### 2. New Admin API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/seo` | List all SEO records |
| GET | `/admin/seo/:page/:locale` | Get SEO for specific page + locale |
| PUT | `/admin/seo/:page/:locale` | Create or update SEO record |
| DELETE | `/admin/seo/:page/:locale` | Delete SEO record (revert to defaults) |

### 3. New Public API Endpoint

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/public/seo/:page/:locale` | Get SEO data for SSR rendering |

### 4. Module Addition

Add `SeoModule` to the NestJS module structure under `src/modules/seo/`.
