# Anchor Point Advising — Implementation Roadmap

> **Last Updated:** 21 February 2026  
> **Total Estimated Duration:** 16–20 weeks  
> **Source Documents:** `FEATURE_LIST.md`, `USER_JOURNEYS.md`, `FUNCTIONAL_REQUIREMENTS.md`, `BACKEND_ARCHITECTURE.md`, `API_BEST_PRACTICES.md`, `SWAGGER_STANDARDS.md`

---

## Overview

```
PHASE 0 ──► PHASE 1 ──► PHASE 2 ──► PHASE 3 ──► PHASE 4 ──► PHASE 5
Foundation    Core         Customer     Revenue &    Growth       Scale &
(Week 1-2)   Auth & MVP   Experience   Operations   Features     Polish
              (Week 3-6)   (Week 7-10)  (Week 11-13) (Week 14-16) (Ongoing)
```

---

## Phase 0 — Foundation & Infrastructure (Week 1–2)

> **Goal:** Set up the backend project, database, deployment pipeline, and dev tooling so all subsequent phases build on solid ground.

### 0.1 Backend Project Bootstrap

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 0.1.1 | Initialize NestJS project with TypeScript strict mode | — | 2h |
| 0.1.2 | Set up Prisma with PostgreSQL connection | BACKEND_ARCHITECTURE §3 | 2h |
| 0.1.3 | Create `common/` folder: decorators, guards, filters, interceptors, pipes, DTOs | BACKEND_ARCHITECTURE §2 | 4h |
| 0.1.4 | Implement `TransformInterceptor` (standard response envelope) | API_BEST_PRACTICES §2 | 2h |
| 0.1.5 | Implement `AllExceptionsFilter` (standard error responses) | API_BEST_PRACTICES §6 | 2h |
| 0.1.6 | Implement `PaginationDto` with Prisma query pattern | API_BEST_PRACTICES §4 | 1h |
| 0.1.7 | Configure global `ValidationPipe` with `class-validator` | FR-SEC-002 | 1h |
| 0.1.8 | Set up environment config with Joi validation | — | 2h |
| 0.1.9 | Set up Swagger/OpenAPI docs at `/api/docs` | SWAGGER_STANDARDS §1 | 3h |
| 0.1.10 | Configure all Swagger tags (23 tags) | SWAGGER_STANDARDS §2 | 1h |

### 0.2 Infrastructure

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 0.2.1 | Set up AWS S3 bucket for file storage | BACKEND_ARCHITECTURE §1 | 2h |
| 0.2.2 | Implement `UploadModule` (S3 upload, presigned URLs, delete) | FR-DOC-001, FR-DOC-006 | 4h |
| 0.2.3 | Set up Redis for caching and queue | BACKEND_ARCHITECTURE §1 | 2h |
| 0.2.4 | Configure CORS, Helmet, rate limiting (Throttler) | FR-SEC-001, X-05 | 2h |
| 0.2.5 | Set up structured logging (Winston/Pino) | X-07 | 2h |
| 0.2.6 | Set up Sentry for error monitoring | X-06 | 1h |
| 0.2.7 | CI/CD pipeline: GitHub Actions → server deploy | X-08 | 3h |
| 0.2.8 | NGINX reverse proxy configuration | BACKEND_ARCHITECTURE §1 | 1h |

### 0.3 Database Schema — Core Models

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 0.3.1 | Create initial Prisma schema: `User`, `RefreshToken`, `CustomerProfile` | BACKEND_ARCHITECTURE §3.1, §3.2 | 2h |
| 0.3.2 | Create `Document`, `Filing`, `FilingStatusLog` models | BACKEND_ARCHITECTURE §3.3, §3.4 | 2h |
| 0.3.3 | Create `Payment`, `Invoice`, `Refund`, `Coupon` models | BACKEND_ARCHITECTURE §3.5 | 2h |
| 0.3.4 | Create `Consultation`, `AdvisorSchedule`, `ScheduleException` models | BACKEND_ARCHITECTURE §3.6 | 1h |
| 0.3.5 | Create `Conversation`, `Message`, `Notification`, `Ticket`, `TicketReply` models | BACKEND_ARCHITECTURE §3.7 | 2h |
| 0.3.6 | Create `CmsContent`, `Setting`, `AuditLog`, `SeoMeta` models | BACKEND_ARCHITECTURE §3.8, FRD §Architecture | 2h |
| 0.3.7 | Run initial migration, create seed script | — | 2h |

**Phase 0 Subtotal: ~46 hours (~1.5 weeks)**

---

## Phase 1 — Core Auth & MVP (Week 3–6)

> **Goal:** Customers can register, log in, upload documents, make payments, and see their filing status. Admins can review documents, manage filings, and see dashboard KPIs.

### 1.1 Authentication Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.1.1 | Email/password registration | FR-AUTH-001, C-01 | 4h |
| 1.1.2 | Registration gate logic (OPEN / INVITE_ONLY / DISABLED) | FR-AUTH-009, FR-SYS-005 | 6h |
| 1.1.3 | Invite token generation and validation | FR-AUTH-009 | 4h |
| 1.1.4 | Email verification (send link + verify endpoint) | FR-AUTH-004, C-04 | 4h |
| 1.1.5 | Login (email + password) | FR-AUTH-001 | 3h |
| 1.1.6 | Phone/OTP registration & login | FR-AUTH-002, C-02 | 6h |
| 1.1.7 | JWT access + refresh token system | FR-AUTH-006, C-07 | 6h |
| 1.1.8 | Password reset (forgot + reset endpoints) | FR-AUTH-005, C-05 | 4h |
| 1.1.9 | RBAC guards (`@Roles()` decorator + `RolesGuard`) | FR-AUTH-007, A-02 | 4h |
| 1.1.10 | Swagger documentation for all auth endpoints | SWAGGER_STANDARDS §3, §6 | 2h |
| 1.1.11 | Rate limiting on auth endpoints (5/min/IP) | FR-SEC-001 | 1h |

### 1.2 User Profile Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.2.1 | Get/update customer profile | FR-USR-002, C-42, C-43 | 4h |
| 1.2.2 | Change password | FR-USR-003, C-44 | 2h |
| 1.2.3 | Sensitive field masking (TIN, NID) in responses | API_BEST_PRACTICES §10 | 2h |
| 1.2.4 | Language preference save/load | FR-USR-004, C-46 | 1h |

### 1.3 Document Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.3.1 | Upload document (multipart + S3 + DB record) | FR-DOC-001, C-13 | 6h |
| 1.3.2 | Document categorization on upload | FR-DOC-002, C-14 | 2h |
| 1.3.3 | List my documents (filterable, paginated) | FR-DOC-001, C-13 | 3h |
| 1.3.4 | Document status tracking (customer view) | FR-DOC-004, C-17 | 2h |
| 1.3.5 | Document download (presigned URL) | FR-DOC-006, C-20 | 3h |
| 1.3.6 | Delete pending document | FR-DOC-001 | 1h |
| 1.3.7 | Upload checklist by filing type | FR-DOC-003, C-15 | 4h |
| 1.3.8 | File type + size validation (server-side MIME check) | FR-SEC-002, C-21 | 2h |
| 1.3.9 | Admin: Document review queue (list pending) | FR-DOC-010, A-21 | 3h |
| 1.3.10 | Admin: Approve/reject/request re-upload | FR-DOC-011, A-22 | 4h |
| 1.3.11 | Swagger docs for all document endpoints | SWAGGER_STANDARDS §7 | 2h |

### 1.4 Filing Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.4.1 | Initiate new filing (customer) | FR-FIL-001, C-49 | 4h |
| 1.4.2 | Filing status progress endpoint | FR-FIL-002, C-50, C-09 | 3h |
| 1.4.3 | Filing list (customer: my filings) | FR-FIL-007, C-50 | 2h |
| 1.4.4 | Filing detail + status history | FR-FIL-002 | 2h |
| 1.4.5 | Admin: Filing queue (all filings, filterable) | FR-FIL-003, A-27 | 3h |
| 1.4.6 | Admin: Update filing status | FR-FIL-003, A-28 | 3h |
| 1.4.7 | Admin: Assign advisor | FR-FIL-008, A-30 | 3h |
| 1.4.8 | Admin: Upload filed return / acknowledgement | FR-FIL-005, A-29 | 3h |
| 1.4.9 | Deadline tracker (admin view) | FR-FIL-006, A-31 | 2h |

### 1.5 Payment Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.5.1 | Payment initiation (create PENDING record + gateway redirect) | FR-PAY-001, C-23 | 6h |
| 1.5.2 | SSLCommerz / bKash integration | FR-PAY-001, C-24 | 8h |
| 1.5.3 | IPN callback handler (idempotent) | FR-PAY-002 | 4h |
| 1.5.4 | Payment history (customer) | FR-PAY-004, C-26 | 2h |
| 1.5.5 | Auto invoice generation (PDF + S3) | FR-PAY-003, C-25 | 6h |
| 1.5.6 | Admin: Payment overview | FR-PAY-004, A-34 | 3h |

### 1.6 Admin Dashboard

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.6.1 | Dashboard KPI endpoint (totals, changes) | FR-RPT-001, A-06 | 4h |
| 1.6.2 | Admin: Customer list (search, filter, sort, paginate) | A-13, A-19 | 4h |
| 1.6.3 | Admin: Customer 360° profile view | A-14 | 3h |

### 1.7 System & Settings

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.7.1 | Settings CRUD (key-value store) | FR-SYS-001, FR-SYS-002 | 3h |
| 1.7.2 | Registration mode setting (OPEN/INVITE_ONLY/DISABLED) | FR-SYS-005 | 2h |
| 1.7.3 | Tax season configuration | FR-SYS-002, A-67 | 2h |
| 1.7.4 | AuditLog interceptor (auto-log admin actions) | FR-SYS-004, A-04 | 4h |
| 1.7.5 | Staff management CRUD | FR-SYS-003, A-03 | 4h |

### 1.8 Frontend — Customer MVP

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.8.1 | Auth pages: Login, Register, Forgot Password, Reset Password | C-01 to C-05 | 8h |
| 1.8.2 | Registration gate UX (disable/hide register based on mode) | FR-AUTH-009 | 3h |
| 1.8.3 | Customer dashboard (overview, filing status, quick actions) | C-08, C-09, C-11 | 8h |
| 1.8.4 | Document upload page (drag-drop, categories, checklist) | C-13 to C-17 | 10h |
| 1.8.5 | Filing workspace (year selection, progress bar) | C-49, C-50 | 6h |
| 1.8.6 | Payment flow (service selection → gateway → confirmation) | C-23, C-24 | 8h |
| 1.8.7 | Payment history + invoice download | C-26 | 4h |
| 1.8.8 | Profile management page | C-42, C-43, C-44 | 4h |
| 1.8.9 | Public website: Add Login/Register buttons to navbar | W-01 | 2h |

### 1.9 Frontend — Admin MVP

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 1.9.1 | Admin layout (sidebar nav, header, content area) | A-01 | 6h |
| 1.9.2 | Admin login page | A-01 | 3h |
| 1.9.3 | Admin dashboard (KPI cards, recent activity) | A-06 | 6h |
| 1.9.4 | Customer list + 360° detail page | A-13, A-14, A-19 | 8h |
| 1.9.5 | Document review queue + approve/reject UI | A-21, A-22 | 6h |
| 1.9.6 | Filing queue + status management | A-27, A-28 | 6h |
| 1.9.7 | Payment overview table | A-34 | 4h |
| 1.9.8 | Staff management page | A-03 | 4h |
| 1.9.9 | Settings page (company info, tax season, registration gate) | A-66, A-67, FR-SYS-005 | 4h |

**Phase 1 Subtotal: ~270 hours (~4 weeks)**

---

## Phase 2 — Customer Experience (Week 7–10)

> **Goal:** Richer customer experience — consultations, messaging, notifications, support tickets, and document version history.

### 2.1 Notification Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.1.1 | In-app notification CRUD | FR-NTF-001, C-12 | 4h |
| 2.1.2 | Notification triggers (auto-create on events) | FR-NTF-002 | 6h |
| 2.1.3 | WebSocket gateway for real-time notifications | FR-NTF-001, BACKEND_ARCHITECTURE §4.4 | 6h |
| 2.1.4 | Email notification service (Brevo/Resend integration) | FR-NTF-003, C-39, A-69 | 6h |
| 2.1.5 | Email templates (branded HTML, bilingual) | FR-NTF-003 | 6h |
| 2.1.6 | SMS notification service (BD SMS gateway) | FR-NTF-004, C-40 | 4h |
| 2.1.7 | Notification preferences (customer toggle) | FR-USR-005, C-47 | 3h |

### 2.2 Consultation Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.2.1 | Advisor schedule management (admin CRUD) | A-42 | 4h |
| 2.2.2 | Available slots endpoint (date → time slots) | FR-CON-001, C-32 | 4h |
| 2.2.3 | Book consultation (with payment) | FR-CON-002, C-31 | 6h |
| 2.2.4 | Reschedule consultation | FR-CON-003, C-33 | 3h |
| 2.2.5 | Cancel consultation (with refund logic) | FR-CON-004, C-33 | 3h |
| 2.2.6 | Consultation reminders (cron job) | FR-CON-005, C-35 | 3h |
| 2.2.7 | Post-consultation notes (advisor) | FR-CON-006, A-44 | 2h |
| 2.2.8 | Google Meet link auto-generation | FR-CON-002, C-36 | 3h |
| 2.2.9 | Admin: All bookings view + management | A-41, A-43 | 4h |

### 2.3 Messaging Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.3.1 | Conversation + message CRUD (REST) | FR-MSG-001, C-37 | 4h |
| 2.3.2 | WebSocket gateway for real-time chat | FR-MSG-001 | 6h |
| 2.3.3 | Read receipts + typing indicator | FR-MSG-001 | 3h |
| 2.3.4 | File sharing in chat (S3 attachments) | FR-MSG-002, C-38 | 3h |
| 2.3.5 | Admin: Message center (all conversations) | A-46 | 3h |

### 2.4 Support Tickets

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.4.1 | Create ticket (customer) | FR-TKT-001, C-41 | 3h |
| 2.4.2 | Ticket replies (threaded) | FR-TKT-003 | 3h |
| 2.4.3 | Admin: Ticket queue + assign + status management | FR-TKT-002, A-50 | 4h |
| 2.4.4 | Internal notes (admin-only replies) | FR-TKT-002 | 2h |

### 2.5 Document Enhancements

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.5.1 | Document re-upload / version history | FR-DOC-007, C-18 | 4h |
| 2.5.2 | Bulk upload (multi-file) | FR-DOC-008, C-19 | 3h |
| 2.5.3 | Document preview (PDF.js + image lightbox) | FR-DOC-005, C-16 | 4h |
| 2.5.4 | Admin: Request additional documents | FR-DOC-012, A-23 | 3h |
| 2.5.5 | Reuse previous year documents | FR-DOC-009 | 3h |

### 2.6 Filing Enhancements

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.6.1 | Return preview (customer approval flow) | FR-FIL-004, C-51 | 4h |
| 2.6.2 | Download filed return PDF | FR-FIL-005, C-52 | 2h |
| 2.6.3 | Deadline reminder cron job | FR-FIL-006 | 3h |
| 2.6.4 | Bulk filing status update (admin) | FR-FIL-003, A-33 | 2h |

### 2.7 Payment Enhancements

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.7.1 | Refund request (customer) | FR-PAY-006, C-28 | 3h |
| 2.7.2 | Refund processing (admin) | FR-PAY-007, A-37 | 4h |
| 2.7.3 | Nagad / Rocket integration | FR-PAY-001 | 6h |

### 2.8 Onboarding

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.8.1 | Onboarding wizard (multi-step form) | FR-USR-001, C-06 | 6h |

### 2.9 Frontend — Phase 2

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 2.9.1 | Notification center (bell icon, dropdown, full list) | C-12 | 6h |
| 2.9.2 | Notification settings page | C-47 | 3h |
| 2.9.3 | Consultation booking page (calendar + slots) | C-31, C-32 | 8h |
| 2.9.4 | Consultation history page | C-34 | 3h |
| 2.9.5 | Chat/messaging interface | C-37, C-38 | 10h |
| 2.9.6 | Support ticket page (create, view, reply) | C-41 | 6h |
| 2.9.7 | Document upload improvements (bulk, preview, version tabs) | C-16, C-19 | 6h |
| 2.9.8 | Onboarding wizard UI | C-06 | 6h |
| 2.9.9 | Admin: Consultation management page | A-41, A-42 | 6h |
| 2.9.10 | Admin: Message center UI | A-46 | 6h |
| 2.9.11 | Admin: Ticket management UI | A-50 | 6h |

**Phase 2 Subtotal: ~230 hours (~4 weeks)**

---

## Phase 3 — Revenue & Operations (Week 11–13)

> **Goal:** CMS for the public website, SEO management, analytics, and operational tooling for the admin team.

### 3.1 CMS Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.1.1 | CMS content CRUD (hero, services, FAQ, team, pricing, about) | FR-CMS-001, A-52 to A-57 | 6h |
| 3.1.2 | Testimonial management (CRUD + reorder + visibility toggle) | FR-CMS-002, A-56 | 4h |
| 3.1.3 | Frontend: Fetch content from API with fallback to JSON | FR-CMS-001 | 6h |
| 3.1.4 | Announcement banner (admin create + public display + dismiss) | FR-CMS-003, A-60 | 4h |

### 3.2 SEO Module

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.2.1 | SeoMeta CRUD API (per page, per locale) | FR-SEO-001, FR-SEO-003 | 4h |
| 3.2.2 | Public SEO endpoint for SSR `<head>` rendering | FR-SEO-001 | 2h |
| 3.2.3 | Admin: SEO list page (all pages, character counts, status) | FR-SEO-002 | 4h |
| 3.2.4 | Admin: SEO edit form (Google preview, JSON-LD editor) | FR-SEO-003 | 6h |
| 3.2.5 | Dynamic sitemap.xml generation | FR-SEO-005 | 3h |
| 3.2.6 | Robots.txt with sitemap reference | FR-SEO-005 | 1h |

### 3.3 Analytics & Reporting

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.3.1 | Revenue analytics endpoint (by month, service, method) | FR-RPT-002, A-07 | 4h |
| 3.3.2 | Customer growth report endpoint | FR-RPT-003, A-08 | 3h |
| 3.3.3 | Filing performance report endpoint | FR-RPT-004, A-32 | 3h |
| 3.3.4 | Consultation analytics endpoint | A-11 | 3h |
| 3.3.5 | Data export (CSV/Excel) for customers, payments, filings | FR-RPT-005, A-64 | 6h |
| 3.3.6 | Filing season summary report | A-62 | 3h |

### 3.4 Communication Tools

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.4.1 | Admin: Broadcast notification (filtered segments) | FR-MSG-003, A-47 | 4h |
| 3.4.2 | Email template management (CRUD) | A-48 | 4h |

### 3.5 Coupon System

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.5.1 | Coupon CRUD (admin) | FR-PAY-005, A-39 | 4h |
| 3.5.2 | Apply coupon at checkout (customer) | FR-PAY-005, C-29 | 3h |

### 3.6 Frontend — Phase 3

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 3.6.1 | Admin: CMS editor pages (hero, services, FAQ, team, pricing, testimonials) | A-52 to A-57 | 12h |
| 3.6.2 | Admin: SEO management page | FR-SEO-002, FR-SEO-003 | 8h |
| 3.6.3 | Admin: Revenue analytics page (charts) | A-07 | 6h |
| 3.6.4 | Admin: Customer growth + filing performance charts | A-08, A-32 | 4h |
| 3.6.5 | Admin: Data export UI | A-64 | 3h |
| 3.6.6 | Admin: Broadcast notification UI | A-47 | 3h |
| 3.6.7 | Admin: Coupon management UI | A-39 | 4h |
| 3.6.8 | Admin: Email template editor | A-48 | 4h |
| 3.6.9 | Admin: Audit log viewer (search, filter) | A-04 | 4h |
| 3.6.10 | Public website: dynamic content from CMS API | FR-CMS-001 | 6h |

**Phase 3 Subtotal: ~145 hours (~3 weeks)**

---

## Phase 4 — Growth Features (Week 14–16)

> **Goal:** Features that drive customer acquisition and improve engagement — blog, tax calculator, Google OAuth, advanced admin tools.

### 4.1 Advanced Auth

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 4.1.1 | Google OAuth login | FR-AUTH-003, C-03 | 6h |
| 4.1.2 | Admin 2FA (TOTP) | FR-AUTH-008 | 6h |

### 4.2 Public Website

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 4.2.1 | Tax calculator widget (input income → estimate tax) | W-04 | 8h |
| 4.2.2 | Blog/resource center (admin: create posts, public: read) | A-58, W-03 | 12h |
| 4.2.3 | Blog SEO (open graph, structured data, sitemap entries) | FR-SEO-005 | 3h |
| 4.2.4 | Enhanced language switcher (URL-based `/en/`, `/bn/`) | W-07 | 6h |
| 4.2.5 | Dynamic testimonials from database | W-02 | 3h |

### 4.3 Advanced Admin

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 4.3.1 | Customer status management (Active/Inactive/Suspended/VIP) | A-15 | 2h |
| 4.3.2 | Customer internal notes | A-18 | 2h |
| 4.3.3 | Bulk actions (email/SMS/status change) | A-17 | 4h |
| 4.3.4 | Filing season dashboard (special season view) | A-09 | 4h |
| 4.3.5 | Custom report builder (date ranges, filters, groupings) | A-61 | 8h |
| 4.3.6 | Admin: Invoice management (view, resend, manual create) | A-38 | 4h |
| 4.3.7 | Document annotations (admin internal notes on docs) | A-25 | 3h |
| 4.3.8 | Consultation follow-up actions | A-45 | 3h |

### 4.4 Customer Enhancements

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 4.4.1 | Filing year-over-year comparison | C-53 | 4h |
| 4.4.2 | Tax savings report | C-54 | 4h |
| 4.4.3 | Deadline countdown timer on dashboard | C-10 | 2h |

### 4.5 Background Jobs

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 4.5.1 | Automated database backup (daily cron → S3) | FR-SEC-004, A-71 | 4h |
| 4.5.2 | Scheduled report generation (daily/weekly/monthly → email) | A-65 | 4h |
| 4.5.3 | Document expiry alerts | C-22 | 3h |

**Phase 4 Subtotal: ~95 hours (~2.5 weeks)**

---

## Phase 5 — Scale & Polish (Ongoing)

> **Goal:** Future enhancements, performance optimization, and nice-to-have features. No fixed deadline.

| # | Task | FR/Feature Ref | Est. |
|---|------|----------------|------|
| 5.1 | Subscription/retainer plans | C-30 | 12h |
| 5.2 | Referral programme with unique links & rewards | W-06 | 8h |
| 5.3 | PWA (installable, offline dashboard) | W-10 | 8h |
| 5.4 | Dark mode (all panels) | X-02 | 6h |
| 5.5 | Live chat widget (Tawk.to or custom) | W-05 | 4h |
| 5.6 | Cookie consent (category-based) | W-08 | 3h |
| 5.7 | Accessibility audit (WCAG 2.1 AA) | W-09 | 8h |
| 5.8 | IP whitelisting for admin | A-05 | 3h |
| 5.9 | Impersonate customer (admin "view as") | A-20 | 4h |
| 5.10 | Canned responses for support | A-51 | 3h |
| 5.11 | Maintenance mode toggle | A-72 | 2h |
| 5.12 | Bangla date/number formatting | X-12 | 4h |
| 5.13 | Customer acquisition report (UTM tracking) | A-63 | 6h |
| 5.14 | Website traffic analytics (GA or self-hosted) | A-12 | 4h |
| 5.15 | Customer 2FA (SMS / authenticator) | C-45 | 4h |
| 5.16 | Account deletion (GDPR-style with data export) | C-48 | 4h |
| 5.17 | SMS delivery reports (admin view) | A-49 | 3h |
| 5.18 | Document pipeline visual (admin) | A-10 | 4h |

---

## Summary Dashboard

```
┌──────────────────────────────────────────────────────────────┐
│                    IMPLEMENTATION ROADMAP                     │
├──────────┬───────────┬──────────┬───────────────────────────┤
│  Phase   │  Duration │  Hours   │  Key Deliverables         │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  0       │  1.5 wk   │  ~46h    │  Project setup, DB,       │
│          │           │          │  Swagger, CI/CD           │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  1       │  4 wk     │  ~270h   │  Auth (+ reg gate),       │
│          │           │          │  docs, filings,           │
│          │           │          │  payments, admin MVP      │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  2       │  4 wk     │  ~230h   │  Consultations, chat,     │
│          │           │          │  notifications, tickets,  │
│          │           │          │  doc v2+, onboarding      │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  3       │  3 wk     │  ~145h   │  CMS, SEO admin,          │
│          │           │          │  analytics, reports,      │
│          │           │          │  coupons, broadcasts      │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  4       │  2.5 wk   │  ~95h    │  Blog, tax calc,          │
│          │           │          │  Google OAuth, 2FA,       │
│          │           │          │  advanced admin tools     │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  5       │  Ongoing  │  ~90h    │  Subscriptions, referral, │
│          │           │          │  PWA, dark mode, a11y     │
├──────────┼───────────┼──────────┼───────────────────────────┤
│  TOTAL   │  16-20 wk │  ~876h   │  148 features delivered   │
└──────────┴───────────┴──────────┴───────────────────────────┘
```

---

## Dependency Graph

```
Phase 0 (Foundation)
    │
    ├── 0.3 DB Schema ──────────────────────────────────┐
    ├── 0.1 NestJS Setup ──┐                            │
    └── 0.2 Infrastructure ┘                            │
                           │                            │
                     Phase 1 (MVP)                      │
                           │                            │
    ┌──────────────────────┼──────────────────────┐     │
    │                      │                      │     │
    ▼                      ▼                      ▼     │
  1.1 Auth ──► 1.2 Profile    1.5 Payments        │     │
    │                │              │              │     │
    ▼                ▼              ▼              │     │
  1.3 Documents    1.4 Filings   1.6 Dashboard    │     │
    │                │              │              │     │
    └────────────────┴──────────────┘              │     │
                           │                      │     │
                     Phase 2 (Experience)         │     │
                           │                      │     │
    ┌──────────┬──────────┼──────────┬──────────┘     │
    ▼          ▼          ▼          ▼                  │
  2.1 Notif  2.2 Consult 2.3 Chat  2.4 Tickets        │
    │          │          │          │                  │
    └──────────┴──────────┴──────────┘                  │
                           │                            │
                     Phase 3 (Operations) ◄─────────────┘
                           │
    ┌──────────────────────┼──────────────────┐
    ▼                      ▼                  ▼
  3.1 CMS              3.2 SEO           3.3 Analytics
    │                      │                  │
    └──────────────────────┴──────────────────┘
                           │
                     Phase 4 (Growth)
                           │
                     Phase 5 (Scale)
```

---

## Risk Register

| Risk | Impact | Mitigation |
|------|--------|------------|
| Payment gateway integration delays | Phase 1 blocked | Start bKash integration early; use SSLCommerz sandbox day 1 |
| SMS OTP provider reliability | Login/registration affected | Have fallback provider configured; email verification as alternative |
| Scope creep during Phase 2-3 | Timeline slips | Strict PR reviews against FRD acceptance criteria; no features without FR ID |
| Single developer bottleneck | All phases delayed | Documentation-first approach enables onboarding new devs fast |
| Filing season deadline (Nov 30) | Must be live before season | Phase 1 MVP target must align with season timing |

---

## Definition of Done (Per Task)

- [ ] Backend endpoint(s) implemented with all FR acceptance criteria passing
- [ ] Swagger docs complete (all decorators per SWAGGER_STANDARDS checklist)
- [ ] Response format follows API_BEST_PRACTICES envelope
- [ ] Input validation via DTOs with class-validator
- [ ] AuditLog integration for admin-facing actions
- [ ] Error responses follow standard error codes
- [ ] Unit tests for service methods (≥80% coverage)
- [ ] Frontend page/component connected and visually tested
- [ ] Bilingual support verified (en + bn)
- [ ] Mobile responsive verified (customer pages)
