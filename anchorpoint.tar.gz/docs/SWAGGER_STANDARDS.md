# Anchor Point Advising — Swagger / OpenAPI Standards

> **Last Updated:** 21 February 2026  
> **Stack:** NestJS + `@nestjs/swagger`  
> **Swagger UI URL:** `/api/docs`  
> **OpenAPI JSON:** `/api/docs-json`

---

## Table of Contents

1. [Setup & Configuration](#1-setup--configuration)
2. [Tag Organization](#2-tag-organization)
3. [Controller Decorators](#3-controller-decorators)
4. [DTO Decorators](#4-dto-decorators)
5. [Response Documentation](#5-response-documentation)
6. [Authentication in Swagger](#6-authentication-in-swagger)
7. [File Upload Documentation](#7-file-upload-documentation)
8. [Enum Documentation](#8-enum-documentation)
9. [Pagination & Filtering](#9-pagination--filtering)
10. [Grouping by Role](#10-grouping-by-role)
11. [Examples & Conventions](#11-examples--conventions)
12. [Full Controller Example](#12-full-controller-example)

---

## 1. Setup & Configuration

### Installation

```bash
npm install @nestjs/swagger swagger-ui-express
```

### Bootstrap Configuration

```typescript
// src/main.ts
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Global prefix
  app.setGlobalPrefix('api/v1');

  // Swagger setup
  const config = new DocumentBuilder()
    .setTitle('Anchor Point Advising API')
    .setDescription(
      'RESTful API for Anchor Point Advising — Tax Consulting & Financial Advisory Platform.\n\n' +
      '## Authentication\n' +
      'Most endpoints require a Bearer JWT token. Obtain one via `/auth/login`.\n\n' +
      '## Roles\n' +
      '- **CUSTOMER** — Paying clients\n' +
      '- **TAX_ADVISOR** — Staff who prepare returns\n' +
      '- **OPERATIONS** — Staff managing CMS & reports\n' +
      '- **SUPPORT** — Staff handling tickets\n' +
      '- **SUPER_ADMIN** — Full access\n\n' +
      '## Response Format\n' +
      'All responses follow: `{ success, message, data, meta?, error? }`'
    )
    .setVersion('1.0')
    .setContact(
      'Anchor Point Advising',
      'https://anchorpointadvising.com',
      'support@anchorpointadvising.com'
    )
    .setLicense('Proprietary', '')
    .addServer('http://localhost:4000', 'Local Development')
    .addServer('https://api.anchorpointadvising.com', 'Production')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Enter your JWT access token',
      },
      'access-token', // Security scheme name
    )
    .addCookieAuth(
      'refreshToken',
      {
        type: 'apiKey',
        in: 'cookie',
        description: 'Refresh token (httpOnly cookie, auto-managed)',
      },
      'refresh-token',
    )
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document, {
    customSiteTitle: 'Anchor Point API Docs',
    customCss: `.swagger-ui .topbar { display: none }`, // Hide Swagger top bar
    swaggerOptions: {
      persistAuthorization: true,       // Keep token across page refreshes
      docExpansion: 'none',             // Collapse all by default
      filter: true,                      // Enable search
      tagsSorter: 'alpha',              // Sort tags alphabetically
      operationsSorter: 'method',       // Sort by HTTP method within tags
    },
  });

  await app.listen(4000);
}
bootstrap();
```

### Environment-Based Toggle

```typescript
// Only enable Swagger in development and staging
if (process.env.NODE_ENV !== 'production') {
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document, swaggerOptions);
}
```

> ⚠️ **Production:** Disable Swagger UI or protect it behind admin auth. Never expose API docs publicly in production.

---

## 2. Tag Organization

Tags group endpoints in the Swagger UI sidebar. We organize by **module + audience**.

```typescript
// Add tags in DocumentBuilder (main.ts) — they appear in this order
.addTag('Auth', 'Registration, login, password reset, token refresh')
.addTag('Customer: Profile', 'Customer profile and settings management')
.addTag('Customer: Documents', 'Upload, view, and manage tax documents')
.addTag('Customer: Filings', 'Tax filing lifecycle and status tracking')
.addTag('Customer: Payments', 'Payment initiation, history, and invoices')
.addTag('Customer: Consultations', 'Book and manage consultation appointments')
.addTag('Customer: Messages', 'In-app messaging with assigned advisor')
.addTag('Customer: Notifications', 'Notification center and preferences')
.addTag('Customer: Tickets', 'Support ticket submission and tracking')
.addTag('Admin: Dashboard', 'KPIs, analytics, and overview stats')
.addTag('Admin: Customers', 'Customer management and 360° view')
.addTag('Admin: Documents', 'Document review queue and actions')
.addTag('Admin: Filings', 'Filing queue, status management, assignments')
.addTag('Admin: Payments', 'Transaction overview, refunds, exports')
.addTag('Admin: Consultations', 'Booking and schedule management')
.addTag('Admin: Messages', 'Message center and broadcasts')
.addTag('Admin: Tickets', 'Support ticket assignment and resolution')
.addTag('Admin: CMS', 'Website content management')
.addTag('Admin: SEO', 'Per-page SEO metadata CRUD')
.addTag('Admin: Coupons', 'Promo code management')
.addTag('Admin: Reports', 'Revenue, growth, and filing reports')
.addTag('Admin: Settings', 'System configuration and staff management')
.addTag('Admin: Audit', 'Audit log viewer')
```

### Controller Tag Usage

```typescript
@ApiTags('Customer: Documents')
@Controller('customer/documents')
export class CustomerDocumentsController { ... }

@ApiTags('Admin: Documents')
@Controller('admin/documents')
export class AdminDocumentsController { ... }
```

---

## 3. Controller Decorators

Every endpoint must have these Swagger decorators:

### Required Decorators

| Decorator | Purpose | Required? |
|-----------|---------|-----------|
| `@ApiTags()` | Groups endpoint under a tag | ✅ On controller |
| `@ApiOperation()` | Endpoint summary & description | ✅ On every method |
| `@ApiResponse()` | Documents each possible response | ✅ On every method |
| `@ApiBearerAuth()` | Marks endpoint as requiring JWT | ✅ On protected methods |
| `@ApiParam()` | Documents URL parameters | ✅ On methods with `:id` |
| `@ApiQuery()` | Documents query parameters | ✅ On methods with filters |
| `@ApiBody()` | Documents request body | ✅ On POST/PUT/PATCH |
| `@ApiConsumes()` | Documents content type | ✅ On file uploads |

### Endpoint Template

```typescript
@Post()
@ApiBearerAuth('access-token')
@ApiOperation({
  summary: 'Upload a document',
  description: 'Upload a tax document (PDF, JPG, PNG, DOCX) to a specific filing. Max 10 MB per file.',
})
@ApiResponse({ status: 201, description: 'Document uploaded successfully', type: DocumentResponseDto })
@ApiResponse({ status: 400, description: 'Invalid file type or missing required fields' })
@ApiResponse({ status: 401, description: 'Unauthorized — invalid or expired token' })
@ApiResponse({ status: 413, description: 'File too large — max 10 MB' })
async uploadDocument(...) { }
```

### URL Parameters

```typescript
@Get(':id')
@ApiParam({
  name: 'id',
  description: 'Document ID (cuid format)',
  example: 'clx1doc001',
})
async getDocument(@Param('id') id: string) { }
```

---

## 4. DTO Decorators

Every field in a DTO must be documented with `@ApiProperty()` or `@ApiPropertyOptional()`.

### Request DTO

```typescript
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString, MinLength } from 'class-validator';
import { DocumentCategory } from '@prisma/client';

export class CreateDocumentDto {
  @ApiProperty({
    description: 'ID of the filing this document belongs to',
    example: 'clx1filing001',
  })
  @IsString()
  @IsNotEmpty()
  filingId: string;

  @ApiProperty({
    description: 'Document category',
    enum: DocumentCategory,
    example: 'SALARY_CERTIFICATE',
  })
  @IsEnum(DocumentCategory)
  category: DocumentCategory;

  @ApiPropertyOptional({
    description: 'Optional note about the document',
    example: 'This is my 2025 salary certificate from XYZ Ltd.',
  })
  @IsString()
  @IsOptional()
  notes?: string;
}
```

### Response DTO

```typescript
import { ApiProperty } from '@nestjs/swagger';

export class DocumentResponseDto {
  @ApiProperty({ example: 'clx1doc001' })
  id: string;

  @ApiProperty({ example: 'clx1filing001' })
  filingId: string;

  @ApiProperty({ enum: ['NID', 'TIN_CERTIFICATE', 'SALARY_CERTIFICATE', '...'], example: 'SALARY_CERTIFICATE' })
  category: string;

  @ApiProperty({ example: 'salary-certificate-2025.pdf' })
  fileName: string;

  @ApiProperty({ description: 'File size in bytes', example: 251904 })
  fileSize: number;

  @ApiProperty({ example: 'application/pdf' })
  mimeType: string;

  @ApiProperty({ enum: ['PENDING', 'ACCEPTED', 'REJECTED', 'NEEDS_REUPLOAD'], example: 'PENDING' })
  status: string;

  @ApiProperty({ description: 'Reason if rejected', example: null, nullable: true })
  rejectionNote: string | null;

  @ApiProperty({ example: 1 })
  version: number;

  @ApiProperty({ example: '2026-02-21T10:30:00.000Z' })
  createdAt: string;
}
```

### Wrapped Response DTO (With Envelope)

```typescript
// Standard envelope wrapper — reuse across all endpoints
export class ApiResponseDto<T> {
  @ApiProperty({ example: true })
  success: boolean;

  @ApiProperty({ example: 'Document uploaded successfully' })
  message: string;

  @ApiProperty()
  data: T;
}

// Usage in controller:
@ApiResponse({
  status: 201,
  description: 'Document uploaded',
  schema: {
    allOf: [
      {
        properties: {
          success: { type: 'boolean', example: true },
          message: { type: 'string', example: 'Document uploaded successfully' },
          data: { $ref: getSchemaPath(DocumentResponseDto) },
        },
      },
    ],
  },
})
```

### Simpler Approach: ApiExtraModels + getSchemaPath

```typescript
// Register response DTOs globally in main.ts
const document = SwaggerModule.createDocument(app, config, {
  extraModels: [
    DocumentResponseDto,
    FilingResponseDto,
    PaymentResponseDto,
    // ... all response DTOs
  ],
});
```

---

## 5. Response Documentation

### Document ALL Possible Responses

```typescript
@Get(':id')
@ApiBearerAuth('access-token')
@ApiOperation({ summary: 'Get document details' })
@ApiParam({ name: 'id', description: 'Document ID', example: 'clx1doc001' })
@ApiResponse({
  status: 200,
  description: 'Document found',
  type: DocumentResponseDto,
})
@ApiResponse({
  status: 401,
  description: 'Unauthorized — token missing or expired',
})
@ApiResponse({
  status: 403,
  description: 'Forbidden — document belongs to another customer',
})
@ApiResponse({
  status: 404,
  description: 'Document not found',
})
async getDocument(@Param('id') id: string) { }
```

### Error Response Schema

```typescript
// src/common/dto/error-response.dto.ts
export class ErrorDetailDto {
  @ApiProperty({ example: 'email' })
  field: string;

  @ApiProperty({ example: 'Must be a valid email address' })
  message: string;
}

export class ErrorResponseDto {
  @ApiProperty({ example: false })
  success: boolean;

  @ApiProperty({ example: 'Validation failed' })
  message: string;

  @ApiProperty({
    example: {
      code: 'VALIDATION_ERROR',
      details: [{ field: 'email', message: 'Must be a valid email address' }],
    },
  })
  error: {
    code: string;
    details?: ErrorDetailDto[];
  };

  @ApiProperty({ example: null, nullable: true })
  data: null;
}
```

---

## 6. Authentication in Swagger

### Marking Protected Endpoints

```typescript
// Entire controller protected
@ApiBearerAuth('access-token')
@ApiTags('Customer: Filings')
@Controller('customer/filings')
export class CustomerFilingsController { }

// Single public endpoint in a protected controller
@Get('public-data')
@Public()  // Custom decorator to skip auth guard
@ApiOperation({ summary: 'Get public filing stats' })
// Note: No @ApiBearerAuth() here
async getPublicStats() { }
```

### Marking Role Requirements

```typescript
@Post('approve')
@ApiBearerAuth('access-token')
@ApiOperation({
  summary: 'Approve a document',
  description: '**Requires role:** `SUPER_ADMIN`, `TAX_ADVISOR`',
})
@Roles(Role.SUPER_ADMIN, Role.TAX_ADVISOR)
async approveDocument() { }
```

> **Convention:** Always note required roles in the `description` field so they're visible in Swagger UI without inspecting decorators.

### Using Swagger UI to Test

1. Click the **"Authorize"** button (🔒) in Swagger UI
2. Enter your JWT token (obtained from `/auth/login`)
3. All subsequent requests include the `Authorization: Bearer <token>` header
4. `persistAuthorization: true` keeps it across page refreshes

---

## 7. File Upload Documentation

```typescript
@Post()
@ApiBearerAuth('access-token')
@ApiOperation({ summary: 'Upload a document' })
@ApiConsumes('multipart/form-data')
@ApiBody({
  description: 'Document file with metadata',
  schema: {
    type: 'object',
    required: ['file', 'filingId', 'category'],
    properties: {
      file: {
        type: 'string',
        format: 'binary',
        description: 'The document file (PDF, JPG, PNG, DOCX). Max 10 MB.',
      },
      filingId: {
        type: 'string',
        description: 'Filing ID to associate the document with',
        example: 'clx1filing001',
      },
      category: {
        type: 'string',
        enum: ['NID', 'TIN_CERTIFICATE', 'SALARY_CERTIFICATE', 'BANK_STATEMENT', '...'],
        description: 'Document category',
        example: 'SALARY_CERTIFICATE',
      },
      notes: {
        type: 'string',
        description: 'Optional notes about the document',
        example: 'January to June 2025 statement',
      },
    },
  },
})
@ApiResponse({ status: 201, description: 'Document uploaded successfully' })
@ApiResponse({ status: 400, description: 'Invalid file type or missing fields' })
@ApiResponse({ status: 413, description: 'File exceeds 10 MB limit' })
@UseInterceptors(FileInterceptor('file'))
async uploadDocument(
  @UploadedFile() file: Express.Multer.File,
  @Body() dto: CreateDocumentDto,
) { }
```

---

## 8. Enum Documentation

### Prisma Enums → Swagger

```typescript
// src/common/swagger/enums.ts
// Export all enums with descriptions for Swagger

export const DOCUMENT_STATUS_DESCRIPTIONS = {
  PENDING: 'Document uploaded, awaiting admin review',
  ACCEPTED: 'Document reviewed and approved',
  REJECTED: 'Document rejected — see rejectionNote for reason',
  NEEDS_REUPLOAD: 'Admin requested a corrected version',
};

export const FILING_STATUS_DESCRIPTIONS = {
  INITIATED: 'Filing created, payment may be pending',
  DOCUMENTS_PENDING: 'Waiting for customer to upload documents',
  DOCUMENTS_RECEIVED: 'All required documents uploaded',
  UNDER_PREPARATION: 'Tax advisor is preparing the return',
  REVIEW_READY: 'Return prepared, awaiting customer approval',
  CUSTOMER_APPROVED: 'Customer approved the return',
  E_FILED: 'Return submitted to NBR portal',
  ACKNOWLEDGED: 'NBR acknowledgement received',
  COMPLETED: 'Filing process fully complete',
  ON_HOLD: 'Filing paused — missing info or customer inactive',
};
```

### In DTOs

```typescript
@ApiProperty({
  enum: DocumentStatus,
  enumName: 'DocumentStatus',
  description: Object.entries(DOCUMENT_STATUS_DESCRIPTIONS)
    .map(([k, v]) => `- \`${k}\`: ${v}`)
    .join('\n'),
  example: 'PENDING',
})
status: DocumentStatus;
```

> This renders as a dropdown in Swagger UI with all valid values, and the description explains what each means.

---

## 9. Pagination & Filtering

### Pagination Query Params

```typescript
// Apply to all list endpoints via the DTO
export class PaginationDto {
  @ApiPropertyOptional({
    description: 'Page number (1-indexed)',
    minimum: 1,
    default: 1,
    example: 1,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({
    description: 'Items per page',
    minimum: 1,
    maximum: 100,
    default: 20,
    example: 20,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit?: number = 20;
}
```

### Filter DTO with Swagger

```typescript
export class FilterDocumentsDto extends PaginationDto {
  @ApiPropertyOptional({
    description: 'Filter by document status',
    enum: DocumentStatus,
    example: 'PENDING',
  })
  @IsOptional()
  @IsEnum(DocumentStatus)
  status?: DocumentStatus;

  @ApiPropertyOptional({
    description: 'Filter by document category',
    enum: DocumentCategory,
    example: 'SALARY_CERTIFICATE',
  })
  @IsOptional()
  @IsEnum(DocumentCategory)
  category?: DocumentCategory;

  @ApiPropertyOptional({
    description: 'Sort field',
    enum: ['createdAt', 'fileName', 'category', 'status'],
    default: 'createdAt',
  })
  @IsOptional()
  @IsString()
  sort?: string = 'createdAt';

  @ApiPropertyOptional({
    description: 'Sort order',
    enum: ['asc', 'desc'],
    default: 'desc',
  })
  @IsOptional()
  @IsIn(['asc', 'desc'])
  order?: 'asc' | 'desc' = 'desc';

  @ApiPropertyOptional({
    description: 'Search by file name or customer name',
    example: 'rahim',
  })
  @IsOptional()
  @IsString()
  search?: string;
}
```

### Pagination Response Schema

```typescript
export class PaginationMetaDto {
  @ApiProperty({ example: 1 })
  page: number;

  @ApiProperty({ example: 20 })
  limit: number;

  @ApiProperty({ example: 156 })
  totalItems: number;

  @ApiProperty({ example: 8 })
  totalPages: number;

  @ApiProperty({ example: true })
  hasNextPage: boolean;

  @ApiProperty({ example: false })
  hasPreviousPage: boolean;
}
```

---

## 10. Grouping by Role

### Convention: Separate Controllers by Audience

```
src/modules/documents/
├── customer-documents.controller.ts    → @ApiTags('Customer: Documents')
├── admin-documents.controller.ts       → @ApiTags('Admin: Documents')
├── documents.service.ts                → Shared business logic
└── dto/
    ├── create-document.dto.ts
    ├── filter-documents.dto.ts
    ├── review-document.dto.ts
    └── document-response.dto.ts
```

This way in Swagger UI:
- **Customer endpoints** are grouped under `Customer: Documents`
- **Admin endpoints** are grouped under `Admin: Documents`
- Developers can quickly find the right endpoint for their role

### Mark Role in Description

```typescript
@ApiTags('Admin: Documents')
@ApiBearerAuth('access-token')
@Controller('admin/documents')
export class AdminDocumentsController {

  @Put(':id/approve')
  @ApiOperation({
    summary: 'Approve a document',
    description: '🔒 **Roles:** `SUPER_ADMIN`, `TAX_ADVISOR`\n\n' +
      'Marks a document as accepted after review. Triggers a notification to the customer.',
  })
  @Roles(Role.SUPER_ADMIN, Role.TAX_ADVISOR)
  async approve() { }
}
```

---

## 11. Examples & Conventions

### Every DTO Field Must Have an Example

```typescript
// ✅ GOOD
@ApiProperty({
  description: 'Customer email address',
  example: 'rahim@example.com',
})
email: string;

// ❌ BAD — no example
@ApiProperty()
email: string;
```

> **Why?** Swagger UI uses examples to auto-fill the "Try it out" form. Without examples, testers have to guess the format.

### Naming Conventions for DTOs

| Type | Pattern | Example |
|------|---------|---------|
| Create request | `Create{Entity}Dto` | `CreateDocumentDto` |
| Update request | `Update{Entity}Dto` | `UpdateProfileDto` |
| Filter/query | `Filter{Entity}Dto` | `FilterDocumentsDto` |
| Action request | `{Action}{Entity}Dto` | `RejectDocumentDto` |
| Response | `{Entity}ResponseDto` | `DocumentResponseDto` |
| List response | `{Entity}ListResponseDto` | `DocumentListResponseDto` |

### Swagger Description Markdown

Swagger supports Markdown in descriptions. Use it for clarity:

```typescript
@ApiOperation({
  summary: 'Initiate payment',
  description: `
Initiates a payment for a service. Redirects the customer to the payment gateway.

### Supported Methods
- **BKASH** — Redirects to bKash tokenized checkout
- **NAGAD** — Redirects to Nagad payment gateway
- **CARD** — Processes via SSLCommerz

### Flow
1. Client calls this endpoint with the service and preferred method
2. Server creates a \`PENDING\` payment record
3. Server returns a \`gatewayUrl\`
4. Client redirects the user to \`gatewayUrl\`
5. User completes payment on the gateway
6. Gateway sends IPN to \`/payments/callback\`
7. Server updates payment status to \`COMPLETED\`
  `,
})
```

---

## 12. Full Controller Example

```typescript
// src/modules/documents/customer-documents.controller.ts
import {
  Controller, Get, Post, Param, Query, Body, Delete,
  UseInterceptors, UploadedFile, UseGuards,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation, ApiResponse,
  ApiParam, ApiConsumes, ApiBody,
} from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import { DocumentsService } from './documents.service';
import { CreateDocumentDto } from './dto/create-document.dto';
import { FilterDocumentsDto } from './dto/filter-documents.dto';
import { DocumentResponseDto } from './dto/document-response.dto';

@ApiTags('Customer: Documents')
@ApiBearerAuth('access-token')
@UseGuards(JwtAuthGuard)
@Controller('customer/documents')
export class CustomerDocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  // ─── LIST DOCUMENTS ──────────────────────────────────
  @Get()
  @ApiOperation({
    summary: 'List my documents',
    description: 'Returns all documents uploaded by the current customer, with pagination and filters.',
  })
  @ApiResponse({
    status: 200,
    description: 'Documents retrieved with pagination meta',
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async listDocuments(
    @CurrentUser('id') userId: string,
    @Query() filters: FilterDocumentsDto,
  ) {
    return this.documentsService.findByUser(userId, filters);
  }

  // ─── GET SINGLE DOCUMENT ─────────────────────────────
  @Get(':id')
  @ApiOperation({
    summary: 'Get document details',
    description: 'Returns full details of a specific document owned by the current customer.',
  })
  @ApiParam({ name: 'id', description: 'Document ID', example: 'clx1doc001' })
  @ApiResponse({ status: 200, description: 'Document found', type: DocumentResponseDto })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 404, description: 'Document not found' })
  async getDocument(
    @CurrentUser('id') userId: string,
    @Param('id') id: string,
  ) {
    return this.documentsService.findOneByUser(id, userId);
  }

  // ─── UPLOAD DOCUMENT ─────────────────────────────────
  @Post()
  @ApiOperation({
    summary: 'Upload a document',
    description:
      'Upload a tax document to a specific filing.\n\n' +
      '**Accepted formats:** PDF, JPG, JPEG, PNG, DOCX\n' +
      '**Max size:** 10 MB',
  })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Document file with metadata',
    schema: {
      type: 'object',
      required: ['file', 'filingId', 'category'],
      properties: {
        file: {
          type: 'string',
          format: 'binary',
          description: 'The document file. Max 10 MB.',
        },
        filingId: {
          type: 'string',
          example: 'clx1filing001',
        },
        category: {
          type: 'string',
          enum: ['NID', 'TIN_CERTIFICATE', 'SALARY_CERTIFICATE', 'BANK_STATEMENT'],
          example: 'SALARY_CERTIFICATE',
        },
        notes: {
          type: 'string',
          example: 'January to June 2025 statement',
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Document uploaded successfully', type: DocumentResponseDto })
  @ApiResponse({ status: 400, description: 'Invalid file type or missing required fields' })
  @ApiResponse({ status: 413, description: 'File exceeds 10 MB limit' })
  @UseInterceptors(FileInterceptor('file'))
  async uploadDocument(
    @CurrentUser('id') userId: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: CreateDocumentDto,
  ) {
    return this.documentsService.upload(userId, file, dto);
  }

  // ─── GET UPLOAD CHECKLIST ─────────────────────────────
  @Get('checklist/:filingId')
  @ApiOperation({
    summary: 'Get document upload checklist',
    description:
      'Returns the required documents for a filing based on service type, ' +
      'with status showing which are uploaded, accepted, or missing.',
  })
  @ApiParam({ name: 'filingId', description: 'Filing ID', example: 'clx1filing001' })
  @ApiResponse({ status: 200, description: 'Checklist retrieved' })
  @ApiResponse({ status: 404, description: 'Filing not found' })
  async getChecklist(
    @CurrentUser('id') userId: string,
    @Param('filingId') filingId: string,
  ) {
    return this.documentsService.getChecklist(userId, filingId);
  }

  // ─── DOWNLOAD DOCUMENT ───────────────────────────────
  @Get(':id/download')
  @ApiOperation({
    summary: 'Download a document',
    description: 'Generates a short-lived presigned S3 URL (15 min) for downloading the document.',
  })
  @ApiParam({ name: 'id', description: 'Document ID', example: 'clx1doc001' })
  @ApiResponse({
    status: 200,
    description: 'Presigned download URL',
    schema: {
      properties: {
        success: { type: 'boolean', example: true },
        message: { type: 'string', example: 'Download URL generated' },
        data: {
          type: 'object',
          properties: {
            url: { type: 'string', example: 'https://s3.amazonaws.com/...' },
            expiresIn: { type: 'number', example: 900 },
          },
        },
      },
    },
  })
  @ApiResponse({ status: 404, description: 'Document not found' })
  async downloadDocument(
    @CurrentUser('id') userId: string,
    @Param('id') id: string,
  ) {
    return this.documentsService.getDownloadUrl(id, userId);
  }

  // ─── DELETE DRAFT DOCUMENT ────────────────────────────
  @Delete(':id')
  @ApiOperation({
    summary: 'Delete a pending document',
    description: 'Deletes a document that has not yet been reviewed. Only `PENDING` documents can be deleted.',
  })
  @ApiParam({ name: 'id', description: 'Document ID', example: 'clx1doc001' })
  @ApiResponse({ status: 200, description: 'Document deleted' })
  @ApiResponse({ status: 400, description: 'Cannot delete — document already reviewed' })
  @ApiResponse({ status: 404, description: 'Document not found' })
  async deleteDocument(
    @CurrentUser('id') userId: string,
    @Param('id') id: string,
  ) {
    return this.documentsService.deletePending(id, userId);
  }
}
```

---

## Checklist: Before Merging Any Controller

- [ ] Every method has `@ApiOperation({ summary, description })`
- [ ] Every method has all relevant `@ApiResponse()` decorators (200, 400, 401, 403, 404, etc.)
- [ ] Protected methods have `@ApiBearerAuth('access-token')`
- [ ] Role requirements noted in the description
- [ ] URL params have `@ApiParam()` with examples
- [ ] Query params are in a DTO with `@ApiPropertyOptional()`
- [ ] Request body DTOs have `@ApiProperty()` with examples on every field
- [ ] File uploads use `@ApiConsumes('multipart/form-data')` + `@ApiBody({ schema })`
- [ ] Enums show all valid values
- [ ] Response DTOs have `@ApiProperty()` with examples
- [ ] Controller has `@ApiTags()` matching our tag convention
- [ ] Swagger UI renders correctly — test by visiting `/api/docs`
