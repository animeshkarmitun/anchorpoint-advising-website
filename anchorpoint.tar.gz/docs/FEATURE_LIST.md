# Anchor Point Advising — Comprehensive Feature List

> **Last Updated:** 21 February 2026
> **Project:** Tax Consulting & Financial Advisory Platform
> **Stack:** Next.js (Frontend) + Backend (TBD) + Database (TBD)

---

## Table of Contents

1. [Current State (What Exists)](#1-current-state)
2. [Customer Panel Features](#2-customer-panel-features)
3. [Admin Panel Features](#3-admin-panel-features)
4. [Public Website Enhancements](#4-public-website-enhancements)
5. [Shared / Cross-Cutting Features](#5-shared--cross-cutting-features)

---

## 1. Current State

The platform is currently a **static landing page** with:
- ✅ Hero Section with CTAs
- ✅ Services overview (6 services)
- ✅ About section
- ✅ Team section
- ✅ Pricing (BDT 1,500 complete tax solution + BDT 300 consultation)
- ✅ Consultation booking CTA
- ✅ FAQ section (13 tax-related questions)
- ✅ Bilingual content (English / Bangla)
- ✅ WhatsApp floating button
- ✅ Service detail pages (Individual Tax, Corporate Tax, NRB Tax, Late Filing Guide, Tax Rebate Guide)
- ✅ Cookie policy page
- ✅ SEO optimization (DynamicSEO component)
- ✅ Contact form via SheetDB

**What's missing:** Authentication, customer accounts, document management, admin panel, payment processing, and all dynamic backend features.

---

## 2. Customer Panel Features

### 2.1 🔐 Authentication & Onboarding

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-01 | **Email/Password Registration** | Customer signs up with email, phone, and password | 🔴 High |
| C-02 | **Phone/OTP Login** | Login via Bangladesh mobile number + OTP (SMS) | 🔴 High |
| C-03 | **Google OAuth Login** | One-click sign-in with Google | 🟡 Medium |
| C-04 | **Email Verification** | Verify email address via magic link or OTP | 🔴 High |
| C-05 | **Password Reset** | Forgot password flow with secure reset link | 🔴 High |
| C-06 | **Onboarding Wizard** | Guided first-time setup: name, TIN, NID, income type, taxpayer category | 🟡 Medium |
| C-07 | **Session Management** | Secure JWT-based sessions with refresh tokens | 🔴 High |

### 2.2 📊 Dashboard

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-08 | **Dashboard Overview** | At-a-glance view: active service status, pending tasks, upcoming deadlines, recent activity | 🔴 High |
| C-09 | **Tax Filing Status Tracker** | Visual progress bar showing current filing stage (Docs Submitted → Under Review → Filed → Confirmed) | 🔴 High |
| C-10 | **Deadline Reminders** | Show upcoming tax deadlines (e.g., Nov 30 filing deadline) with countdown timer | 🟡 Medium |
| C-11 | **Quick Actions** | One-click buttons: Upload Document, Book Consultation, View Receipt, Contact Support | 🟡 Medium |
| C-12 | **Notification Center** | Bell icon with unread count — shows document requests, status updates, messages | 🔴 High |

### 2.3 📁 Document Management (Core Feature)

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-13 | **Document Upload** | Upload files (PDF, JPG, PNG, DOCX) with drag-and-drop support | 🔴 High |
| C-14 | **Document Categories** | Organize uploads by type: NID, TIN Certificate, Salary Certificate, Bank Statements, Rental Agreements, Investment Proofs, Previous Returns, Others | 🔴 High |
| C-15 | **Upload Checklist** | Dynamic checklist showing which documents are required vs. already uploaded, based on the customer's service type | 🔴 High |
| C-16 | **Document Preview** | In-browser preview for PDFs and images without downloading | 🟡 Medium |
| C-17 | **Document Status** | Each document shows: Pending Review, Accepted, Rejected (with reason), Needs Re-upload | 🔴 High |
| C-18 | **Version History** | Track re-uploads; keep previous versions accessible | 🟢 Low |
| C-19 | **Bulk Upload** | Upload multiple documents at once with progress indicators | 🟡 Medium |
| C-20 | **Secure Storage** | Files encrypted at rest, served via signed/expiring URLs (e.g., AWS S3 pre-signed URLs) | 🔴 High |
| C-21 | **File Size & Type Validation** | Client-side + server-side validation (max 10MB per file, allowed types only) | 🔴 High |
| C-22 | **Document Expiry Alerts** | Notify customer when uploaded documents are nearing expiry (e.g., TIN certificate renewal) | 🟢 Low |

### 2.4 💳 Payments & Billing

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-23 | **Service Purchase** | Select and pay for services (Tax Filing, Consultation, etc.) | 🔴 High |
| C-24 | **Payment Gateway Integration** | Pay via bKash, Nagad, Rocket, or card (SSLCommerz / Stripe) | 🔴 High |
| C-25 | **Invoice Generation** | Auto-generated invoices (PDF) for each payment with proper Bangladeshi tax format | 🔴 High |
| C-26 | **Payment History** | Full log of all transactions with date, amount, service, status, and receipt download | 🔴 High |
| C-27 | **Pending Payments** | Show any outstanding balances or partially paid services | 🟡 Medium |
| C-28 | **Refund Requests** | Submit a refund request with reason — tracked through resolution | 🟡 Medium |
| C-29 | **Promo / Coupon Codes** | Apply discount codes during checkout | 🟢 Low |
| C-30 | **Subscription Plans** | Annual retainer packages for recurring clients (e.g., monthly bookkeeping + annual filing) | 🟢 Low |

### 2.5 📅 Consultation / Appointment Booking

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-31 | **Book Consultation** | Select date, time slot, and preferred medium (phone / video / in-person) | 🔴 High |
| C-32 | **Calendar View** | See available slots in a weekly/monthly calendar UI | 🟡 Medium |
| C-33 | **Reschedule / Cancel** | Modify or cancel upcoming consultations (with cancellation policy) | 🟡 Medium |
| C-34 | **Consultation History** | View past consultations with notes/summary from the advisor | 🟡 Medium |
| C-35 | **Reminder Notifications** | Email/SMS reminders 24h and 1h before the appointment | 🟡 Medium |
| C-36 | **Video Call Integration** | Integrated video conferencing (Google Meet / Zoom link auto-generation) | 🟢 Low |

### 2.6 💬 Communication

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-37 | **In-App Messaging** | Real-time chat with assigned tax advisor | 🟡 Medium |
| C-38 | **File Sharing in Chat** | Send/receive documents directly within the chat | 🟡 Medium |
| C-39 | **Email Notifications** | Automated emails for: document status changes, payment confirmations, appointment reminders, filing updates | 🔴 High |
| C-40 | **SMS Notifications** | Critical alerts via SMS (filing complete, payment received, deadline approaching) | 🟡 Medium |
| C-41 | **Support Ticket System** | Submit support tickets with categories: Billing, Technical, Tax Query, General | 🟡 Medium |

### 2.7 👤 Profile & Settings

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-42 | **Personal Information** | Manage name, email, phone, address, NID, TIN, date of birth | 🔴 High |
| C-43 | **Taxpayer Profile** | Income sources, employment type, business details, filing zone/circle | 🔴 High |
| C-44 | **Change Password** | Update password with current password verification | 🔴 High |
| C-45 | **Two-Factor Authentication** | Enable 2FA via SMS or authenticator app | 🟢 Low |
| C-46 | **Language Preference** | Switch between English and Bangla | 🟡 Medium |
| C-47 | **Notification Preferences** | Toggle email/SMS/push notifications per category | 🟡 Medium |
| C-48 | **Delete Account** | GDPR-style account deletion with data export option | 🟢 Low |

### 2.8 📋 Tax Filing Workspace

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| C-49 | **Filing Year Selection** | Select assessment year to view/manage filing for that year | 🔴 High |
| C-50 | **Step-by-Step Filing Progress** | Track stages: Documents Collected → Return Prepared → Under Review → E-Filed → Acknowledgement Received | 🔴 High |
| C-51 | **Return Preview** | View a summary of the prepared return before final submission (read-only) | 🟡 Medium |
| C-52 | **Download Filed Return** | Download the final filed return copy (PDF) and acknowledgement receipt | 🔴 High |
| C-53 | **Year-over-Year Comparison** | Compare key figures (income, tax paid, refund) across assessment years | 🟢 Low |
| C-54 | **Tax Savings Report** | Summary of deductions and rebates applied, with tips for next year | 🟢 Low |

---

## 3. Admin Panel Features

### 3.1 🔐 Admin Authentication & Roles

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-01 | **Admin Login** | Secure login with email/password + mandatory 2FA | 🔴 High |
| A-02 | **Role-Based Access Control (RBAC)** | Roles: Super Admin, Tax Advisor, Operations Staff, Support Agent | 🔴 High |
| A-03 | **Staff Management** | Add, edit, deactivate staff accounts; assign roles and permissions | 🔴 High |
| A-04 | **Audit Log** | Track all admin actions: who did what, when (immutable log) | 🟡 Medium |
| A-05 | **IP Whitelisting** | Restrict admin panel access to specific IP addresses | 🟢 Low |

### 3.2 📊 Admin Dashboard & Analytics

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-06 | **Overview Dashboard** | KPIs: Total Customers, Active Filings, Revenue (MTD/YTD), Pending Documents, Open Tickets | 🔴 High |
| A-07 | **Revenue Analytics** | Charts showing revenue breakdown by service type, payment method, time period | 🔴 High |
| A-08 | **Customer Growth Chart** | Line/bar chart of new customer signups over time | 🟡 Medium |
| A-09 | **Filing Season Dashboard** | Special view during tax season: filings completed vs. pending, advisor workloads | 🟡 Medium |
| A-10 | **Document Pipeline** | Visual pipeline: Documents Received → Under Review → Accepted/Rejected | 🟡 Medium |
| A-11 | **Consultation Analytics** | Bookings per day/week, completion rate, average duration, advisor ratings | 🟡 Medium |
| A-12 | **Website Traffic Analytics** | Page views, bounce rate, top pages (integrate Google Analytics or self-hosted) | 🟢 Low |

### 3.3 👥 Customer Management

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-13 | **Customer List** | Searchable, filterable, sortable table of all customers | 🔴 High |
| A-14 | **Customer Profile View** | Full 360° view: personal info, documents, payments, filings, communications, activity log | 🔴 High |
| A-15 | **Customer Status** | Mark as: Active, Inactive, Suspended, VIP | 🟡 Medium |
| A-16 | **Assign Tax Advisor** | Assign/reassign customers to specific tax advisors | 🔴 High |
| A-17 | **Bulk Actions** | Send bulk emails/SMS, export customer data, change status in bulk | 🟡 Medium |
| A-18 | **Customer Notes** | Internal notes per customer (visible only to admins) | 🟡 Medium |
| A-19 | **Customer Search** | Advanced search by: name, TIN, NID, phone, email, service type, status | 🔴 High |
| A-20 | **Impersonate Customer** | "View as Customer" to debug issues (with audit trail) | 🟢 Low |

### 3.4 📁 Document Management (Admin Side)

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-21 | **Document Review Queue** | List of all pending documents awaiting review, sorted by upload date | 🔴 High |
| A-22 | **Approve / Reject Documents** | One-click approve or reject with mandatory reason for rejection | 🔴 High |
| A-23 | **Request Additional Documents** | Send a document request to customer with specific requirements | 🔴 High |
| A-24 | **Document Download** | Download individual or bulk documents per customer | 🔴 High |
| A-25 | **Document Annotations** | Add internal notes or highlights on uploaded documents | 🟢 Low |
| A-26 | **Secure Document Access Log** | Track who viewed/downloaded which document and when | 🟡 Medium |

### 3.5 📋 Tax Filing Management

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-27 | **Filing Queue** | Dashboard view of all filings with status filters (Pending, In Progress, Filed, Completed) | 🔴 High |
| A-28 | **Update Filing Status** | Change filing stage for each customer (triggers customer notification) | 🔴 High |
| A-29 | **Upload Return Copy** | Upload the filed return PDF and acknowledgement receipt to the customer's account | 🔴 High |
| A-30 | **Filing Assignment** | Auto-assign or manually assign filings to advisors based on workload | 🟡 Medium |
| A-31 | **Deadline Tracker** | See all customers approaching deadlines with days remaining | 🔴 High |
| A-32 | **Filing Statistics** | Year-wise stats: total filings completed, average processing time, advisor performance | 🟡 Medium |
| A-33 | **Bulk Status Update** | Update filing status for multiple customers at once | 🟡 Medium |

### 3.6 💰 Financial Management

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-34 | **Payment Overview** | All transactions: customer, service, amount, method, status, date | 🔴 High |
| A-35 | **Revenue Reports** | Generate revenue reports by period, service type, advisor | 🔴 High |
| A-36 | **Pending Payments** | List of unpaid/partially paid services with follow-up actions | 🔴 High |
| A-37 | **Issue Refunds** | Process refunds with reason tracking and approval workflow | 🟡 Medium |
| A-38 | **Invoice Management** | View/download/resend invoices; manually create invoices | 🟡 Medium |
| A-39 | **Coupon / Promo Management** | Create, edit, deactivate discount codes with usage limits and expiry dates | 🟢 Low |
| A-40 | **Financial Export** | Export transactions as CSV/Excel for accounting software integration | 🟡 Medium |

### 3.7 📅 Consultation Management

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-41 | **Booking Management** | View all appointments: upcoming, completed, cancelled | 🔴 High |
| A-42 | **Advisor Schedule Management** | Set availability per advisor (working hours, holidays, blocked slots) | 🔴 High |
| A-43 | **Reschedule / Cancel from Admin** | Admin can reschedule or cancel with automatic customer notification | 🟡 Medium |
| A-44 | **Consultation Notes** | Advisor writes session notes/summary after each consultation | 🟡 Medium |
| A-45 | **Follow-Up Actions** | Create follow-up tasks from a consultation (e.g., "Client to upload bank statement") | 🟡 Medium |

### 3.8 💬 Communication Management

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-46 | **Message Center** | View and reply to all customer messages (organized by customer) | 🔴 High |
| A-47 | **Broadcast Notifications** | Send announcements to all customers or filtered groups (e.g., "Filing deadline reminder") | 🟡 Medium |
| A-48 | **Email Templates** | Manage reusable email templates for common communications | 🟡 Medium |
| A-49 | **SMS Gateway Management** | Configure SMS provider, view delivery reports | 🟡 Medium |
| A-50 | **Support Ticket Management** | View, assign, prioritize, and resolve customer support tickets | 🔴 High |
| A-51 | **Canned Responses** | Pre-written responses for common queries (tax FAQs, document requests) | 🟢 Low |

### 3.9 🌐 Website Content Management (CMS)

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-52 | **Hero Section Editor** | Edit hero text, images, CTAs without touching code | 🟡 Medium |
| A-53 | **Services Management** | Add/edit/remove/reorder services | 🟡 Medium |
| A-54 | **Team Management** | Add/edit/remove team members with photo, bio, designation | 🟡 Medium |
| A-55 | **FAQ Management** | Add/edit/remove/reorder FAQ questions and answers | 🟡 Medium |
| A-56 | **Testimonial Management** | Add/edit/remove customer testimonials with rating, photo, text | 🟡 Medium |
| A-57 | **Pricing Management** | Update service prices, package names, features | 🟡 Medium |
| A-58 | **Blog / Resource Center** | Create and publish tax guides, articles, news updates | 🟢 Low |
| A-59 | **SEO Settings** | Edit meta titles, descriptions, OG tags per page | 🟢 Low |
| A-60 | **Banner / Announcement Bar** | Create dismissible top banners (e.g., "Tax season ends Nov 30!") | 🟢 Low |

### 3.10 📈 Reporting & Export

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-61 | **Custom Report Builder** | Generate reports with custom date ranges, filters, and groupings | 🟡 Medium |
| A-62 | **Filing Season Report** | End-of-season summary: total filings, revenue, advisor performance | 🟡 Medium |
| A-63 | **Customer Acquisition Report** | Where customers come from (referral, Google, social media) with UTM tracking | 🟢 Low |
| A-64 | **Export to PDF / Excel** | All reports exportable in PDF and Excel formats | 🟡 Medium |
| A-65 | **Scheduled Reports** | Auto-generate and email reports on a schedule (daily/weekly/monthly) | 🟢 Low |

### 3.11 ⚙️ System Settings

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| A-66 | **Company Settings** | Business name, logo, address, contact info, social links | 🔴 High |
| A-67 | **Tax Season Configuration** | Set current assessment year, filing deadlines, late fee rules | 🔴 High |
| A-68 | **Payment Gateway Settings** | Configure bKash, Nagad, SSLCommerz API keys | 🔴 High |
| A-69 | **Email / SMS Provider Settings** | Configure SMTP, SMS API credentials | 🔴 High |
| A-70 | **File Storage Settings** | Configure S3 bucket, max file size, allowed file types | 🟡 Medium |
| A-71 | **Backup & Restore** | Manual/scheduled database backups with restore capability | 🟡 Medium |
| A-72 | **Maintenance Mode** | Toggle site maintenance mode with custom message | 🟢 Low |

---

## 4. Public Website Enhancements

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| W-01 | **Login / Register Buttons** | Add prominent auth buttons to navbar | 🔴 High |
| W-02 | **Customer Testimonials (Dynamic)** | Pull testimonials from database instead of static JSON | 🟡 Medium |
| W-03 | **Blog / Tax Guide Section** | SEO-friendly articles on tax topics (boosts organic traffic) | 🟡 Medium |
| W-04 | **Tax Calculator Widget** | Simple calculator: input income → estimate tax liability | 🟡 Medium |
| W-05 | **Live Chat Widget** | Tawk.to or custom chat widget for instant support | 🟢 Low |
| W-06 | **Referral Programme** | "Refer a friend, get BDT 200 off" with unique referral links | 🟢 Low |
| W-07 | **Multi-Language Switcher (Enhanced)** | Persistent language preference with URL-based routing (`/en/`, `/bn/`) | 🟡 Medium |
| W-08 | **Cookie Consent (Enhanced)** | Category-based consent (necessary, analytics, marketing) per GDPR/local law | 🟢 Low |
| W-09 | **Accessibility (a11y)** | WCAG 2.1 AA compliance: screen reader support, keyboard navigation, contrast ratios | 🟢 Low |
| W-10 | **Progressive Web App (PWA)** | Installable on mobile, offline access to dashboard | 🟢 Low |

---

## 5. Shared / Cross-Cutting Features

| # | Feature | Description | Priority |
|---|---------|-------------|----------|
| X-01 | **Responsive Design** | All panels fully responsive (mobile, tablet, desktop) | 🔴 High |
| X-02 | **Dark Mode** | Toggle dark/light theme across all panels | 🟢 Low |
| X-03 | **Rate Limiting** | Prevent brute-force attacks on auth endpoints | 🔴 High |
| X-04 | **Input Sanitization** | Prevent XSS, SQL injection, and other input-based attacks | 🔴 High |
| X-05 | **CORS Configuration** | Proper cross-origin resource sharing setup | 🔴 High |
| X-06 | **Error Monitoring** | Sentry or equivalent for tracking frontend and backend errors | 🟡 Medium |
| X-07 | **Logging** | Structured logging (Winston/Pino) for all backend operations | 🟡 Medium |
| X-08 | **CI/CD Pipeline** | Automated testing + deployment on push to main branch | 🟡 Medium |
| X-09 | **Automated Backups** | Scheduled database + file storage backups | 🔴 High |
| X-10 | **HTTPS Everywhere** | SSL/TLS on all endpoints | 🔴 High |
| X-11 | **API Versioning** | Version all API endpoints (`/api/v1/...`) for future compatibility | 🟡 Medium |
| X-12 | **Bangla Date/Number Formatting** | Display dates and numbers in Bangla format where appropriate | 🟢 Low |

---

## Summary Statistics

| Category | Total Features |
|----------|---------------|
| Customer Panel | 54 features |
| Admin Panel | 72 features |
| Public Website | 10 features |
| Cross-Cutting | 12 features |
| **Grand Total** | **148 features** |

### Priority Breakdown

| Priority | Count | Meaning |
|----------|-------|---------|
| 🔴 High | ~55 | Must-have for MVP launch |
| 🟡 Medium | ~58 | Important for a complete product |
| 🟢 Low | ~35 | Nice-to-have, post-launch enhancements |

---

## Recommended Implementation Phases

### Phase 1 — MVP (4-6 weeks)
- Authentication (C-01 to C-07)
- Customer Dashboard (C-08, C-09, C-12)
- Document Upload & Management (C-13 to C-17, C-20, C-21)
- Payment Integration (C-23, C-24, C-25, C-26)
- Basic Admin Panel (A-01, A-06, A-13, A-14, A-21, A-22, A-27, A-28, A-34, A-66)
- Public Website Auth Integration (W-01)

### Phase 2 — Core Experience (3-4 weeks)
- Consultation Booking (C-31 to C-35)
- Filing Workspace (C-49, C-50, C-52)
- Admin Filing Management (A-29 to A-31)
- Communication (C-37, C-39, A-46)
- Support Tickets (C-41, A-50)
- CMS Basics (A-52 to A-57)

### Phase 3 — Growth & Polish (3-4 weeks)
- Analytics & Reporting (A-07, A-08, A-61 to A-64)
- Advanced Document Features (C-15, C-16, C-19)
- Consultation Enhancements (C-36, A-44, A-45)
- Blog / Resource Center (A-58, W-03)
- Tax Calculator (W-04)

### Phase 4 — Scale & Optimize (Ongoing)
- Subscription Plans (C-30)
- Referral Programme (W-06)
- PWA (W-10)
- Advanced Security (C-45, A-05)
- Dark Mode (X-02)
- Scheduled Reports (A-65)
