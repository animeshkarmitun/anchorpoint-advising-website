# Anchor Point Advising — Backend Architecture Plan

> **Last Updated:** 21 February 2026  
> **Stack:** NestJS + PostgreSQL + Prisma + S3 + Redis  
> **API Base:** `/api/v1`

---

## 1. High-Level Architecture

```
                    ┌──────────────┐
                    │   NGINX      │
                    │  (Reverse    │
                    │   Proxy)     │
                    └──────┬───────┘
                           │
              ┌────────────┴────────────┐
              │                         │
     ┌────────▼────────┐     ┌──────────▼──────────┐
     │   Next.js :3000  │     │   NestJS API :4000   │
     │   (Frontend)     │     │   (Backend)          │
     │                  │     │                      │
     │  • SSR Pages     │     │  • REST API          │
     │  • Customer UI   │◄───►│  • WebSocket Gateway │
     │  • Admin UI      │     │  • Background Jobs   │
     └──────────────────┘     │  • File Processing   │
                              └──────────┬───────────┘
                                         │
                    ┌────────────────────┬┴───────────────┐
                    │                    │                │
           ┌───────▼───────┐   ┌────────▼──────┐  ┌─────▼─────┐
           │  PostgreSQL   │   │    Redis       │  │  AWS S3    │
           │  (Primary DB) │   │  (Cache/Queue) │  │  (Files)   │
           └───────────────┘   └───────────────┘  └───────────┘
```

---

## 2. NestJS Module Structure

```
src/
├── app.module.ts                  # Root module
├── main.ts                        # Bootstrap
├── common/                        # Shared utilities
│   ├── decorators/                # @Roles(), @CurrentUser(), @Public()
│   ├── guards/                    # JwtAuthGuard, RolesGuard
│   ├── filters/                   # HttpExceptionFilter
│   ├── interceptors/              # TransformInterceptor, LoggingInterceptor
│   ├── pipes/                     # ValidationPipe config
│   ├── dto/                       # PaginationDto, SortDto
│   └── utils/                     # Helpers, constants
│
├── modules/
│   ├── auth/                      # Authentication & authorization
│   │   ├── auth.module.ts
│   │   ├── auth.controller.ts     # login, register, refresh, forgot-password
│   │   ├── auth.service.ts
│   │   ├── strategies/            # JwtStrategy, LocalStrategy
│   │   ├── guards/                # JwtAuthGuard, RolesGuard
│   │   └── dto/                   # LoginDto, RegisterDto, ResetPasswordDto
│   │
│   ├── users/                     # User & profile management
│   │   ├── users.module.ts
│   │   ├── users.controller.ts    # CRUD, profile, preferences
│   │   ├── users.service.ts
│   │   └── dto/
│   │
│   ├── documents/                 # Document upload & management
│   │   ├── documents.module.ts
│   │   ├── documents.controller.ts
│   │   ├── documents.service.ts
│   │   └── dto/
│   │
│   ├── filings/                   # Tax filing lifecycle
│   │   ├── filings.module.ts
│   │   ├── filings.controller.ts
│   │   ├── filings.service.ts
│   │   └── dto/
│   │
│   ├── payments/                  # Payment processing & invoicing
│   │   ├── payments.module.ts
│   │   ├── payments.controller.ts
│   │   ├── payments.service.ts
│   │   ├── invoice.service.ts
│   │   └── dto/
│   │
│   ├── consultations/             # Appointment booking
│   │   ├── consultations.module.ts
│   │   ├── consultations.controller.ts
│   │   ├── consultations.service.ts
│   │   └── dto/
│   │
│   ├── messages/                  # In-app chat
│   │   ├── messages.module.ts
│   │   ├── messages.controller.ts
│   │   ├── messages.service.ts
│   │   └── messages.gateway.ts    # WebSocket gateway
│   │
│   ├── notifications/             # Email, SMS, push, in-app
│   │   ├── notifications.module.ts
│   │   ├── notifications.service.ts
│   │   ├── email.service.ts       # Brevo/Resend/SMTP
│   │   ├── sms.service.ts         # BD SMS gateway
│   │   └── templates/
│   │
│   ├── tickets/                   # Support ticket system
│   │   ├── tickets.module.ts
│   │   ├── tickets.controller.ts
│   │   ├── tickets.service.ts
│   │   └── dto/
│   │
│   ├── cms/                       # Website content management
│   │   ├── cms.module.ts
│   │   ├── cms.controller.ts
│   │   ├── cms.service.ts
│   │   └── dto/
│   │
│   ├── analytics/                 # Dashboard & reporting
│   │   ├── analytics.module.ts
│   │   ├── analytics.controller.ts
│   │   ├── analytics.service.ts
│   │   └── dto/
│   │
│   ├── upload/                    # S3 file operations
│   │   ├── upload.module.ts
│   │   ├── upload.controller.ts
│   │   └── upload.service.ts
│   │
│   └── settings/                  # System configuration
│       ├── settings.module.ts
│       ├── settings.controller.ts
│       └── settings.service.ts
│
├── jobs/                          # Background jobs & cron
│   ├── jobs.module.ts
│   ├── deadline-reminder.job.ts
│   ├── document-expiry.job.ts
│   ├── backup.job.ts
│   └── report-generator.job.ts
│
└── prisma/
    ├── schema.prisma
    ├── seed.ts
    └── migrations/
```

---

## 3. Database Schema (Prisma)

### 3.1 User & Authentication

```prisma
enum Role {
  CUSTOMER
  TAX_ADVISOR
  OPERATIONS
  SUPPORT
  SUPER_ADMIN
}

enum AuthProvider {
  EMAIL
  GOOGLE
  PHONE
}

model User {
  id              String       @id @default(cuid())
  email           String       @unique
  phone           String?      @unique
  passwordHash    String?
  role            Role         @default(CUSTOMER)
  authProvider    AuthProvider  @default(EMAIL)
  emailVerified   Boolean      @default(false)
  phoneVerified   Boolean      @default(false)
  twoFactorEnabled Boolean    @default(false)
  twoFactorSecret String?
  status          UserStatus   @default(ACTIVE)
  lastLoginAt     DateTime?
  createdAt       DateTime     @default(now())
  updatedAt       DateTime     @updatedAt

  profile         CustomerProfile?
  documents       Document[]
  filings         Filing[]
  payments        Payment[]
  consultationsAsClient    Consultation[] @relation("ClientConsultations")
  consultationsAsAdvisor   Consultation[] @relation("AdvisorConsultations")
  sentMessages    Message[]    @relation("SentMessages")
  receivedMessages Message[]  @relation("ReceivedMessages")
  notifications   Notification[]
  tickets         Ticket[]
  assignedTickets Ticket[]     @relation("AssignedTickets")
  assignedFilings Filing[]     @relation("AdvisorFilings")
  auditLogs       AuditLog[]
  refreshTokens   RefreshToken[]

  @@index([email])
  @@index([phone])
  @@index([role])
}

enum UserStatus {
  ACTIVE
  INACTIVE
  SUSPENDED
}

model RefreshToken {
  id        String   @id @default(cuid())
  token     String   @unique
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  expiresAt DateTime
  createdAt DateTime @default(now())

  @@index([userId])
}
```

### 3.2 Customer Profile

```prisma
enum IncomeSource {
  SALARY
  BUSINESS
  FREELANCE
  RENTAL
  INVESTMENT
  OTHER
}

enum TaxpayerCategory {
  INDIVIDUAL
  COMPANY
  PARTNERSHIP
  OTHER
}

model CustomerProfile {
  id                String             @id @default(cuid())
  userId            String             @unique
  user              User               @relation(fields: [userId], references: [id], onDelete: Cascade)
  fullName          String
  fullNameBn        String?
  nid               String?
  tin               String?
  dateOfBirth       DateTime?
  address           String?
  city              String?
  district          String?
  taxZone           String?
  taxCircle         String?
  taxpayerCategory  TaxpayerCategory   @default(INDIVIDUAL)
  incomeSources     IncomeSource[]
  employerName      String?
  businessName      String?
  tradeLicenseNo    String?
  language          String             @default("en")
  notifyEmail       Boolean            @default(true)
  notifySms         Boolean            @default(true)
  referralCode      String?            @unique
  referredBy        String?
  vip               Boolean            @default(false)
  notes             String?            // Admin-only internal notes
  createdAt         DateTime           @default(now())
  updatedAt         DateTime           @updatedAt

  @@index([tin])
  @@index([nid])
}
```

### 3.3 Documents

```prisma
enum DocumentCategory {
  NID
  TIN_CERTIFICATE
  SALARY_CERTIFICATE
  BANK_STATEMENT
  RENTAL_AGREEMENT
  INVESTMENT_PROOF
  PREVIOUS_RETURN
  TRADE_LICENSE
  ASSET_STATEMENT
  FILED_RETURN        // Uploaded by admin after filing
  ACKNOWLEDGEMENT     // NBR acknowledgement receipt
  OTHER
}

enum DocumentStatus {
  PENDING
  ACCEPTED
  REJECTED
  NEEDS_REUPLOAD
}

model Document {
  id            String           @id @default(cuid())
  userId        String
  user          User             @relation(fields: [userId], references: [id], onDelete: Cascade)
  filingId      String?
  filing        Filing?          @relation(fields: [filingId], references: [id])
  category      DocumentCategory
  fileName      String
  fileKey       String           // S3 key
  fileSize      Int              // bytes
  mimeType      String
  status        DocumentStatus   @default(PENDING)
  rejectionNote String?
  reviewedBy    String?
  reviewedAt    DateTime?
  version       Int              @default(1)
  parentId      String?          // For version tracking
  parent        Document?        @relation("DocumentVersions", fields: [parentId], references: [id])
  versions      Document[]       @relation("DocumentVersions")
  expiresAt     DateTime?
  createdAt     DateTime         @default(now())
  updatedAt     DateTime         @updatedAt

  @@index([userId])
  @@index([filingId])
  @@index([status])
  @@index([category])
}
```

### 3.4 Tax Filing

```prisma
enum FilingStatus {
  INITIATED            // Customer started the process
  DOCUMENTS_PENDING    // Waiting for documents
  DOCUMENTS_RECEIVED   // All docs uploaded
  UNDER_PREPARATION    // Advisor preparing return
  REVIEW_READY         // Return ready for customer preview
  CUSTOMER_APPROVED    // Customer confirmed
  E_FILED              // Submitted to NBR
  ACKNOWLEDGED         // NBR acknowledgement received
  COMPLETED            // Fully done
  ON_HOLD              // Blocked (missing info, etc.)
}

model Filing {
  id              String        @id @default(cuid())
  userId          String
  user            User          @relation(fields: [userId], references: [id])
  advisorId       String?
  advisor         User?         @relation("AdvisorFilings", fields: [advisorId], references: [id])
  assessmentYear  String        // e.g., "2025-2026"
  status          FilingStatus  @default(INITIATED)
  serviceType     String        // "individual", "corporate", "nrb"
  totalIncome     Decimal?
  taxPayable      Decimal?
  taxPaid         Decimal?
  refundAmount    Decimal?
  filedAt         DateTime?
  acknowledgedAt  DateTime?
  deadline        DateTime?
  internalNotes   String?
  documents       Document[]
  statusHistory   FilingStatusLog[]
  createdAt       DateTime      @default(now())
  updatedAt       DateTime      @updatedAt

  @@unique([userId, assessmentYear])
  @@index([advisorId])
  @@index([status])
  @@index([assessmentYear])
}

model FilingStatusLog {
  id        String       @id @default(cuid())
  filingId  String
  filing    Filing       @relation(fields: [filingId], references: [id], onDelete: Cascade)
  from      FilingStatus
  to        FilingStatus
  changedBy String
  note      String?
  createdAt DateTime     @default(now())

  @@index([filingId])
}
```

### 3.5 Payments & Invoices

```prisma
enum PaymentStatus {
  PENDING
  COMPLETED
  FAILED
  REFUNDED
  PARTIALLY_REFUNDED
}

enum PaymentMethod {
  BKASH
  NAGAD
  ROCKET
  CARD
  BANK_TRANSFER
  CASH
}

model Payment {
  id              String        @id @default(cuid())
  userId          String
  user            User          @relation(fields: [userId], references: [id])
  filingId        String?
  consultationId  String?
  amount          Decimal
  currency        String        @default("BDT")
  method          PaymentMethod
  status          PaymentStatus @default(PENDING)
  transactionId   String?       // Gateway reference
  gatewayResponse Json?
  couponId        String?
  coupon          Coupon?       @relation(fields: [couponId], references: [id])
  discountAmount  Decimal?
  invoice         Invoice?
  refunds         Refund[]
  createdAt       DateTime      @default(now())
  updatedAt       DateTime      @updatedAt

  @@index([userId])
  @@index([status])
}

model Invoice {
  id          String   @id @default(cuid())
  paymentId   String   @unique
  payment     Payment  @relation(fields: [paymentId], references: [id])
  invoiceNo   String   @unique // e.g., "APA-2026-0001"
  issuedAt    DateTime @default(now())
  dueDate     DateTime?
  fileKey     String?  // S3 key for generated PDF
  createdAt   DateTime @default(now())
}

model Refund {
  id        String   @id @default(cuid())
  paymentId String
  payment   Payment  @relation(fields: [paymentId], references: [id])
  amount    Decimal
  reason    String
  status    String   @default("pending") // pending, approved, processed, rejected
  processedBy String?
  createdAt DateTime @default(now())

  @@index([paymentId])
}

model Coupon {
  id            String    @id @default(cuid())
  code          String    @unique
  discountType  String    // "percentage" or "fixed"
  discountValue Decimal
  maxUses       Int?
  usedCount     Int       @default(0)
  minAmount     Decimal?
  expiresAt     DateTime?
  active        Boolean   @default(true)
  payments      Payment[]
  createdAt     DateTime  @default(now())
}
```

### 3.6 Consultations

```prisma
enum ConsultationStatus {
  SCHEDULED
  CONFIRMED
  IN_PROGRESS
  COMPLETED
  CANCELLED
  NO_SHOW
}

enum ConsultationMedium {
  PHONE
  VIDEO
  IN_PERSON
}

model Consultation {
  id          String              @id @default(cuid())
  clientId    String
  client      User                @relation("ClientConsultations", fields: [clientId], references: [id])
  advisorId   String
  advisor     User                @relation("AdvisorConsultations", fields: [advisorId], references: [id])
  scheduledAt DateTime
  duration    Int                 @default(30) // minutes
  medium      ConsultationMedium
  meetingLink String?
  status      ConsultationStatus  @default(SCHEDULED)
  notes       String?             // Advisor's session notes
  followUp    String?             // Follow-up actions
  cancelledAt DateTime?
  cancelReason String?
  createdAt   DateTime            @default(now())
  updatedAt   DateTime            @updatedAt

  @@index([clientId])
  @@index([advisorId])
  @@index([scheduledAt])
  @@index([status])
}

model AdvisorSchedule {
  id        String   @id @default(cuid())
  advisorId String
  dayOfWeek Int      // 0=Sunday, 6=Saturday
  startTime String   // "09:00"
  endTime   String   // "17:00"
  slotDuration Int   @default(30) // minutes
  active    Boolean  @default(true)

  @@unique([advisorId, dayOfWeek])
}

model ScheduleException {
  id        String   @id @default(cuid())
  advisorId String
  date      DateTime
  available Boolean  @default(false) // false = blocked, true = extra availability
  reason    String?

  @@unique([advisorId, date])
}
```

### 3.7 Messaging, Notifications, Tickets

```prisma
model Conversation {
  id           String    @id @default(cuid())
  participantA String
  participantB String
  lastMessageAt DateTime?
  messages     Message[]
  createdAt    DateTime  @default(now())

  @@unique([participantA, participantB])
}

model Message {
  id             String       @id @default(cuid())
  conversationId String
  conversation   Conversation @relation(fields: [conversationId], references: [id])
  senderId       String
  sender         User         @relation("SentMessages", fields: [senderId], references: [id])
  receiverId     String
  receiver       User         @relation("ReceivedMessages", fields: [receiverId], references: [id])
  content        String
  attachmentKey  String?      // S3 key
  read           Boolean      @default(false)
  readAt         DateTime?
  createdAt      DateTime     @default(now())

  @@index([conversationId])
  @@index([receiverId, read])
}

model Notification {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  type      String   // "filing_update", "document_status", "payment", "reminder", "system"
  title     String
  body      String
  link      String?  // Deep link to relevant page
  read      Boolean  @default(false)
  readAt    DateTime?
  createdAt DateTime @default(now())

  @@index([userId, read])
  @@index([type])
}

enum TicketPriority { LOW MEDIUM HIGH URGENT }
enum TicketStatus { OPEN IN_PROGRESS WAITING_ON_CUSTOMER RESOLVED CLOSED }
enum TicketCategory { BILLING TECHNICAL TAX_QUERY DOCUMENT GENERAL }

model Ticket {
  id          String         @id @default(cuid())
  userId      String
  user        User           @relation(fields: [userId], references: [id])
  assignedTo  String?
  assignee    User?          @relation("AssignedTickets", fields: [assignedTo], references: [id])
  subject     String
  category    TicketCategory
  priority    TicketPriority @default(MEDIUM)
  status      TicketStatus   @default(OPEN)
  replies     TicketReply[]
  resolvedAt  DateTime?
  createdAt   DateTime       @default(now())
  updatedAt   DateTime       @updatedAt

  @@index([userId])
  @@index([assignedTo])
  @@index([status])
}

model TicketReply {
  id        String  @id @default(cuid())
  ticketId  String
  ticket    Ticket  @relation(fields: [ticketId], references: [id], onDelete: Cascade)
  authorId  String
  content   String
  isInternal Boolean @default(false) // Admin-only notes
  createdAt DateTime @default(now())

  @@index([ticketId])
}
```

### 3.8 CMS & System

```prisma
model CmsContent {
  id        String   @id @default(cuid())
  section   String   // "hero", "services", "faq", "team", "pricing", "testimonials"
  locale    String   @default("en")
  data      Json     // Flexible JSON for any section
  updatedBy String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@unique([section, locale])
}

model Setting {
  id    String @id @default(cuid())
  key   String @unique  // "assessment_year", "filing_deadline", "company_name", etc.
  value Json
}

model AuditLog {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id])
  action    String   // "user.create", "document.approve", "filing.status_change"
  entity    String   // "User", "Document", "Filing"
  entityId  String
  oldValue  Json?
  newValue  Json?
  ip        String?
  userAgent String?
  createdAt DateTime @default(now())

  @@index([userId])
  @@index([entity, entityId])
  @@index([createdAt])
}
```

---

## 4. API Structure

### 4.1 Public (No Auth)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/register` | Register new customer |
| POST | `/auth/login` | Login (email/phone + password) |
| POST | `/auth/google` | Google OAuth callback |
| POST | `/auth/send-otp` | Send OTP to phone |
| POST | `/auth/verify-otp` | Verify phone OTP |
| POST | `/auth/forgot-password` | Request password reset |
| POST | `/auth/reset-password` | Reset password with token |
| POST | `/auth/refresh` | Refresh access token |
| GET | `/cms/:section/:locale` | Get public content (hero, faq, etc.) |
| GET | `/services` | List services (public) |

### 4.2 Customer (`/customer/*`) — Role: CUSTOMER

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/customer/dashboard` | Dashboard overview stats |
| GET/PUT | `/customer/profile` | Get/update profile |
| PUT | `/customer/change-password` | Change password |
| **Documents** | | |
| POST | `/customer/documents` | Upload document(s) |
| GET | `/customer/documents` | List my documents (filter by filing, category, status) |
| GET | `/customer/documents/:id` | Get document details |
| GET | `/customer/documents/:id/download` | Download (presigned URL) |
| DELETE | `/customer/documents/:id` | Delete pending document |
| GET | `/customer/documents/checklist/:filingId` | Required docs checklist |
| **Filings** | | |
| POST | `/customer/filings` | Start new filing |
| GET | `/customer/filings` | List my filings |
| GET | `/customer/filings/:id` | Filing detail + status history |
| GET | `/customer/filings/:id/return` | Download filed return PDF |
| **Payments** | | |
| POST | `/customer/payments/initiate` | Initiate payment |
| POST | `/customer/payments/callback` | Payment gateway callback (IPN) |
| GET | `/customer/payments` | Payment history |
| GET | `/customer/payments/:id/invoice` | Download invoice PDF |
| POST | `/customer/refunds` | Request refund |
| POST | `/customer/payments/apply-coupon` | Validate & apply coupon |
| **Consultations** | | |
| GET | `/customer/consultations/slots` | Available time slots |
| POST | `/customer/consultations` | Book consultation |
| GET | `/customer/consultations` | My consultations |
| PUT | `/customer/consultations/:id/reschedule` | Reschedule |
| PUT | `/customer/consultations/:id/cancel` | Cancel |
| **Messages** | | |
| GET | `/customer/conversations` | My conversations |
| GET | `/customer/conversations/:id/messages` | Messages in conversation |
| POST | `/customer/conversations/:id/messages` | Send message |
| PUT | `/customer/messages/:id/read` | Mark as read |
| **Notifications** | | |
| GET | `/customer/notifications` | My notifications |
| PUT | `/customer/notifications/read-all` | Mark all read |
| **Tickets** | | |
| POST | `/customer/tickets` | Create support ticket |
| GET | `/customer/tickets` | My tickets |
| GET | `/customer/tickets/:id` | Ticket detail + replies |
| POST | `/customer/tickets/:id/replies` | Reply to ticket |

### 4.3 Admin (`/admin/*`) — Roles: SUPER_ADMIN, TAX_ADVISOR, OPERATIONS, SUPPORT

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/dashboard` | Admin KPI dashboard |
| **User Management** | | |
| GET | `/admin/customers` | List all customers (search, filter, sort, paginate) |
| GET | `/admin/customers/:id` | Customer 360° profile |
| PUT | `/admin/customers/:id/status` | Change customer status |
| PUT | `/admin/customers/:id/assign-advisor` | Assign tax advisor |
| POST | `/admin/customers/:id/notes` | Add internal note |
| GET | `/admin/staff` | List staff members |
| POST | `/admin/staff` | Create staff account |
| PUT | `/admin/staff/:id` | Edit staff / change role |
| DELETE | `/admin/staff/:id` | Deactivate staff |
| **Documents** | | |
| GET | `/admin/documents` | Review queue (pending docs) |
| PUT | `/admin/documents/:id/approve` | Approve document |
| PUT | `/admin/documents/:id/reject` | Reject with reason |
| POST | `/admin/documents/request/:userId` | Request docs from customer |
| GET | `/admin/documents/:id/download` | Download document |
| POST | `/admin/documents/bulk-download` | Bulk download (zip) |
| **Filings** | | |
| GET | `/admin/filings` | All filings (filterable) |
| PUT | `/admin/filings/:id/status` | Update filing status |
| PUT | `/admin/filings/:id/assign` | Assign to advisor |
| POST | `/admin/filings/:id/upload-return` | Upload filed return |
| GET | `/admin/filings/deadlines` | Upcoming deadlines |
| PUT | `/admin/filings/bulk-status` | Bulk status update |
| **Payments** | | |
| GET | `/admin/payments` | All transactions |
| GET | `/admin/payments/pending` | Pending payments |
| POST | `/admin/refunds/:id/process` | Process refund |
| GET | `/admin/invoices` | All invoices |
| POST | `/admin/invoices/manual` | Create manual invoice |
| GET | `/admin/payments/export` | Export as CSV/Excel |
| **Consultations** | | |
| GET | `/admin/consultations` | All bookings |
| PUT | `/admin/consultations/:id` | Update (reschedule/cancel/notes) |
| GET/PUT | `/admin/schedules/:advisorId` | Manage advisor schedule |
| POST | `/admin/schedules/:advisorId/exceptions` | Add day off / extra slot |
| **Communication** | | |
| GET | `/admin/conversations` | All customer conversations |
| POST | `/admin/conversations/:id/messages` | Reply as admin |
| POST | `/admin/broadcast` | Send broadcast notification |
| GET/POST/PUT/DELETE | `/admin/email-templates` | CRUD email templates |
| **Tickets** | | |
| GET | `/admin/tickets` | All tickets (filterable) |
| PUT | `/admin/tickets/:id/assign` | Assign ticket |
| PUT | `/admin/tickets/:id/status` | Change status |
| POST | `/admin/tickets/:id/replies` | Reply (public or internal) |
| **CMS** | | |
| GET | `/admin/cms/:section/:locale` | Get section content |
| PUT | `/admin/cms/:section/:locale` | Update section content |
| **Coupons** | | |
| GET/POST | `/admin/coupons` | List / create coupons |
| PUT/DELETE | `/admin/coupons/:id` | Edit / deactivate coupon |
| **Analytics** | | |
| GET | `/admin/analytics/revenue` | Revenue reports |
| GET | `/admin/analytics/customers` | Customer growth |
| GET | `/admin/analytics/filings` | Filing season stats |
| GET | `/admin/analytics/consultations` | Consultation stats |
| GET | `/admin/analytics/export` | Export report (PDF/Excel) |
| **Settings** | | |
| GET/PUT | `/admin/settings` | System settings |
| GET | `/admin/audit-logs` | Audit trail |

### 4.4 WebSocket Events

| Event | Direction | Description |
|-------|-----------|-------------|
| `message:new` | Server → Client | New chat message |
| `message:read` | Server → Client | Message read receipt |
| `notification:new` | Server → Client | New notification |
| `filing:status` | Server → Client | Filing status change |
| `document:status` | Server → Client | Document review result |
| `typing` | Bidirectional | Typing indicator |

---

## 5. Security Architecture

| Layer | Implementation |
|-------|---------------|
| **Auth** | JWT access tokens (15min) + refresh tokens (7d) in httpOnly cookies |
| **RBAC** | Custom `@Roles()` decorator + `RolesGuard` on every protected endpoint |
| **Rate Limiting** | `@nestjs/throttler` — strict on auth endpoints, relaxed on reads |
| **Validation** | `class-validator` DTOs with `ValidationPipe` globally |
| **File Security** | S3 presigned URLs (expire in 15min), server-side MIME validation |
| **Encryption** | bcrypt for passwords, AES-256 for sensitive fields (TIN, NID) |
| **CORS** | Whitelist frontend origin only |
| **Helmet** | Security headers via `helmet` middleware |
| **Audit** | Every write operation logged to `AuditLog` table |

---

## 6. Infrastructure Requirements

| Service | Purpose | Recommendation |
|---------|---------|----------------|
| **Database** | Primary data store | PostgreSQL 15+ (Supabase or self-hosted) |
| **Cache/Queue** | Caching + Bull job queues | Redis 7+ |
| **File Storage** | Document uploads | AWS S3 or DigitalOcean Spaces |
| **Email** | Transactional emails | Brevo (free tier: 300/day) or Resend |
| **SMS** | OTP + alerts | BD local provider (BulkSMSBD, Infobip) |
| **Hosting** | Backend API | VPS (Contabo/Hetzner) or AWS EC2 |
| **Process Manager** | Keep API alive | PM2 |
| **Reverse Proxy** | SSL + routing | Nginx |
| **Monitoring** | Error tracking | Sentry (free tier) |
| **Backups** | Database safety | Automated pg_dump to S3 (daily) |
